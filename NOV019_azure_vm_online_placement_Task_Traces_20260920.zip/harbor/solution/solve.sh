#!/usr/bin/env bash
# Oracle: install the organiser's reference allocator (code + the lifetime tables it learned from the practice
# history) as the artifact. The verifier does the scoring; this script never writes a score.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="${RSI_METHODS_DIR:-/app/methods}/main"
mkdir -p "$DEST"
cp -f "$HERE"/methods/reference/* "$DEST/"
echo "solve.sh: reference installed into $DEST"
