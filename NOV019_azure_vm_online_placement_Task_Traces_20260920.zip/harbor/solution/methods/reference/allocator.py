"""Reference allocator: dual-priced machine-type admission + first-fit compaction.

Two measured facts drive it (practice window P006, see the task README):
  1. The starter's biggest loss is putting a VM on whatever compatible server comes first, including machine types
     on which that VM is expensive (a large share of a heavily weighted server). Restricting each VM to cheap types
     recovers most of the gap.
  2. "Cheap" is not a per-VM property. Servers of one generation fill up in one dimension (on machine type 1 the
     network share binds while ~30 % of memory and cores stay stranded), so the right type for a VM depends on the
     mix of everything else that is running. The fractional vector-packing LP over the VMs alive right now prices
     every (machine type, dimension); a VM type is admitted onto the machine types whose priced cost is within
     RC_EPS of its best one, and a new server is opened on the type with the lowest priced cost.

Placement inside the admitted types is first fit in server order: on these windows compaction beat best fit,
dot-product alignment and (even clairvoyant) lifetime-matching rules, which all spread VMs over more servers.

The LP is re-solved every LP_EVERY_H hours of trace time on the counts of alive VMs by type (a few hundred
variables x 175 capacity rows, HiGHS through scipy, ~0.1 s). Before the first solve, and for VM types absent from
the alive mix, admission falls back to types within DELTA of the VM's cheapest dominant-share cost.
"""
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

from cluster import EPS

RC_EPS = 0.2
LP_EVERY_H = 1.0
DELTA = 0.1
MIN_ALIVE = 200


def lp_prices(counts, demand, compatible, weight):
    """Dual prices p[m, k] >= 0 of the fractional packing LP for the given VM-type counts (None if not solved)."""
    ts = np.flatnonzero(counts > 0)
    n_t, n_m, n_k = demand.shape
    pt, pm = [], []
    for t in ts:
        ms = np.flatnonzero(compatible[t])
        pt += [t] * len(ms)
        pm += ms.tolist()
    pt, pm = np.asarray(pt), np.asarray(pm)
    ny, nx = len(pt), n_m
    c = np.concatenate([weight, np.zeros(ny)])
    a_eq = coo_matrix((np.ones(ny), (np.searchsorted(ts, pt), nx + np.arange(ny))), shape=(len(ts), nx + ny)).tocsr()
    rows, cols, vals = [], [], []
    for k in range(n_k):
        rows.append(pm * n_k + k)
        cols.append(nx + np.arange(ny))
        vals.append(demand[pt, pm, k])
    rows.append(np.arange(n_m * n_k))
    cols.append(np.repeat(np.arange(n_m), n_k))
    vals.append(-np.ones(n_m * n_k))
    a_ub = coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))),
                      shape=(n_m * n_k, nx + ny)).tocsr()
    res = linprog(c, A_ub=a_ub, b_ub=np.zeros(n_m * n_k), A_eq=a_eq, b_eq=counts[ts], bounds=(0, None),
                  method="highs")
    if res.status != 0:
        return None, ts
    return (-res.ineqlin.marginals).reshape(n_m, n_k), ts


class Allocator:
    def reset(self, cluster):
        self.next_lp = -1e9
        self.allow = None
        self.newtype = None
        self.base = None

    def _base(self, m):
        if self.base is None:
            self.base = (m.dom_cost <= m.dom_cost.min(axis=1, keepdims=True) * (1 + DELTA) + 1e-12) & m.compatible
        return self.base

    def _refresh(self, state):
        m = state.machines
        base = self._base(m)
        if len(state.vm_type) < MIN_ALIVE:
            return
        vts = np.fromiter(state.vm_type.values(), dtype=np.int64, count=len(state.vm_type))
        counts = np.bincount(vts, minlength=m.n_types).astype(float)
        prices, ts = lp_prices(counts, m.demand, m.compatible, m.weight)
        if prices is None:
            return
        cost = np.where(m.compatible, np.einsum("tmk,mk->tm", m.demand, prices), np.inf)
        best = cost.min(axis=1)
        rc = cost - best[:, None]
        alive = np.zeros(m.n_types, dtype=bool)
        alive[ts] = True
        admitted = m.compatible & (rc <= RC_EPS * np.maximum(best, 1e-12)[:, None])
        self.allow = np.where(alive[:, None], admitted, base)
        self.newtype = np.where(alive, np.argmin(np.where(m.compatible, rc + 1e-9 * m.dom_cost, np.inf), axis=1),
                                m.cheapest)

    def place(self, request, state):
        t = request["vm_type"]
        m = state.machines
        if request["time"] >= self.next_lp:
            self._refresh(state)
            self.next_lp = request["time"] + LP_EVERY_H
        if self.allow is None:
            allow, new_type = self._base(m)[t], int(m.cheapest[t])
        else:
            allow, new_type = self.allow[t], int(self.newtype[t])
        n = state.n_servers
        if n:
            mt = state.server_type[:n]
            ok = allow[mt] & ((state.used[:n] + m.demand[t][mt]) <= 1.0 + EPS).all(axis=1) & (state.n_vms[:n] > 0)
            k = int(ok.argmax())
            if ok[k]:
                return k
        return f"new:{new_type}"
