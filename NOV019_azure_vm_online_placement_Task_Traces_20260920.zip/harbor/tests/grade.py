#!/usr/bin/env python3
"""Sealed grader for azure_vm_online_placement (harbor separate-verifier image; entry point tests/test.sh).

Protocol
  1. read the sealed scoring band /tests/anchors.json (root-only, 0400) and unlink it before any submitted
     code runs. The band is DECLARED, not applied: it records the measured baseline/reference/upper of this
     task so the band is fixed before any run, and unlinking it keeps the submission from ever reading it.
     No arithmetic here uses it;
  2. run the frozen scorer
         python3 /tests/score.py --split assessment --methods /app/methods --log-dir /logs/verifier/raw
     It re-checks the sealed split against tests/heldout.json (status frozen, sha256 of every hidden file),
     runs the submission in a de-privileged (uid 65534), entropy- and clock-pinned child process, and writes
     the RAW metric as "reward" in raw/reward.json (plus numeric diagnostics; a human note in raw/verifier_note.txt).
     Its own failure paths write raw/verifier_error.json and exit 1 -- those are grader failures, never a 0;
  3. report that RAW metric as "reward" in /logs/verifier/reward.json (flat, numbers only), reward.txt and
     score_details.json.

**The verifier does not normalise.** The SOW fixes the 0.6 anchor as the best hidden result among the
solution and the three designated models' final artifacts, which is only known after the pilot has run;
it is then frozen for the collection period. A second mapping inside the verifier would be a second,
contradicting source of truth for the same score (the buyer found exactly that last round), so the reward
key carries the raw metric and the batch layer does the single normalisation:

    normalized = 0.6 * raw / anchor                          (raw <= anchor)
               = 0.6 + 0.4 * (raw - anchor) / (upper - anchor)   (raw > anchor), clipped to [0, 1]

reward.json keys: reward (== mean_instance_score, the raw metric, repeated under its own name) and the scorer's
aggregate diagnostics. Per-record diagnostics stay in score_details.json (never in reward.json). A
grader-side failure writes reward 0 with grader_failed = 1; a submission without the artifact writes
reward 0 with missing_artifact = 1.
"""
from __future__ import annotations

import json
import math
import os
import re
import subprocess
import sys
import time
from pathlib import Path

TESTS = Path(__file__).resolve().parent
# Two callers, two layouts -- see the header of test.sh. In the verifier image both defaults are right;
# under the platform's clean-sandbox verify the paths arrive as environment and neither default exists.
# test.sh has already validated HARBOR_VERIFIER_LOG_DIR is absolute and exported it.
LOG_DIR = Path(os.environ.get("HARBOR_VERIFIER_LOG_DIR") or "/logs/verifier")
RAW_DIR = LOG_DIR / "raw"
SUBMISSION = Path(os.environ.get("RSI_METHODS_DIR") or "/app/methods")
ARTIFACT = "main/allocator.py"                 # relative to /app/methods
METRIC = "mean_instance_score"
ANCHORS_PATH = TESTS / "anchors.json"
SCORER = TESTS / "score.py"
# per-record / per-window keys of the scorer's reward.json (hidden-set feedback): `score__DE_2019_01_28`,
# `cn-2018a__R_net`, `score_A01` -- reported in score_details.json, kept out of reward.json
_DETAIL_RE = re.compile(r"^[a-z_]+_[A-Z]\d{2,3}$")


def _is_detail(key: str) -> bool:
    return "__" in key or bool(_DETAIL_RE.match(key))


def _numeric(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(float(v))


def load_anchors() -> tuple[float | None, float | None, float | None]:
    """Read the DECLARED band while still root, then unlink it so the submission can never see it.

    The band is recorded in score_details.json and checked for order, but it never enters the score --
    normalisation is a batch-layer step (see the module docstring). Reading and unlinking still happens
    on every run: it is what keeps a sealed 0400 file from surviving into the submission's process.

    An unmeasured band (nulls) is NOT a grader failure. Measuring the band means running this grader, so
    the band is necessarily absent on the first build of a task; failing here would make that first run
    impossible. Neither is a MISSING file: the participant view the platform's clean-sandbox verify runs
    from excludes anchors.json on purpose -- it is organiser-side, and the agent can read tests/ there.
    What the band must not be is WRONG, and that is checked where it can be: the calibration matrix
    requires the starter and reference arms to reproduce the declared numbers exactly.
    """
    if not ANCHORS_PATH.exists():
        return None, None, None
    a = json.loads(ANCHORS_PATH.read_text())
    try:
        ANCHORS_PATH.unlink()
    except OSError:
        pass

    def num(x):
        return None if x is None else float(x)

    b, r, u = num(a.get("baseline")), num(a.get("reference")), num(a.get("upper"))
    if b is not None and u is not None:
        if not (b < u) or (r is not None and not (b < r < u)):
            raise ValueError(f"anchors out of order: baseline={b} reference={r} upper={u}")
    return b, r, u


def write_out(reward: float, extra: dict, details: dict) -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    payload = {"reward": round(float(reward), 6)}
    for k, v in extra.items():
        if _numeric(v):
            payload[k] = round(float(v), 6) if isinstance(v, float) else v
    (LOG_DIR / "reward.json").write_text(json.dumps(payload, indent=1, sort_keys=True))
    (LOG_DIR / "reward.txt").write_text(f"{payload['reward']}\n")
    (LOG_DIR / "score_details.json").write_text(json.dumps({"reward": payload, **details}, indent=1, default=str))
    print(json.dumps(payload, sort_keys=True))


def fail(msg: str) -> None:
    """Grader-side failure: reward 0 with a marker that keeps it apart from a submission that scored 0."""
    write_out(0.0, {"grader_failed": 1}, {"error": "grader failed: " + msg})
    print("grader failed:", msg, file=sys.stderr)
    sys.exit(0)


def main() -> None:
    t0 = time.time()
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    try:
        baseline, reference, upper = load_anchors()
    except Exception as exc:  # noqa: BLE001
        fail(f"cannot read the sealed anchors: {exc}")

    artifact = SUBMISSION / ARTIFACT
    if not artifact.exists():
        write_out(0.0, {"missing_artifact": 1},
                  {"error": f"the submission has no {ARTIFACT} under /app/methods -- nothing to evaluate"})
        return
    # the scorer's child process runs as uid 65534 and must be able to read (never write) the submission
    subprocess.run(["chmod", "-R", "a+rX", str(SUBMISSION)], check=False)

    env = dict(os.environ, HARBOR_VERIFIER_LOG_DIR=str(RAW_DIR), RSI_NO_HOME_ENV="1", PYTHONDONTWRITEBYTECODE="1")
    # The scorer runs with cwd=RAW_DIR, but rsi_common.hidden_dir() looks for the sealed pack's key at
    # <cwd>/.rsi_hidden_key -- and the platform writes it at the CLEAN-VERIFY cwd, which is ours, not the
    # child's. Resolve it here and hand it over explicitly, or a sealed pack reads as "no key available"
    # and the whole run becomes an apparatus fault instead of a score.
    if "RSI_HIDDEN_KEY" not in env and "RSI_HIDDEN_KEY_FILE" not in env:
        key_file = Path.cwd() / ".rsi_hidden_key"
        if key_file.exists():
            env["RSI_HIDDEN_KEY_FILE"] = str(key_file)
    cmd = [sys.executable, str(SCORER), "--split", "assessment", "--methods", str(SUBMISSION), "--log-dir", str(RAW_DIR)]
    with open(RAW_DIR / "scorer.log", "w") as fh:
        rc = subprocess.run(cmd, stdout=fh, stderr=subprocess.STDOUT, env=env, cwd=str(RAW_DIR)).returncode
    raw_path = RAW_DIR / "reward.json"
    if rc != 0 or not raw_path.exists():
        reason = f"scorer exited {rc}"
        err = RAW_DIR / "verifier_error.json"
        if err.exists():
            try:
                reason += ": " + str(json.loads(err.read_text()).get("apparatus_fault"))
            except Exception:  # noqa: BLE001
                pass
        fail(reason)
    try:
        raw = json.loads(raw_path.read_text())
        metric = float(raw["reward"])
        assert math.isfinite(metric)
    except Exception as exc:  # noqa: BLE001
        fail(f"scorer wrote an unreadable reward.json: {exc}")

    # the reward IS the raw metric: the single normalisation happens at the batch layer (see the docstring)
    aggregates = {k: v for k, v in raw.items() if k not in ("reward", "normalized") and not _is_detail(k) and _numeric(v)}
    per_record = {k: v for k, v in raw.items() if _is_detail(k)}
    note = (RAW_DIR / "verifier_note.txt").read_text() if (RAW_DIR / "verifier_note.txt").exists() else ""
    write_out(metric, {METRIC: metric, **aggregates},
              {"metric": METRIC, "raw_metric": metric,
               "normalization": "batch layer; the verifier reports the raw metric only",
               "declared_band": {"baseline": baseline, "reference": reference, "upper": upper,
                                 "note": "measured before any run; not applied here"},
               "per_record": per_record, "scorer_note": note, "scorer_rc": rc,
               "grader_wall_sec": round(time.time() - t0, 1)})
    print(f"{METRIC}={metric:.6f} reward={metric:.6f} (raw metric; declared band "
          f"baseline {baseline} / reference {reference} / upper {upper}, not applied)")


if __name__ == "__main__":
    main()
