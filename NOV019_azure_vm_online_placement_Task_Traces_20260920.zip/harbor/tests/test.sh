#!/usr/bin/env bash
# Verifier entry point. ONE script, TWO callers -- keep both working.
#
#   harbor, separate verifier image built from tests/  (what the buyer runs, and `harbor run -a oracle`)
#       cwd is /tests, the submission is re-materialised at /app/methods by the `artifacts` declaration,
#       HARBOR_VERIFIER_LOG_DIR and RSI_METHODS_DIR are unset -> the /logs/verifier and /app/methods defaults.
#
#   the Novix platform's clean-sandbox verify  (what produces the delivered hidden score)
#       It does NOT build this image. It starts a fresh container from the task's ENVIRONMENT image and runs
#           cd <ws>/harbor_run/<slug> && RSI_METHODS_DIR=$PWD/methods \
#           HARBOR_VERIFIER_LOG_DIR=$PWD/verify_clean/logs/verifier \
#           bash <ws>/.harbor_task/<slug>/tests/test.sh
#       so both paths arrive as environment, this script is not at /tests, and the sealed hidden pack is
#       opened with <cwd>/.rsi_hidden_key (rsi_common.hidden_dir handles that part).
#       Measured 2026-09-17: with /logs/verifier and /tests/grade.py hardcoded, that invocation writes its
#       score where the platform does not look, and the run is recorded as having produced none.
#
# Honouring HARBOR_VERIFIER_LOG_DIR is NOT a fail-open: the agent is gone by the time either caller runs,
# and the caller that sets it is the one that reads the result. What would be a fail-open is trusting a
# reward.json that was already there, so both callers get the same wipe below.
#
# grade.py does the work; this wrapper only guarantees a fail-closed outcome. Deliberately no `set -e`:
# the fallback below must still run when grade.py dies.
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOGDIR="${HARBOR_VERIFIER_LOG_DIR:-/logs/verifier}"
case "$LOGDIR" in
  /*) ;;
  *) echo "verifier: HARBOR_VERIFIER_LOG_DIR must be absolute, got '$LOGDIR'" >&2; exit 1 ;;
esac
export HARBOR_VERIFIER_LOG_DIR="$LOGDIR"
mkdir -p "$LOGDIR"
chmod 0755 "$LOGDIR" 2>/dev/null || true

# A reward file that merely EXISTS is never evidence of a score: wipe whatever the agent phase may have planted.
rm -f "$LOGDIR/reward.json" "$LOGDIR/reward.txt" "$LOGDIR/score_details.json"
rm -rf "$LOGDIR/raw"

python3 "$HERE/grade.py"
RC=$?

# Fail-closed: only a clean exit that produced reward.json counts. Anything else is a 0 with a numeric
# grader_failed flag (reward.json may hold finite numbers only: harbor validates it as dict[str, float|int]);
# the reason goes to score_details.json so a broken grader is never recorded as "the agent scored 0".
if [ "$RC" -ne 0 ] || [ ! -f "$LOGDIR/reward.json" ]; then
  python3 - "$RC" "$LOGDIR" <<'PY'
import json, os, sys
rc, log_dir = int(sys.argv[1]), sys.argv[2]
reason = f"grade.py exited {rc} without a usable reward.json"
try:
    err = json.load(open(os.path.join(log_dir, "raw", "verifier_error.json")))
    reason += ": " + str(err.get("apparatus_fault", err))[:600]
except Exception:
    pass
json.dump({"reward": 0.0, "grader_failed": 1}, open(os.path.join(log_dir, "reward.json"), "w"))
open(os.path.join(log_dir, "reward.txt"), "w").write("0\n")
json.dump({"error": "grader failed: " + reason},
          open(os.path.join(log_dir, "score_details.json"), "w"), indent=1)
print("grader failed:", reason)
PY
fi

cat "$LOGDIR/reward.txt"
exit "$RC"
