# VENDORED from demo-cases/rsi-exam/tools/opc/azure_vm_online_placement/pkg/simulate.py sha256=44fddb2c196e7e2b6a8c5193b7708ab7b3e43022999c9a6ad987c7469691f587 -- edit the canonical copy, then rerun build_task.py
"""Closed-loop replay of one trace window for azure_vm_online_placement (pure computation).

Imported by score.py (hidden split in the verifier image, practice split in selfcheck) -- one implementation, two
callers -- and by the organiser tools (anchors, calibration matrix, bounds).

An instance is ONE contiguous window of the Azure Trace for Packing 2020 with EVERY VM request that arrived in it,
in the trace's own order: warm-up hours followed by scored hours. The cluster starts empty at the window start.

Event loop (the parent holds the whole window; the candidate sees only the past):
  requests are grouped into decision batches = all requests with the same arrival second.
  for each batch at time t:
      every VM whose real end time is <= t departs first (capacity freed at its real end time; the cost clock runs
      event by event, so a server stops costing at the exact hour its last VM leaves);
      the candidate receives {t, departures since the last batch (vm, end time), the authoritative outcome of the
      previous batch, the batch's requests (vm, vm type, priority, tenant)} and returns one decision per request;
      each decision goes through ClusterState.apply() (cluster.py) -- a failed one is served on a new server of the
      cheapest compatible machine type and penalised;
  after the last batch the remaining departures inside the scored horizon are replayed with no further calls.

Cost of an instance (weighted server-hours; lower is better)
  server_cost   = integral over the SCORED hours of sum_{non-empty servers} weight[machine type]
  fail_penalty  = FAIL_PENALTY x failed placements (whole window: a failure in warm-up is still a failure)
  evict_penalty = EVICT_MULT x weight[m] x dominant share of the evicted VM on m x clip(its real remaining lifetime,
                  EVICT_MIN_H, EVICT_CAP_H) -- not clipped to the scored window, so evicting a VM that was about to
                  leave, or evicting near the end of the window, is not free
  cost_total    = server_cost + fail_penalty + evict_penalty

Candidate isolation: ONE child process per instance (uid 65534 when the verifier is root; entropy and clock
pinned; OMP/BLAS threads pinned to 1). Budgets are CPU seconds of the candidate's process group (threads and
subprocesses included, read from /proc): reset <= RESET_CPU, one decision batch <= BATCH_CPU, the whole instance <=
INSTANCE_CPU, and at most MAX_CORES cores on average (checked every SCAN_WALL_S of wall time and inside a slow call);
a wall-clock backstop of WALL_FACTOR x the budget catches a candidate that sleeps or blocks. A timeout, a crash or a
budget kill ends the process and every remaining request of the instance FAILS (the instance is still scored).
"""
from __future__ import annotations

import heapq
import json
import math
import os
import selectors
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Callable

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from cluster import ClusterState, Machines  # noqa: E402

FAIL_PENALTY = 24.0          # weighted server-hours per failed placement (one reference server-day)
EVICT_MULT = 2.0
EVICT_MIN_H = 1.0            # every eviction costs at least one hour of the evicted VM's share ...
EVICT_CAP_H = 24.0           # ... and at most its next 24 h, wherever the scored window ends
RESET_CPU = 120.0
BATCH_CPU = 10.0
INSTANCE_CPU = 1500.0
WALL_FACTOR = 3.0
SCAN_WALL_S = 2.0            # wall seconds between two full process-group CPU scans
MAX_CORES = 1.5              # the candidate gets one core; sustained use above this is killed
_UNPRIV_UID, _UNPRIV_GID = 65534, 65534


# ----------------------------------------------------------------------------
# instance I/O
# ----------------------------------------------------------------------------
def load_machines(path: Path) -> Machines:
    z = np.load(path)
    return Machines(z["demand"], z["weight"])


def load_instance(path: Path) -> dict[str, Any]:
    """npz with vm_type, priority, tenant, start_h, end_h (inf = alive past the trace), and a json meta string."""
    z = np.load(path, allow_pickle=False)
    meta = json.loads(str(z["meta"]))
    return {"meta": meta, "vm_type": z["vm_type"].astype(np.int64), "priority": z["priority"].astype(np.int64),
            "tenant": z["tenant"].astype(np.int64), "start_h": z["start_h"].astype(np.float64),
            "end_h": z["end_h"].astype(np.float64) if "end_h" in z.files else None}


def batches(start_h: np.ndarray) -> list[tuple[int, int]]:
    """[lo, hi) index ranges of equal arrival time (the trace is sorted by (start, vm id))."""
    if len(start_h) == 0:
        return []
    cut = np.flatnonzero(np.diff(start_h) != 0.0) + 1
    edges = np.concatenate([[0], cut, [len(start_h)]])
    return [(int(a), int(b)) for a, b in zip(edges[:-1], edges[1:])]


def public_cluster(machines_path: Path, inst: dict) -> dict:
    m = inst["meta"]
    return {"machines_file": str(machines_path),
            "instance": {k: m[k] for k in ("id", "t0_trace_day", "warmup_h", "horizon_h", "n_hours") if k in m},
            "fail_penalty": FAIL_PENALTY, "evict_mult": EVICT_MULT,
            "budgets_cpu_s": {"reset": RESET_CPU, "batch": BATCH_CPU, "instance": INSTANCE_CPU}}


# ----------------------------------------------------------------------------
# runners
# ----------------------------------------------------------------------------
class InProcessRunner:
    """Organiser tools only: the allocator in this process, fed through the same mirror logic. No isolation."""

    def __init__(self, factory: Callable[[], Any]):
        self.factory = factory
        self.mirror: Mirror | None = None
        self.used = 0.0
        self.alive = True

    def reset(self, cluster: dict) -> dict:
        try:
            self.mirror = Mirror(self.factory(), cluster)
            return {"ok": True}
        except Exception as exc:  # noqa: BLE001
            self.alive = False
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

    def step(self, msg: dict) -> dict:
        if not self.alive or self.mirror is None:
            return {"ok": False, "error": "allocator dead"}
        try:
            return {"ok": True, "value": self.mirror.step(msg)}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

    def close(self) -> None:
        pass


class Mirror:
    """The candidate-side half of the protocol (also embedded in the sandbox driver below, verbatim logic)."""

    def __init__(self, allocator: Any, cluster: dict):
        z = np.load(cluster["machines_file"])
        self.state = ClusterState(Machines(z["demand"], z["weight"]))
        self.pending: list[tuple] = []
        self.allocator = allocator
        allocator.reset(cluster)

    def step(self, msg: dict) -> list:
        st = self.state
        # 1. authoritative outcome of the previous batch: re-sync if the mirror disagrees
        for (vm, s, m, evicted), (pvm, ps, pev, ptype, pprio, pten, pt) in zip(msg.get("outcome") or [], self.pending):
            if vm != pvm:
                continue
            for v in evicted:
                if v in st.vm_server:
                    st.remove(v)
            while st.n_servers <= s:
                st.open_server(m)
            if st.vm_server.get(vm) != s:
                st.force(vm, ptype, pprio, pten, pt, s)
        self.pending = []
        # 2. departures (real end times) since the last batch
        for vm, _t_end in msg.get("departed") or []:
            if vm in st.vm_server:
                st.remove(vm)
        st.now = float(msg["t"])
        dep = msg.get("departed") or []
        if dep and hasattr(self.allocator, "observe_departures"):
            self.allocator.observe_departures(dep, st)
        # 3. the batch, one request at a time, each applied to the mirror before the next is asked
        out = []
        for vm, vt, pr, ten in msg["requests"]:
            req = {"vm": vm, "vm_type": vt, "priority": pr, "tenant": ten, "time": st.now}
            dec = self.allocator.place(req, st)
            if isinstance(dec, np.integer):
                dec = int(dec)
            s, _failed, ev, _reason = st.apply(vm, vt, pr, ten, st.now, dec)
            self.pending.append((vm, s, ev, vt, pr, ten, st.now))
            out.append(dec)
        return out


DRIVER = r'''
import json, os, sys, importlib.util, pathlib, traceback
pkg_dir, methods_dir, module_rel = sys.argv[1:4]
_proto_fd = os.dup(1)
os.dup2(2, 1)
_proto = os.fdopen(_proto_fd, "w", buffering=1)
sys.stdout = os.fdopen(1, "w", buffering=1)
import hashlib as _hashlib, itertools as _itertools
_ctr = _itertools.count()
def _det_urandom(size):
    out = b""
    while len(out) < size:
        out += _hashlib.sha256(b"rsi-urandom-%d" % next(_ctr)).digest()
    return out[:size]
os.urandom = _det_urandom
import random as _random
_random.seed(0); _random._urandom = _det_urandom
_orig_init = _random.Random.__init__
_random.Random.__init__ = lambda self, x=None: _orig_init(self, 0 if x is None else x)
import time as _time
_time.time = lambda: 1_700_000_000.0
_time.monotonic = lambda: 0.0
_time.perf_counter = lambda: 0.0
import numpy as _np
_np.random.seed(0)
_orig_rng = _np.random.default_rng
_np.random.default_rng = lambda seed=None: _orig_rng(0 if seed is None else seed)
sys.path.insert(0, pkg_dir)
from simulate import Mirror

def _jsonable(o):
    if hasattr(o, "tolist"):
        return o.tolist()
    if isinstance(o, _np.bool_):
        return bool(o)
    raise TypeError("not JSON serialisable: %s" % type(o).__name__)

def _send(msg):
    try:
        line = json.dumps(msg, default=_jsonable)
    except Exception as exc:
        line = json.dumps({"ok": False, "error": "decisions not JSON-serialisable: %s" % exc})
    _proto.write(line + "\n"); _proto.flush()

sys.path.insert(0, str(pathlib.Path(methods_dir) / pathlib.Path(module_rel).parent))
try:
    spec = importlib.util.spec_from_file_location("rsi_candidate", str(pathlib.Path(methods_dir) / module_rel))
    module = importlib.util.module_from_spec(spec)
    sys.modules["rsi_candidate"] = module
    spec.loader.exec_module(module)
except BaseException as exc:
    traceback.print_exc()
    _send({"ok": False, "error": "import failed: %s: %s" % (type(exc).__name__, exc)})
    sys.exit(0)
mirror = None
for line in sys.stdin:
    try:
        msg = json.loads(line)
    except Exception:
        continue
    op = msg.get("op")
    if op == "quit":
        break
    try:
        if op == "reset":
            cls = getattr(module, "Allocator", None)
            if cls is None:
                raise RuntimeError("allocator.py defines no Allocator class")
            mirror = Mirror(cls(), msg["cluster"])
            _send({"ok": True})
        elif op == "step":
            if mirror is None:
                raise RuntimeError("step before reset")
            _send({"ok": True, "value": mirror.step(msg)})
        else:
            _send({"ok": False, "error": "unknown op"})
    except BaseException as exc:
        traceback.print_exc()
        _send({"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)})
'''

_CLK_TCK = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100


def _stat_fields(pid: str) -> list[str] | None:
    try:
        with open(f"/proc/{pid}/stat", "rb") as f:
            raw = f.read().decode("ascii", "replace")
    except OSError:
        return None
    return raw[raw.rfind(")") + 2:].split()


def group_cpu_seconds(pgid: int) -> float:
    """utime+stime (+ reaped children's) of every live process in the process group, from /proc."""
    total = 0.0
    try:
        entries = os.listdir("/proc")
    except OSError:
        return 0.0
    for e in entries:
        if not e.isdigit():
            continue
        rest = _stat_fields(e)
        try:
            if rest is None or int(rest[2]) != pgid:
                continue
            total += (int(rest[11]) + int(rest[12]) + int(rest[13]) + int(rest[14])) / _CLK_TCK
        except (IndexError, ValueError):
            continue
    return total


def pid_cpu_seconds(pid: int) -> float | None:
    rest = _stat_fields(str(pid))
    if rest is None:
        return None
    try:
        return (int(rest[11]) + int(rest[12]) + int(rest[13]) + int(rest[14])) / _CLK_TCK
    except (IndexError, ValueError):
        return None


class SandboxRunner:
    """One de-privileged, entropy-pinned child process per instance in its own process group; messages over pipes;
    budgets in CPU seconds of the whole group."""

    def __init__(self, methods_dir: Path, module_rel: str = "main/allocator.py", stderr_path: Path | None = None,
                 reset_cpu: float = RESET_CPU, batch_cpu: float = BATCH_CPU, instance_cpu: float = INSTANCE_CPU):
        self.methods_dir = Path(methods_dir).resolve()
        self.module_rel = module_rel
        self.reset_cpu, self.batch_cpu, self.instance_cpu = reset_cpu, batch_cpu, instance_cpu
        self.used = 0.0
        self.alive = False
        self.last_error = ""
        self.n_calls = 0
        self.last_scan_wall = time.monotonic()
        self.last_scan_cpu = 0.0
        self.scratch = Path(tempfile.mkdtemp(prefix="rsi-vmp-"))
        pkg = self.scratch / "pkg"
        pkg.mkdir()
        for name in ("cluster.py", "simulate.py"):
            shutil.copy(HERE / name, pkg / name)
        driver = self.scratch / "driver.py"
        driver.write_text(DRIVER)
        env = {"PATH": os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin"),
               "PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0", "PYTHONUNBUFFERED": "1",
               "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
               "NUMEXPR_NUM_THREADS": "1", "HOME": str(self.scratch), "TMPDIR": str(self.scratch),
               "LANG": "C.UTF-8"}
        for k in ("VIRTUAL_ENV", "LD_LIBRARY_PATH"):
            if k in os.environ:
                env[k] = os.environ[k]
        if hasattr(os, "setuid") and os.getuid() == 0:
            def preexec() -> None:  # noqa: E306
                os.setsid()
                os.setgid(_UNPRIV_GID)
                os.setuid(_UNPRIV_UID)
            for p in [self.scratch, pkg]:
                os.chmod(p, 0o777)
            for p in list(pkg.iterdir()) + [driver]:
                os.chmod(p, 0o644)
        else:
            preexec = os.setsid
        self.stderr_fh = open(stderr_path, "ab") if stderr_path else open(os.devnull, "wb")
        try:
            self.proc = subprocess.Popen([sys.executable, str(driver), str(pkg), str(self.methods_dir), self.module_rel],
                                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.stderr_fh,
                                         cwd=str(self.scratch), env=env, preexec_fn=preexec, bufsize=0)
            self.alive = True
        except Exception as exc:  # noqa: BLE001
            self.last_error = f"cannot spawn candidate: {exc}"
        self.sel = selectors.DefaultSelector()
        if self.alive:
            self.sel.register(self.proc.stdout, selectors.EVENT_READ)
        self._buf = b""

    def _group_cpu(self) -> float:
        return group_cpu_seconds(self.proc.pid)

    def _scan(self) -> None:
        """Whole-process-group CPU, at most every SCAN_WALL_S of wall time: charges CPU burnt BETWEEN calls
        (background threads, child processes) and enforces the one-core rule."""
        now = time.monotonic()
        dt = now - self.last_scan_wall
        if dt < SCAN_WALL_S:
            return
        g = self._group_cpu()
        rate = (g - self.last_scan_cpu) / dt if dt > 0 else 0.0
        self.last_scan_wall, self.last_scan_cpu = now, g
        if g > self.used:
            self.used = g
        if rate > MAX_CORES:
            self.kill(f"candidate used {rate:.1f} cores over {dt:.1f}s (limit {MAX_CORES})")
        elif self.used > self.instance_cpu:
            self.kill(f"instance CPU budget exhausted ({self.used:.0f}s > {self.instance_cpu:.0f}s)")

    def _call(self, msg: dict, cpu_budget: float) -> dict[str, Any]:
        if not self.alive:
            return {"ok": False, "error": self.last_error or "candidate process is dead"}
        self._scan()
        if not self.alive:
            return {"ok": False, "error": self.last_error}
        remaining = self.instance_cpu - self.used
        budget = min(cpu_budget, remaining)
        if budget <= 0:
            self.kill(f"instance CPU budget exhausted ({self.used:.0f}s)")
            return {"ok": False, "error": self.last_error}
        self.n_calls += 1
        cpu0 = pid_cpu_seconds(self.proc.pid) or 0.0
        base = None                       # group-CPU baseline, taken only when a reply is slow
        t0 = time.monotonic()
        try:
            self.proc.stdin.write((json.dumps(msg) + "\n").encode())
            self.proc.stdin.flush()
        except Exception as exc:  # noqa: BLE001
            self.kill(f"candidate pipe broken: {exc}")
            return {"ok": False, "error": self.last_error}
        line, why = None, ""
        poll = 0.05
        while True:
            nl = self._buf.find(b"\n")
            if nl >= 0:
                line, self._buf = self._buf[:nl], self._buf[nl + 1:]
                break
            wall_used = time.monotonic() - t0
            if wall_used > 0.25:
                # a slow reply: account the WHOLE process group (threads, subprocesses) from here on
                g = self._group_cpu()
                if base is None:
                    base = g - max(0.0, (pid_cpu_seconds(self.proc.pid) or cpu0) - cpu0)
                cpu_used = g - base
                if cpu_used > budget:
                    why = f"CPU budget ({msg.get('op')} used {cpu_used:.1f}s > {budget:.1f}s)"
                    break
                if cpu_used > MAX_CORES * wall_used + 1.0:
                    why = f"{msg.get('op')} used {cpu_used:.1f} CPU-s in {wall_used:.1f}s wall (limit {MAX_CORES} cores)"
                    break
                if wall_used > WALL_FACTOR * budget:
                    why = f"wall-clock backstop ({msg.get('op')} {wall_used:.0f}s > {WALL_FACTOR:.0f} x {budget:.1f}s)"
                    break
                poll = 0.25
            events = self.sel.select(timeout=poll)
            if not events:
                if self.proc.poll() is not None:
                    why = "candidate process exited"
                    break
                continue
            chunk = os.read(self.proc.stdout.fileno(), 1 << 20)
            if not chunk:
                why = "candidate process exited"
                break
            self._buf += chunk
        if line is None:
            self.used += budget
            self.kill(f"candidate stopped: {why}; instance CPU used {self.used:.0f}s")
            return {"ok": False, "error": self.last_error}
        cpu1 = pid_cpu_seconds(self.proc.pid)
        self.used += max(0.0, (cpu1 if cpu1 is not None else cpu0) - cpu0)
        if self.used > self.instance_cpu:
            self.kill(f"instance CPU budget exhausted ({self.used:.0f}s > {self.instance_cpu:.0f}s)")
            return {"ok": False, "error": self.last_error}
        try:
            out = json.loads(line)
        except Exception:  # noqa: BLE001
            return {"ok": False, "error": "candidate reply unreadable"}
        if not isinstance(out, dict):
            return {"ok": False, "error": "candidate reply is not an object"}
        out.setdefault("ok", False)
        return out

    def reset(self, cluster: dict) -> dict[str, Any]:
        # the child runs as uid 65534 and must never be pointed into the (root-only) hidden directory
        cluster = dict(cluster)
        if self.alive:
            dst = self.scratch / "pkg" / "machines.npz"
            shutil.copy(cluster["machines_file"], dst)
            os.chmod(dst, 0o644)
            cluster["machines_file"] = str(dst)
        return self._call({"op": "reset", "cluster": cluster}, self.reset_cpu)

    def step(self, msg: dict) -> dict[str, Any]:
        return self._call(msg, self.batch_cpu)

    def final_cpu(self) -> float:
        if self.alive:
            try:
                total = self._group_cpu()
                if total > self.used:
                    self.used = total
            except Exception:  # noqa: BLE001
                pass
        return self.used

    def kill(self, reason: str) -> None:
        self.last_error = reason
        if self.alive:
            try:
                os.killpg(self.proc.pid, 9)
            except Exception:  # noqa: BLE001
                pass
            try:
                self.proc.kill()
            except Exception:  # noqa: BLE001
                pass
            self.alive = False

    def close(self) -> None:
        if self.alive:
            self.final_cpu()
            try:
                self.proc.stdin.write(b'{"op": "quit"}\n')
                self.proc.stdin.flush()
                self.proc.wait(timeout=5)
            except Exception:  # noqa: BLE001
                pass
            self.kill("closed")
        try:
            self.sel.close()
            self.stderr_fh.close()
        except Exception:  # noqa: BLE001
            pass
        shutil.rmtree(self.scratch, ignore_errors=True)


# ----------------------------------------------------------------------------
# the window replay
# ----------------------------------------------------------------------------
def run_instance(inst: dict, machines: Machines, machines_path: Path, runner: Any,
                 log: Callable[[str], None] | None = None, deadline: float | None = None) -> dict[str, Any]:
    """deadline: time.monotonic() value after which the candidate is stopped (the scorer's global wall-clock
    backstop); the rest of the instance is replayed with every remaining request failed."""
    meta = inst["meta"]
    vt_a, pr_a, tn_a, st_a, en_a = inst["vm_type"], inst["priority"], inst["tenant"], inst["start_h"], inst["end_h"]
    if en_a is None:
        raise RuntimeError("instance has no end times (verifier-side file expected)")
    n = len(vt_a)
    score_from = float(meta["warmup_h"])
    score_to = float(meta["warmup_h"]) + float(meta["horizon_h"])
    vt, pr, tn, st, en = vt_a.tolist(), pr_a.tolist(), tn_a.tolist(), st_a.tolist(), en_a.tolist()
    state = ClusterState(machines)
    w = machines.weight.tolist()
    dom = machines.demand.max(axis=2).tolist()
    led = {"id": meta["id"], "n_requests": n, "n_batches": 0, "server_cost": 0.0, "fail_penalty": 0.0,
           "evict_penalty": 0.0, "n_failed": 0, "n_evicted": 0, "n_failed_low": 0, "servers_opened": 0,
           "peak_open_servers": 0, "server_hours_unweighted": 0.0, "errors": [], "failure_reasons": {}}
    clock = [0.0]

    def advance(t: float) -> None:
        a, b = max(clock[0], score_from), min(t, score_to)
        if b > a:
            led["server_cost"] += state.open_weight * (b - a)
            led["server_hours_unweighted"] += state.n_open * (b - a)
        if t > clock[0]:
            clock[0] = t

    heap: list[tuple[float, int]] = []
    departed_msg: list[list] = []
    alive_end: dict[int, float] = {}

    def depart_until(t: float, inclusive: bool) -> None:
        while heap and (heap[0][0] <= t if inclusive else heap[0][0] < t):
            te, j = heapq.heappop(heap)
            if alive_end.get(j) != te:
                continue                       # evicted earlier: stale heap entry
            advance(te)
            del alive_end[j]
            state.remove(j)
            departed_msg.append([j, te])

    r = runner.reset(public_cluster(machines_path, inst))
    dead = not r.get("ok")
    if dead:
        led["errors"].append(f"reset: {r.get('error')}")
    prev_outcome: list[list] = []
    for lo, hi in batches(st_a):
        t = st[lo]
        depart_until(t, inclusive=True)
        advance(t)
        state.now = t
        reqs = [[i, vt[i], pr[i], tn[i]] for i in range(lo, hi)]
        decisions: list[Any] | None = None
        if not dead and deadline is not None and time.monotonic() > deadline:
            if hasattr(runner, "kill"):
                runner.kill("scorer wall-clock deadline reached")
            led["errors"].append(f"batch at t={t:.4f}h: scorer wall-clock deadline reached; remaining requests fail")
            dead = True
        if not dead:
            rep = runner.step({"op": "step", "t": t, "departed": departed_msg, "outcome": prev_outcome,
                               "requests": reqs})
            if rep.get("ok") and isinstance(rep.get("value"), list) and len(rep["value"]) == len(reqs):
                decisions = rep["value"]
            else:
                err = rep.get("error") or f"expected a list of {len(reqs)} decisions"
                if len(led["errors"]) < 20:
                    led["errors"].append(f"batch at t={t:.4f}h: {err}")
                if not getattr(runner, "alive", True):
                    dead = True
        departed_msg = []
        led["n_batches"] += 1
        prev_outcome = []
        for k, i in enumerate(range(lo, hi)):
            dec = decisions[k] if decisions is not None else None
            n_serv_before = state.n_servers
            s, failed, evicted, reason = state.apply(i, vt[i], pr[i], tn[i], t, dec)
            if state.n_servers > n_serv_before:
                led["servers_opened"] += 1
            for v in evicted:
                end_v = alive_end.pop(v)
                ms = int(state.server_type[s])
                rem = max(EVICT_MIN_H, min(end_v, t + EVICT_CAP_H) - t)
                led["evict_penalty"] += EVICT_MULT * w[ms] * dom[vt[v]][ms] * rem
                led["n_evicted"] += 1
                departed_msg.append([v, t])
            if failed:
                led["n_failed"] += 1
                led["fail_penalty"] += FAIL_PENALTY
                if pr[i]:
                    led["n_failed_low"] += 1
                key = (reason or "no decision").split(" (")[0][:60] if decisions is not None else "no decision (crash/timeout/bad reply)"
                led["failure_reasons"][key] = led["failure_reasons"].get(key, 0) + 1
            alive_end[i] = en[i]
            heapq.heappush(heap, (en[i], i))
            prev_outcome.append([i, s, int(state.server_type[s]), evicted])
            if state.n_open > led["peak_open_servers"]:
                led["peak_open_servers"] = state.n_open
    depart_until(score_to, inclusive=True)
    advance(score_to)
    if hasattr(runner, "final_cpu"):
        runner.final_cpu()
    led["cost_total"] = led["server_cost"] + led["fail_penalty"] + led["evict_penalty"]
    led["constraint_pass_rate"] = 1.0 - led["n_failed"] / max(1, n)
    led["candidate_cpu_seconds"] = float(getattr(runner, "used", 0.0))
    if log:
        log(f"{meta['id']}: cost {led['cost_total']:.1f} (servers {led['server_cost']:.1f}, fail {led['n_failed']}, "
            f"evict {led['n_evicted']}) cpu {led['candidate_cpu_seconds']:.1f}s")
    return led
