#!/usr/bin/env python3
"""Visible evaluator: the verifier's own scorer, fed the practice split.

    python3 /app/selfcheck.py                     # all practice instances (the only valid reading)
    python3 /app/selfcheck.py --ids P006          # a quick look at one window (NOT a valid reading)
    python3 /app/selfcheck.py --workers 2

Writes reward.json / verifier_note.txt / verifier_detail.json into /app/selfcheck_runs/<timestamp>/.
A reading is valid only if reward.json exists, n_instances == n_declared (the full practice split) and
n_failed == 0 unless you meant to fail placements.
"""
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
out = HERE / "selfcheck_runs" / time.strftime("%Y%m%d-%H%M%S")
out.mkdir(parents=True, exist_ok=True)
cmd = [sys.executable, str(HERE / "score.py"), "--split", "practice", "--methods", str(HERE / "methods"),
       "--log-dir", str(out), "--data-dir", str(HERE / "data" / "practice")] + sys.argv[1:]
rc = subprocess.call(cmd)
print(f"\nselfcheck artifacts in {out}")
sys.exit(rc)
