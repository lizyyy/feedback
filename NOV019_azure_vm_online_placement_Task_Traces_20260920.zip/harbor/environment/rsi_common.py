# VENDORED from demo-cases/rsi-exam/lib/rsi_common.py sha256=079c97222ac9ee61ef1375e3ffe7438520118a41b281bd33e0b060abd116668b -- edit the canonical copy, then rerun build_task.py
"""Shared verifier primitives for the RSI-Exam sample tasks.

Vendored into every task package by ``tools/vendor_rsi_common.py`` — a harbor
task directory must be self-contained, so tasks import the vendored copy
(``tests/rsi_common.py`` for the verifier, ``environment/app/rsi_common.py``
for the selfcheck).  Edit ONLY the canonical copy in demo-cases/rsi-exam/lib.

Contents
--------
* two exit paths for a verifier: ``scored()`` writes reward.json (a 0.0 here is a
  real reading); ``apparatus()`` writes verifier_error.json, deletes any
  reward.json, and exits non-zero (the platform reads this as "could not
  evaluate", never as a score).
* RSI three-point normalisation: starter -> 0.0, reference -> 0.6, upper -> 1.0.
* frozen-manifest checks (status == "frozen", sha256 of every listed file).
* ``call_candidate``: run the agent's code in a separate, de-privileged,
  entropy-pinned child process and bring back only its return value (adapted
  from frontier-eng's verification/sandbox.py; the rationale for every pin is
  measured, not theoretical — see that file's history).
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

REWARD_KEY = "reward"
_UNPRIVILEGED_UID = 65534
_UNPRIVILEGED_GID = 65534


# ----------------------------------------------------------------------------
# verifier exit paths
# ----------------------------------------------------------------------------
def log_dir() -> Path:
    d = Path(os.environ.get("HARBOR_VERIFIER_LOG_DIR", "/logs/verifier"))
    d.mkdir(parents=True, exist_ok=True)
    return d


def _numeric(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(float(v))


def scored(reward: float, diag: dict[str, Any] | None = None, note: str = "",
           extra_json: dict[str, Any] | None = None) -> Path:
    """Write reward.json (numbers only) and a human note; return the path.

    Any non-numeric or non-finite diagnostic value is dropped into the note
    instead of the JSON — harbor validates reward.json as dict[str, float|int]
    and one string value turns the whole trial into a ValidationError.
    """
    d = log_dir()
    payload: dict[str, float] = {}
    dropped: list[str] = []
    for k, v in {REWARD_KEY: reward, **(diag or {})}.items():
        if _numeric(v):
            payload[k] = float(v) if isinstance(v, float) else v
        else:
            dropped.append(f"{k}={v!r}")
    if not _numeric(payload.get(REWARD_KEY)):
        apparatus(f"reward is not a finite number: {reward!r}")
    if hidden_key_available():
        # clean-sandbox mode: the worktree is readable by every later run of the track (shared live workspace),
        # so per-record hidden-set scores must not stay in plaintext. reward.json keeps aggregates only; the
        # per-record keys go to reward_detail.json, which seal_verifier_logs() folds into verifier_logs.enc.
        detail = {k: v for k, v in payload.items() if is_detail_key(k)}
        if detail:
            (d / "reward_detail.json").write_text(json.dumps(detail, indent=1, sort_keys=True))
            payload = {k: v for k, v in payload.items() if k not in detail}
            payload["n_detail_keys_sealed"] = len(detail)
    (d / "reward.json").write_text(json.dumps(payload, indent=1, sort_keys=True))
    lines = [note] if note else []
    if dropped:
        lines.append("non-numeric diagnostics kept out of reward.json: " + ", ".join(dropped))
    (d / "verifier_note.txt").write_text("\n".join(lines) + "\n")
    if extra_json:
        (d / "verifier_detail.json").write_text(json.dumps(extra_json, indent=1, default=str))
    print(json.dumps(payload, sort_keys=True))
    return d / "reward.json"


def apparatus(reason: str) -> None:
    """The evaluation could NOT run. No reward.json, non-zero exit."""
    d = log_dir()
    (d / "reward.json").unlink(missing_ok=True)
    (d / "verifier_error.json").write_text(json.dumps({"apparatus_fault": reason}, indent=1, ensure_ascii=False))
    print(f"verifier: APPARATUS FAULT — {reason}", file=sys.stderr)
    sys.exit(1)


# ----------------------------------------------------------------------------
# RSI three-point normalisation
# ----------------------------------------------------------------------------
def normalize(raw: float, starter: float, reference: float | None, upper: float,
              direction: str = "maximize") -> float:
    """Map a raw metric onto RSI's scale: starter=0.0, reference=0.6, upper=1.0.

    Piecewise linear, clipped to [0, 1]. With no reference the map is linear
    starter -> 0, upper -> 1. ``direction="minimize"`` flips the axis.
    """
    s, u = float(starter), float(upper)
    r = None if reference is None else float(reference)
    x = float(raw)
    if direction == "minimize":
        s, u, x = -s, -u, -x
        r = None if r is None else -r
    if u == s:
        return 0.0
    if r is None or r <= s or r >= u:
        return max(0.0, min(1.0, (x - s) / (u - s)))
    if x <= r:
        return max(0.0, 0.6 * (x - s) / (r - s))
    return min(1.0, 0.6 + 0.4 * (x - r) / (u - r))


# ----------------------------------------------------------------------------
# frozen manifest
# ----------------------------------------------------------------------------
def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_frozen(heldout_path: Path, verify_files: bool = True) -> dict[str, Any]:
    """Read tests/heldout.json; apparatus-fault unless status == "frozen".

    If the manifest carries ``files: {relpath: sha256}`` every file is hashed
    and compared — a hidden set that drifted after freezing must fail loudly.
    """
    try:
        man = json.loads(Path(heldout_path).read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        apparatus(f"cannot read {heldout_path}: {exc}")
    if man.get("status") != "frozen":
        apparatus(f"heldout status is {man.get('status')!r}, not 'frozen'")
    if verify_files:
        base = Path(heldout_path).parent
        for rel, digest in (man.get("files") or {}).items():
            p = base / rel
            if not p.exists():
                apparatus(f"frozen file missing: {rel}")
            got = sha256_file(p)
            if got != digest:
                apparatus(f"frozen file drifted: {rel} sha256 {got[:12]} != {digest[:12]}")
    return man


# ----------------------------------------------------------------------------
# candidate isolation (adapted from frontier-eng verification/sandbox.py)
# ----------------------------------------------------------------------------
DRIVER = r'''
import json, os, sys, importlib.util, pathlib
task_dir, module_rel, entry, args_path, out_path = sys.argv[1:6]
sys.path.insert(0, task_dir)
spec = importlib.util.spec_from_file_location("rsi_candidate", str(pathlib.Path(task_dir) / module_rel))
module = importlib.util.module_from_spec(spec)

import hashlib as _hashlib, itertools as _itertools
_ctr = _itertools.count()
def _det_urandom(size):
    out = b""
    while len(out) < size:
        out += _hashlib.sha256(b"rsi-urandom-%d" % next(_ctr)).digest()
    return out[:size]
os.urandom = _det_urandom
import random as _random
_random.seed(0); _random._urandom = _det_urandom
_orig_init = _random.Random.__init__
_random.Random.__init__ = lambda self, x=None: _orig_init(self, 0 if x is None else x)
import time as _time
_time.time = lambda: 1_700_000_000.0
_time.monotonic = lambda: 0.0
_time.perf_counter = lambda: 0.0
try:
    import numpy as _np
    _np.random.seed(0)
    _orig_rng = _np.random.default_rng
    _np.random.default_rng = lambda seed=None: _orig_rng(0 if seed is None else seed)
except Exception:
    pass

result = {"ok": False, "error": "driver did not run"}
try:
    spec.loader.exec_module(module)
    fn = getattr(module, entry, None)
    if fn is None:
        result = {"ok": False, "error": f"{module_rel} defines no {entry}()"}
    else:
        args = json.loads(pathlib.Path(args_path).read_text())
        value = fn(*args)
        result = {"ok": True, "value": value}
except BaseException as exc:
    result = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
try:
    pathlib.Path(out_path).write_text(json.dumps(result, default=str))
except Exception:
    pass
'''


def call_candidate(task_dir: Path, module_rel: str, entry: str,
                   args: list[Any] | None = None, timeout: int = 900,
                   env_extra: dict[str, str] | None = None,
                   memory_mb: int | None = None) -> dict[str, Any]:
    """Call ``entry(*args)`` from ``task_dir/module_rel`` in a child process.

    Returns {"ok": True, "value": ...} or {"ok": False, "error": "..."}.
    Crash / hang / exit / unreadable output are all a failed candidate, never
    an exception in the scorer. Args and the result travel through files whose
    paths THIS process chooses; the child's stdout is not a result channel.
    """
    scratch = Path(tempfile.mkdtemp(prefix="rsi-cand-"))
    try:
        args_path = scratch / "args.json"
        args_path.write_text(json.dumps(args or [], default=str))
        out_path = scratch / "result.json"
        driver = scratch / "driver.py"
        driver.write_text(DRIVER)
        env = dict(os.environ)
        env.update(env_extra or {})
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["PYTHONHASHSEED"] = "0"
        env.setdefault("OMP_NUM_THREADS", "2")
        preexec = None
        if hasattr(os, "setuid") and os.getuid() == 0:
            def preexec() -> None:  # noqa: E306
                if memory_mb:
                    try:
                        import resource
                        lim = memory_mb * 1024 * 1024
                        resource.setrlimit(resource.RLIMIT_AS, (lim, lim))
                    except Exception:
                        pass
                os.setgid(_UNPRIVILEGED_GID)
                os.setuid(_UNPRIVILEGED_UID)
            os.chmod(scratch, 0o777)
        try:
            subprocess.run([sys.executable, str(driver), str(task_dir), module_rel, entry,
                            str(args_path), str(out_path)],
                           capture_output=True, text=True, timeout=timeout, check=False,
                           env=env, cwd=str(scratch), preexec_fn=preexec)
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": f"candidate timed out after {timeout}s"}
        if not out_path.exists():
            return {"ok": False, "error": "candidate produced no result (crashed or exited)"}
        try:
            return json.loads(out_path.read_text())
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": f"candidate result unreadable: {exc}"}
    finally:
        shutil.rmtree(scratch, ignore_errors=True)


def finite_list(x: Any, n: int | None = None) -> list[float] | None:
    """Coerce to a list of finite floats (length n if given) or None."""
    try:
        vals = [float(v) for v in list(x)]
    except Exception:  # noqa: BLE001
        return None
    if n is not None and len(vals) != n:
        return None
    if not all(math.isfinite(v) for v in vals):
        return None
    return vals


# ----------------------------------------------------------------------------
# sealed hidden pack (live mode)
# ----------------------------------------------------------------------------
# On the discovery engine the task package is mounted read-only in EVERY sandbox
# of the track (experiment and verifier alike), so a plaintext tests/hidden/ is
# readable by the agent under test (measured: the smoke agent read
# solution/reference and listed tests/hidden). The publish step therefore ships
# tests/hidden.enc + a participant view without solution/ or tests/hidden/, and the
# clean-verify run alone receives the per-task key (backend-derived, delivered
# through a file the platform writes into the verify run's own worktree right
# before dispatch and removes at its terminal). Stdlib-only: SHA-256 counter-mode
# keystream + HMAC-SHA256 over the ciphertext. Adequate against an agent inside
# our own platform; not a substitute for real crypto against external adversaries.
import hmac as _hmac
import io as _io
import tarfile as _tarfile

_SEAL_MAGIC = b"RSISEAL1"


def _keystream(key: bytes, nonce: bytes, n: int) -> bytes:
    out = bytearray()
    ctr = 0
    while len(out) < n:
        out += hashlib.sha256(key + nonce + ctr.to_bytes(8, "big")).digest()
        ctr += 1
    return bytes(out[:n])


def seal_bytes(plain: bytes, key_hex: str) -> bytes:
    key = bytes.fromhex(key_hex)
    nonce = hashlib.sha256(b"nonce" + key + str(len(plain)).encode() + plain[:64]).digest()[:16]
    ct = bytes(a ^ b for a, b in zip(plain, _keystream(key, nonce, len(plain))))
    mac = _hmac.new(key, nonce + ct, hashlib.sha256).digest()
    return _SEAL_MAGIC + nonce + mac + ct


def open_bytes(sealed: bytes, key_hex: str) -> bytes:
    if not sealed.startswith(_SEAL_MAGIC):
        raise ValueError("not a sealed pack")
    key = bytes.fromhex(key_hex)
    nonce, mac, ct = sealed[8:24], sealed[24:56], sealed[56:]
    if not _hmac.compare_digest(mac, _hmac.new(key, nonce + ct, hashlib.sha256).digest()):
        raise ValueError("sealed pack: wrong key or corrupted")
    return bytes(a ^ b for a, b in zip(ct, _keystream(key, nonce, len(ct))))


def seal_dir(src_dir: Path, out_path: Path, key_hex: str) -> None:
    buf = _io.BytesIO()
    with _tarfile.open(fileobj=buf, mode="w:gz") as tf:
        for p in sorted(Path(src_dir).rglob("*")):
            if p.is_file():
                tf.add(p, arcname=str(p.relative_to(src_dir)))
    Path(out_path).write_bytes(seal_bytes(buf.getvalue(), key_hex))


def open_dir(sealed_path: Path, dst_dir: Path, key_hex: str) -> Path:
    data = open_bytes(Path(sealed_path).read_bytes(), key_hex)
    dst = Path(dst_dir)
    dst.mkdir(parents=True, exist_ok=True)
    with _tarfile.open(fileobj=_io.BytesIO(data), mode="r:gz") as tf:
        tf.extractall(dst)
    return dst


def hidden_dir(tests_dir: Path) -> Path:
    """Resolve the hidden data directory for a verifier run.

    Order: plaintext ``tests/hidden/`` (harbor-native / organizer runs) → sealed
    ``tests/hidden.enc`` opened with the key from ``$RSI_HIDDEN_KEY`` or
    ``$RSI_HIDDEN_KEY_FILE`` (default ``$PWD/.rsi_hidden_key`` at the worktree root, written by
    the platform right before the clean-verify run and removed at its terminal). Anything else is an apparatus
    fault — never a score.
    """
    tests_dir = Path(tests_dir)
    plain = tests_dir / "hidden"
    if plain.is_dir() and any(plain.iterdir()):
        return plain
    sealed = tests_dir / "hidden.enc"
    if not sealed.exists():
        apparatus(f"no hidden data: neither {plain} nor {sealed} exists")
    key = os.environ.get("RSI_HIDDEN_KEY", "").strip()
    if not key:
        kf = Path(os.environ.get("RSI_HIDDEN_KEY_FILE") or (Path.cwd() / ".rsi_hidden_key"))
        if kf.exists():
            key = kf.read_text().strip()
    if not key:
        apparatus("hidden pack is sealed and no RSI_HIDDEN_KEY / .rsi_hidden_key is available in this run "
                  "(only the platform's clean-sandbox verify receives it)")
    out = Path(tempfile.mkdtemp(prefix="rsi-hidden-"))
    try:
        open_dir(sealed, out, key)
    except Exception as exc:  # noqa: BLE001
        apparatus(f"cannot open sealed hidden pack: {exc}")
    return out



_DETAIL_RE = re.compile(r"^[a-z_]+_[A-Z]\d{2,3}$")            # wind-style per-record keys: score_A01 ...


def is_detail_key(key: str) -> bool:
    """Per-record / per-window diagnostic key (hidden-set feedback) vs an aggregate.
    Convention across the RSI tasks: per-record keys carry a `__<record id>` segment (grid `score__DE_2019_01_28`,
    portfolio `cn-2018a__R_net`) or a `_<ID>` suffix like `score_A01` (wind)."""
    return "__" in key or bool(_DETAIL_RE.match(key))


def hidden_key_available() -> str | None:
    """The clean-sandbox verify is the only run that holds the hidden-pack key (env or <worktree>/.rsi_hidden_key)."""
    k = os.environ.get("RSI_HIDDEN_KEY", "").strip()
    if k:
        return k
    kf = Path(os.environ.get("RSI_HIDDEN_KEY_FILE") or (Path.cwd() / ".rsi_hidden_key"))
    try:
        k = kf.read_text().strip()
    except OSError:
        return None
    return k or None


def seal_verifier_logs(log_dir: Path, keep: tuple[str, ...] = ("reward.json", "verifier_error.json")) -> Path | None:
    """In clean-sandbox mode, fold everything in the verifier log dir except `keep` into verifier_logs.enc
    (sealed with the hidden-pack key) and delete the plaintext. No key -> no-op (organizer/local runs keep
    plaintext). Measured need (2026-09-02, rsi-grid-dispatch-mpc p210): a later run read three earlier runs'
    verify_clean/logs/verifier/verifier_detail.json — per-record hidden scores — through the shared workspace."""
    key = hidden_key_available()
    if not key:
        return None
    log_dir = Path(log_dir)
    files = [p for p in sorted(log_dir.rglob("*")) if p.is_file() and p.name not in keep and p.name != "verifier_logs.enc"]
    if not files:
        return None
    import io, tarfile
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w") as tf:
        for p in files:
            tf.add(p, arcname=str(p.relative_to(log_dir)))
    out = log_dir / "verifier_logs.enc"
    out.write_bytes(seal_bytes(buf.getvalue(), key))
    for p in files:
        p.unlink()
    for dp in sorted((p for p in log_dir.rglob("*") if p.is_dir()), reverse=True):
        try:
            dp.rmdir()
        except OSError:
            pass
    return out


def open_verifier_logs(sealed: Path, dst_dir: Path, key_hex: str) -> Path:
    """Organizer side: unpack verifier_logs.enc (see seal_verifier_logs)."""
    import io, tarfile
    data = open_bytes(Path(sealed).read_bytes(), key_hex)
    dst_dir = Path(dst_dir); dst_dir.mkdir(parents=True, exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(data), mode="r") as tf:
        tf.extractall(dst_dir)
    return dst_dir


def derive_key(secret: str, slug: str) -> str:
    """Per-task key = HMAC-SHA256(secret, slug), hex. Same derivation as the backend."""
    return _hmac.new(secret.encode(), slug.encode(), hashlib.sha256).hexdigest()


if __name__ == "__main__":  # tiny CLI for the publish step
    import argparse
    ap = argparse.ArgumentParser(description="seal/open a hidden pack")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s1 = sub.add_parser("seal"); s1.add_argument("src_dir"); s1.add_argument("out"); s1.add_argument("--key", required=True)
    s2 = sub.add_parser("open"); s2.add_argument("sealed"); s2.add_argument("dst"); s2.add_argument("--key", required=True)
    s3 = sub.add_parser("derive"); s3.add_argument("slug"); s3.add_argument("--secret-file", required=True)
    s4 = sub.add_parser("seal-logs"); s4.add_argument("log_dir")
    s5 = sub.add_parser("open-logs"); s5.add_argument("sealed"); s5.add_argument("dst"); s5.add_argument("--key", required=True)
    a = ap.parse_args()
    if a.cmd == "seal":
        seal_dir(Path(a.src_dir), Path(a.out), a.key); print("sealed ->", a.out)
    elif a.cmd == "open":
        print("opened ->", open_dir(Path(a.sealed), Path(a.dst), a.key))
    elif a.cmd == "seal-logs":
        out = seal_verifier_logs(Path(a.log_dir)); print("sealed logs ->", out if out else "(no key: left in plaintext)")
    elif a.cmd == "open-logs":
        print("opened logs ->", open_verifier_logs(Path(a.sealed), Path(a.dst), a.key))
    else:
        print(derive_key(Path(a.secret_file).read_text().strip(), a.slug))
