# Experiment log

| version | what changed | practice reward (7/7 instances) | note |
|---|---|---|---|
| v0 | starter as shipped | 0.000000 by construction | first fit, cheapest machine type for new servers |
