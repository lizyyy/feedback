"""Starter allocator: first fit.

What a simple cluster allocator does: walk the non-empty servers in the order they were opened and put the VM on the
first one whose machine type can run it and that still has room in every dimension. If none has room, open a new
server of the machine type on which this VM type is cheapest (weight x dominant share).

It ignores lifetimes, priorities, tenants, how full a server already is, and which machine type suits the VM mix.
"""
import numpy as np


class Allocator:
    def reset(self, cluster):
        """cluster: machines_file, instance {id, t0_trace_day, warmup_h, horizon_h, n_hours}, penalties, budgets."""
        self.cluster = cluster

    def place(self, request, state):
        """request: {vm, vm_type, priority, tenant, time}; state: cluster.ClusterState (read it, do not modify it)."""
        t = request["vm_type"]
        n = state.n_servers
        if n:
            ok = state.fits_mask(t) & (state.n_vms[:n] > 0)
            k = int(ok.argmax())
            if ok[k]:
                return k
        return f"new:{int(state.machines.cheapest[t])}"
