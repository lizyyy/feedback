Snapshot every measured version here as v<N>/ before you change it again.
