# VENDORED from demo-cases/rsi-exam/tools/opc/azure_vm_online_placement/pkg/cluster.py sha256=d407c536d33a3754db25f9abb55acf53e47408bab0476bea335f0eac330e37a5 -- edit the canonical copy, then rerun build_task.py
"""Cluster state and placement rules for azure_vm_online_placement (pure computation, numpy only).

ONE implementation, three users:
  * the verifier's closed-loop engine (simulate.py) keeps the AUTHORITATIVE ClusterState and applies every decision
    through ClusterState.apply();
  * the candidate's child process keeps a MIRROR ClusterState, built by the same driver code from the same messages,
    and hands it to Allocator.place() as `state`;
  * organiser tools (reference, bounds, calibration arms) use it in-process.
Because both sides run the same deterministic code on the same event order, the mirror equals the authority unless
the candidate mutates it; the verifier re-sends the authoritative outcome of every batch and the driver re-syncs.

Units
  resources  -- fraction of ONE machine of that machine type, per dimension (core, memory, hdd, ssd, nic); a server's
                capacity is 1.0 in every dimension. A VM type has a demand vector only for the machine types it can run
                on (NaN elsewhere = incompatible). hdd is NULL in the trace for most (type, machine) pairs: that VM type
                reserves no hdd there, so NULL hdd -> 0.0 when the pair itself exists.
  time       -- hours since the instance start.
  cost       -- weighted server-hours: a non-empty server of machine type m costs weight[m] per hour.

Decisions (what Allocator.place returns for one request)
  int s                          -- put the VM on existing server s (an empty server may be reused: it re-opens)
  "new:<m>"                      -- open a new server of machine type m and put the VM on it
  {"server": s, "evict": [...]}  -- HIGH-priority request only: first evict the listed LOW-priority VMs, which must
                                    all be on server s, then put the VM on s
Anything else, or a decision that breaks a rule (incompatible machine type, any dimension over 1.0, unknown server,
eviction of a VM that is not low-priority / not on s / by a low-priority request), is a FAILED placement: the VM is
served on a new server of its cheapest compatible machine type and the failure is penalised.
"""
from __future__ import annotations

import math
from typing import Any

import numpy as np

DIMS = ("core", "memory", "hdd", "ssd", "nic")
EPS = 1e-9


class Machines:
    """demand[t, m, k] (NaN where VM type t cannot run on machine type m), weight[m]."""

    def __init__(self, demand: Any, weight: Any):
        self.raw = np.asarray(demand, dtype=np.float64)
        self.weight = np.asarray(weight, dtype=np.float64)
        self.n_types, self.n_machines, nd = self.raw.shape
        assert nd == len(DIMS) and self.weight.shape == (self.n_machines,)
        self.compatible = ~np.isnan(self.raw[:, :, 0])
        self.demand = np.where(self.compatible[:, :, None], np.nan_to_num(self.raw, nan=0.0), 0.0)
        # dominant-share cost of hosting one VM of type t on machine m, and the cheapest machine type per VM type
        dom = self.demand.max(axis=2)
        self.dom_cost = np.where(self.compatible, self.weight[None, :] * dom, np.inf)
        self.cheapest = np.argmin(self.dom_cost, axis=1).astype(np.int64)
        self._dl = self.demand.tolist()

    def d(self, vm_type: int, m: int) -> list[float]:
        return self._dl[vm_type][m]


class ClusterState:
    """Servers and the VMs on them. Arrays are sized to capacity; the first n_servers rows are live."""

    def __init__(self, machines: Machines, capacity: int = 4096):
        self.machines = machines
        self.cap = capacity
        self.server_type = np.zeros(capacity, dtype=np.int32)
        self.used = np.zeros((capacity, len(DIMS)), dtype=np.float64)
        self.n_vms = np.zeros(capacity, dtype=np.int32)
        self.n_low = np.zeros(capacity, dtype=np.int32)
        self.n_servers = 0
        self.server_vms: list[set] = []
        self.vm_server: dict[int, int] = {}
        self.vm_type: dict[int, int] = {}
        self.vm_priority: dict[int, int] = {}
        self.vm_tenant: dict[int, int] = {}
        self.vm_start: dict[int, float] = {}
        self.now = 0.0
        self.open_weight = 0.0          # sum of weight over non-empty servers (the current cost rate)
        self.n_open = 0                 # number of non-empty servers

    # ---------------------------------------------------------------- helpers for allocators
    def fits_mask(self, vm_type: int) -> np.ndarray:
        """bool[n_servers]: compatible machine type, non-empty or empty, and every dimension fits."""
        n = self.n_servers
        mt = self.server_type[:n]
        d = self.machines.demand[vm_type][mt]
        return self.machines.compatible[vm_type][mt] & ((self.used[:n] + d) <= 1.0 + EPS).all(axis=1)

    def is_open(self) -> np.ndarray:
        return self.n_vms[: self.n_servers] > 0

    # ---------------------------------------------------------------- mutation
    def _grow(self) -> None:
        cap = self.cap * 2
        for name in ("server_type", "n_vms", "n_low"):
            a = getattr(self, name)
            b = np.zeros(cap, dtype=a.dtype)
            b[: self.cap] = a
            setattr(self, name, b)
        u = np.zeros((cap, len(DIMS)), dtype=np.float64)
        u[: self.cap] = self.used
        self.used = u
        self.cap = cap

    def open_server(self, m: int) -> int:
        if self.n_servers == self.cap:
            self._grow()
        s = self.n_servers
        self.server_type[s] = m
        self.used[s] = 0.0
        self.n_vms[s] = 0
        self.n_low[s] = 0
        self.server_vms.append(set())
        self.n_servers += 1
        return s

    def _add(self, vm: int, vm_type: int, priority: int, tenant: int, t: float, s: int) -> None:
        m = int(self.server_type[s])
        d = self.machines.d(vm_type, m)
        row = self.used[s]
        row += d
        if self.n_vms[s] == 0:
            self.open_weight += float(self.machines.weight[m])
            self.n_open += 1
        self.n_vms[s] += 1
        if priority:
            self.n_low[s] += 1
        self.server_vms[s].add(vm)
        self.vm_server[vm] = s
        self.vm_type[vm] = vm_type
        self.vm_priority[vm] = priority
        self.vm_tenant[vm] = tenant
        self.vm_start[vm] = t

    def remove(self, vm: int) -> int:
        """Departure or eviction. Returns the server it left."""
        s = self.vm_server.pop(vm)
        vt = self.vm_type.pop(vm)
        pr = self.vm_priority.pop(vm)
        self.vm_tenant.pop(vm, None)
        self.vm_start.pop(vm, None)
        m = int(self.server_type[s])
        self.n_vms[s] -= 1
        if pr:
            self.n_low[s] -= 1
        self.server_vms[s].discard(vm)
        if self.n_vms[s] == 0:
            self.used[s] = 0.0          # exact zero: no float drift survives an empty server
            self.open_weight -= float(self.machines.weight[m])
            self.n_open -= 1
            if self.n_open == 0:
                self.open_weight = 0.0
        else:
            self.used[s] -= self.machines.d(vt, m)
        return s

    # ---------------------------------------------------------------- the rule
    def check(self, vm_type: int, priority: int, decision: Any) -> tuple[str | None, int, int, list[int]]:
        """Validate a decision WITHOUT mutating. Returns (reason_or_None, server or -1, new machine type or -1, evict)."""
        evict: list[int] = []
        target = decision
        if isinstance(decision, dict):
            if set(decision) - {"server", "evict"} or "server" not in decision:
                return "dict decision needs exactly 'server' and optional 'evict'", -1, -1, []
            target = decision["server"]
            ev = decision.get("evict") or []
            if not isinstance(ev, (list, tuple)):
                return "evict must be a list of vm ids", -1, -1, []
            try:
                evict = [int(x) for x in ev]
            except Exception:  # noqa: BLE001
                return "evict ids must be integers", -1, -1, []
            if any(isinstance(x, bool) for x in ev):
                return "evict ids must be integers", -1, -1, []
        n_mach = self.machines.n_machines
        if isinstance(target, str):
            if evict:
                return "evictions only apply to an existing server", -1, -1, []
            if not target.startswith("new:"):
                return f"unknown decision string {target[:40]!r}", -1, -1, []
            try:
                m = int(target[4:])
            except ValueError:
                return f"bad machine type in {target[:40]!r}", -1, -1, []
            if not (0 <= m < n_mach):
                return f"machine type {m} out of range", -1, -1, []
            if not self.machines.compatible[vm_type, m]:
                return f"vm type {vm_type} cannot run on machine type {m}", -1, -1, []
            return None, -1, m, []
        if isinstance(target, bool) or not isinstance(target, (int, np.integer)):
            if isinstance(target, float) and math.isfinite(target) and float(target).is_integer():
                target = int(target)
            else:
                return f"decision of type {type(target).__name__} is not a server id", -1, -1, []
        s = int(target)
        if not (0 <= s < self.n_servers):
            return f"server {s} does not exist", -1, -1, []
        m = int(self.server_type[s])
        if not self.machines.compatible[vm_type, m]:
            return f"vm type {vm_type} cannot run on machine type {m} (server {s})", -1, -1, []
        d = self.machines.d(vm_type, m)
        row = self.used[s].tolist()
        if evict:
            if priority != 0:
                return "only a high-priority request may evict", -1, -1, []
            if len(set(evict)) != len(evict):
                return "duplicate vm in evict", -1, -1, []
            for v in evict:
                if self.vm_server.get(v) != s:
                    return f"vm {v} is not on server {s}", -1, -1, []
                if self.vm_priority.get(v) != 1:
                    return f"vm {v} is not low-priority", -1, -1, []
                dv = self.machines.d(self.vm_type[v], m)
                for k in range(len(DIMS)):
                    row[k] -= dv[k]
        for k in range(len(DIMS)):
            if row[k] + d[k] > 1.0 + EPS:
                return f"server {s} over capacity in {DIMS[k]} ({row[k] + d[k]:.6f})", -1, -1, []
        return None, s, -1, evict

    def apply(self, vm: int, vm_type: int, priority: int, tenant: int, t: float,
              decision: Any) -> tuple[int, bool, list[int], str | None]:
        """Apply one decision. Returns (server, failed, evicted vm ids, failure reason)."""
        try:
            reason, s, m, evict = self.check(vm_type, priority, decision)
        except Exception as exc:  # noqa: BLE001  (a hostile decision object must not crash the verifier)
            reason, s, m, evict = f"unreadable decision: {type(exc).__name__}", -1, -1, []
        failed = reason is not None
        if failed:
            s, m, evict = -1, int(self.machines.cheapest[vm_type]), []
        for v in evict:
            self.remove(v)
        if s < 0:
            s = self.open_server(m)
        self._add(vm, vm_type, priority, tenant, t, s)
        return s, failed, evict, reason

    def force(self, vm: int, vm_type: int, priority: int, tenant: int, t: float, s: int) -> None:
        """Mirror re-sync only: put vm on s regardless of capacity (the authority already validated it)."""
        while self.n_servers <= s:
            self.open_server(int(self.machines.cheapest[vm_type]))
        if vm in self.vm_server:
            self.remove(vm)
        self._add(vm, vm_type, priority, tenant, t, s)
