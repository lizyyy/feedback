#!/usr/bin/env python3
# VENDORED from demo-cases/rsi-exam/tools/opc/azure_vm_online_placement/pkg/score.py sha256=e9081889750466b00b56d8737836f5e4249cc7859495701f0441df81da463206 -- edit the canonical copy, then rerun build_task.py
"""Scorer for azure_vm_online_placement (pure computation; selfcheck runs this with --split practice).

    python3 score.py --split assessment --methods <dir with main/allocator.py> --log-dir <dir>
    python3 score.py --split practice   --methods ... --log-dir ... --data-dir <practice dir>

Per instance (one real 24-hour window of the Azure zone):
    instance_score = clip( (C_starter - C) / (C_starter - LB), -1, 1 )
  C          weighted server-hours over the scored 12 h + failed-placement and eviction penalties (simulate.py)
  C_starter  the same for the shipped first-fit starter (measured once, frozen in truth.json)
  LB         clairvoyant fractional vector-packing lower bound over the same 12 h (bounds.py, frozen in truth.json)
reward = mean of instance_score over the split's instances (AGGREGATE below).

Also written (numbers only): cost_ratio_score (sum of (C_starter - C) / sum of (C_starter - LB), each instance
floored at -1 x its gap), constraint_pass_rate, n_failed, n_evicted, server_cost, fail_penalty, evict_penalty,
candidate CPU; per-instance keys (score__A000 ...) go to score_details, never to reward.json. Human-readable notes
go to verifier_note.txt, the full ledgers to verifier_detail.json.

Exit paths: scored() (reward.json, exit 0 -- a 0.0 is a real reading) vs apparatus() (no reward.json,
verifier_error.json, exit 1) for anything that means the evaluation could not run: missing / drifted hidden files,
unfrozen manifest, empty instance set, simulator failure. A candidate crash / timeout / invalid decision fails the
affected requests (penalised, served on new servers) -- never an apparatus fault.
"""
from __future__ import annotations

import argparse
import json
import os
import statistics
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rsi_common  # noqa: E402
import simulate  # noqa: E402

AGGREGATE = "mean_instance_score"
DEADLINE_S = float(os.environ.get("RSI_SCORER_DEADLINE_S", "9000"))


def instance_score(cost: float, c_starter: float, lb: float) -> float:
    gap = c_starter - lb
    if not (gap > 0):
        return 0.0
    return float(min(1.0, max(-1.0, (c_starter - cost) / gap)))


def _run_one(args: tuple) -> dict:
    iid, inst_path, machines_path, methods, stderr_path, in_process, deadline = args
    machines = simulate.load_machines(Path(machines_path))
    inst = simulate.load_instance(Path(inst_path))
    if inst["meta"].get("id") != iid:
        return {"id": iid, "apparatus": f"instance file {inst_path} carries id {inst['meta'].get('id')}"}
    if in_process:
        import importlib.util
        spec = importlib.util.spec_from_file_location(f"rsi_candidate_inproc_{iid}", Path(methods) / "main/allocator.py")
        mod = importlib.util.module_from_spec(spec)
        sys.path.insert(0, str(Path(methods) / "main"))
        spec.loader.exec_module(mod)
        runner = simulate.InProcessRunner(mod.Allocator)
    else:
        runner = simulate.SandboxRunner(Path(methods), "main/allocator.py", stderr_path=Path(stderr_path))
    t0 = time.time()
    try:
        led = simulate.run_instance(inst, machines, Path(machines_path), runner, deadline=deadline)
    except Exception as exc:  # noqa: BLE001
        return {"id": iid, "apparatus": f"simulator failed on {iid}: {type(exc).__name__}: {exc}"}
    finally:
        runner.close()
    led["seconds"] = time.time() - t0
    return {"id": iid, "ledger": led}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", choices=["assessment", "practice"], required=True)
    ap.add_argument("--methods", required=True, help="directory containing main/allocator.py")
    ap.add_argument("--log-dir", required=True)
    ap.add_argument("--data-dir", default=None, help="directory with the instances, machines.npz and truth.json")
    ap.add_argument("--heldout", default=str(HERE / "heldout.json"))
    ap.add_argument("--in-process", action="store_true", help="organiser only: no sandbox (never in test.sh)")
    ap.add_argument("--ids", default="", help="comma-separated instance ids (quick look; not a valid reading)")
    ap.add_argument("--workers", type=int, default=int(os.environ.get("RSI_VERIFIER_WORKERS", "4")))
    a = ap.parse_args()
    os.environ["HARBOR_VERIFIER_LOG_DIR"] = a.log_dir
    log_dir = rsi_common.log_dir()
    t_start = time.time()

    if a.data_dir:
        data_dir = Path(a.data_dir)
        man = rsi_common.load_frozen(Path(a.heldout), verify_files=False) if Path(a.heldout).exists() else \
            json.loads((data_dir / "manifest.json").read_text())
    elif a.split == "assessment":
        data_dir = rsi_common.hidden_dir(HERE)   # plaintext tests/hidden/ or sealed tests/hidden.enc (+ key)
        man = rsi_common.load_frozen(Path(a.heldout), verify_files=(HERE / "hidden").is_dir())
    else:
        rsi_common.apparatus("--split practice needs --data-dir")
    if man.get("status") != "frozen":
        rsi_common.apparatus(f"{a.split} manifest status is {man.get('status')!r}, not 'frozen'")
    try:
        truth = json.loads((data_dir / "truth.json").read_text())
    except Exception as exc:  # noqa: BLE001
        rsi_common.apparatus(f"cannot read {a.split} truth from {data_dir}: {exc}")
    machines_path = data_dir / "machines.npz"
    if not machines_path.exists():
        rsi_common.apparatus(f"no machines.npz in {data_dir}")
    declared = list(man[a.split]["ids"])
    ids = [i for i in a.ids.split(",") if i] if a.ids else declared
    missing = [i for i in ids if i not in truth or not (data_dir / f"{i}.npz").exists()]
    if not ids or missing:
        rsi_common.apparatus(f"{a.split}: {len(ids)} ids requested, missing in data: {missing[:5]}")
    methods = Path(a.methods).resolve()
    if not (methods / "main/allocator.py").exists():
        rsi_common.apparatus(f"no main/allocator.py under {methods}")

    stderr_path = log_dir / "candidate.stderr"
    deadline = time.monotonic() + DEADLINE_S
    jobs = [(iid, str(data_dir / f"{iid}.npz"), str(machines_path), str(methods), str(stderr_path), a.in_process,
             deadline) for iid in ids]
    ledgers: dict[str, dict] = {}
    with ProcessPoolExecutor(max_workers=max(1, a.workers)) as ex:
        for res in ex.map(_run_one, jobs):
            if "apparatus" in res:
                rsi_common.apparatus(res["apparatus"])
            ledgers[res["id"]] = res["ledger"]

    notes, scores = [], []
    num, den = 0.0, 0.0
    for iid in ids:
        led, tr = ledgers[iid], truth[iid]
        c_s, lb = float(tr["c_starter"]), float(tr["lb"])
        gap = c_s - lb
        led["score"] = instance_score(led["cost_total"], c_s, lb)
        led["c_starter"], led["lb"] = c_s, lb
        scores.append(led["score"])
        if gap > 0:
            num += max(-gap, c_s - led["cost_total"])
            den += gap
        notes.append(f"{iid}: score {led['score']:.4f} cost {led['cost_total']:.1f} (starter {c_s:.1f} / bound {lb:.1f}) "
                     f"servers {led['server_cost']:.1f} failed {led['n_failed']} evicted {led['n_evicted']} "
                     f"opened {led['servers_opened']} peak {led['peak_open_servers']} "
                     f"cand-cpu {led['candidate_cpu_seconds']:.1f}s wall {led['seconds']:.1f}s"
                     + (f" | {led['errors'][0]}" if led["errors"] else ""))
    if not scores:
        rsi_common.apparatus("no instances scored")
    n = len(scores)
    agg = {"mean_instance_score": float(sum(scores) / n), "cost_ratio_score": float(num / den) if den > 0 else 0.0}
    reward = agg[AGGREGATE]
    L = ledgers.values()
    n_req = sum(l["n_requests"] for l in L)
    diag = {
        AGGREGATE: reward,
        "cost_ratio_score": agg["cost_ratio_score"],
        "n_instances": n,
        "n_declared": len(declared),
        "n_feasible": sum(1 for l in L if l["n_failed"] == 0),
        "score_std": statistics.pstdev(scores) if n > 1 else 0.0,
        "score_sem": (statistics.stdev(scores) / n ** 0.5) if n > 1 else 0.0,
        "constraint_pass_rate": 1.0 - sum(l["n_failed"] for l in L) / max(1, n_req),
        "n_requests": n_req,
        "n_failed": sum(l["n_failed"] for l in L),
        "n_evicted": sum(l["n_evicted"] for l in L),
        "cost_total": sum(l["cost_total"] for l in L),
        "server_cost": sum(l["server_cost"] for l in L),
        "fail_penalty": sum(l["fail_penalty"] for l in L),
        "evict_penalty": sum(l["evict_penalty"] for l in L),
        "servers_opened": sum(l["servers_opened"] for l in L),
        "candidate_cpu_seconds": sum(l["candidate_cpu_seconds"] for l in L),
        "verifier_seconds": time.time() - t_start,
    }
    for iid in ids:
        diag[f"score__{iid}"] = ledgers[iid]["score"]
        diag[f"cost__{iid}"] = ledgers[iid]["cost_total"]
    partial = " (PARTIAL: --ids given, not a valid reading)" if a.ids else ""
    note = (f"split={a.split} suite={man.get('suite_id')} instances={n}/{len(declared)} reward={reward:.6f}{partial} "
            f"({AGGREGATE}; cost_ratio_score={agg['cost_ratio_score']:.6f})\n" + "\n".join(notes))
    for l in L:
        l["failure_reasons"] = dict(sorted(l["failure_reasons"].items(), key=lambda kv: -kv[1])[:10])
    rsi_common.scored(reward, diag, note=note, extra_json={"split": a.split, "ledgers": ledgers})


if __name__ == "__main__":
    main()
