# Data sources, licences and commercial-training rights

## Microsoft Azure — Azure Trace for Packing 2020 (AzurePublicDataset, "AzurePackingTraceV1")

- **Source**: `https://github.com/Azure/AzurePublicDataset/releases/download/dataset-packing-2020/azurevmallocation_dataset2020_AzurePackingTraceV1.zip`
  (53,416,762 bytes, sha256 `af967499c4f2c38bb37f8fbb202768115cff6c2e522272a498a414762d85fe16`), containing
  `packing_trace_zone_a_v1.sqlite` (181,116,928 bytes, sha256
  `bb7e935b0bea31389b99060035f50371e384bb192baf8ed5e75b863f00b8159e`), revision 1 of 2020-11-05. The original
  Azure-blob download links no longer resolve; the dataset is re-hosted as a GitHub release asset. Retrieved
  2026-09-17 by `demo-cases/rsi-exam/tools/opc/azure_vm_online_placement/fetch_sources.py`, which pins every hash
  in `SOURCES.json`.
- **Schema document**: `https://github.com/Azure/AzurePublicDataset/blob/master/AzureTracesForPacking2020.md`.
- **Licence**: **Creative Commons Attribution 4.0 International (CC BY 4.0).** The dataset document states: "The data
  is made available and licensed under a CC-BY Attribution License … By downloading it or using them, you agree to
  the terms of this license." The repository `LICENSE` file is the full CC BY 4.0 text.
- **Commercial training rights: GRANTED** under CC BY 4.0, subject to attribution.
- **Attribution (required)**: Ori Hadary, Luke Marshall, Ishai Menache, Abhisek Pan, David Dion, Esaias Greeff,
  Star Dorminey, Shailesh Joshi, Yang Chen, Mark Russinovich and Thomas Moscibroda. "Protean: VM Allocation Service
  at Scale", OSDI 2020. Data: Microsoft Azure, AzurePublicDataset, Azure Trace for Packing 2020.
- **What this package ships (and how it was changed)** — CC BY 4.0 asks that changes be indicated:
  - `machines.npz`: the `vmType` table re-encoded as an array `demand[vmTypeId, machineId, (core, memory, hdd, ssd,
    nic)]`; a NULL `hdd` becomes 0 for an existing (type, machine) pair; plus a per-machine server-cost weight derived
    by the organiser (the machine's memory size relative to machine type 1, computed from the table itself).
  - `history_practice.npz` and the instance files: the `vm` table re-encoded (vmTypeId, priority, tenantId, start,
    end), times converted to hours since the window start, end times beyond the practice cut-off replaced by +inf in
    everything the agent can see. Rows are neither filtered nor sampled; the anonymised ids are the trace's own.

## What is deliberately NOT cleaned

Every VM request in a window is kept: whole-host VM types, sub-second lifetimes (1,037 in the trace), the same-second
bursts of up to 1,002 requests, the low-priority VMs whose recorded lifetime already includes Azure's own evictions,
and the tenants that appear only once. The machine-type compatibility table is used as published, including machine
types that only a handful of VM types can use.

## Contamination

The trace is public and has been used in VM-packing research (it was released for exactly that). What is not public
is anything this task scores against: the per-window lower bounds, the starter's per-window cost and the split are
computed here. A policy that memorised published results would still have to place each request online, one second
at a time, against a replay that only reveals the past.
