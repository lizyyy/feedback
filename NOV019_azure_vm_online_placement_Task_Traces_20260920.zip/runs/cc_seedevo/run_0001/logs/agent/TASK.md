# Harbor task — auto-research run with clean-sandbox verification

You are running one harbor task inside a sandbox built from the task's own environment.

Layout:
- `/app` is the working directory. Do your work there.
- The task files (instruction.md, task.toml, tests/) are at `/home/novix/workspace/.harbor_task/azure_vm_online_placement`. They are READ-ONLY: never modify, add to, or delete anything under that directory.
- `/app/methods` is the ONLY directory that persists after your run (the platform keeps it and grades from it). Everything you want scored must live there; the rest of `/app` is ephemeral.

Scoring contract:
- **The only score you may produce is the task's own self-check on the practice split.** Run it as often as you like to steer your work, and run it once more as the LAST step of your run so the platform records your visible reward:

```bash
cd /app && python3 /app/selfcheck.py /app/methods   # or exactly the practice self-check command instruction.md names
mkdir -p /logs/verifier && cp <the reward.json that self-check just wrote> /logs/verifier/reward.json
```

  Always the practice-split check, never the hidden one. If the self-check accepts a log-dir option, point it at `/logs/verifier` instead of copying. `/logs/verifier/reward.json` (key `reward`) is your visible reward and is recorded as such — it is NOT the score that counts.
- **The score that counts is produced by the platform, not by you.** After your run ends the platform starts a NEW clean container from the same image, mounts `/app/methods` as you left it, and runs the task's sealed hidden verifier there. Design for it: nothing you installed or changed outside `/app/methods` exists in that container; whatever the verifier needs must come from the task image or from `/app/methods` in the way instruction.md allows.
- **Never create a `verify_clean/` directory, never hand-write or edit `reward.json`, never read sealed or hidden data** (`tests/hidden*`, `.rsi_hidden_key`, `solution/`, `organizer/` — they are not yours and are not in this sandbox). Anything of that kind is treated as tampering and voids the run.
- If the self-check fails or produces no score, do NOT fabricate one. Leave `reward.json` absent and write `/logs/verifier/verifier_error.json` as `{"apparatus_fault": "<what broke>"}`.
- Do not stop before the final self-check has run: a run without a visible reward is recorded as a failure even if the clean verifier later scores your methods.


## Task

# Placing virtual machines online in a real Azure zone

In a public cloud region, the cluster allocator (Azure's is Protean) decides, the moment a VM request arrives, which
physical server it will run on. It does not know how long the VM will live. It must respect every resource
dimension of the server (cores, memory, hdd, ssd, network), it may only use machine generations the VM type is
certified for, it may never overcommit, and the operator pays for every server that is kept non-empty. When nothing
fits, a new server has to be brought into service; a request that cannot be served correctly is an allocation
failure. **Your job is to evolve `methods/main/allocator.py`, the placement policy, so that the zone runs on fewer
weighted server-hours.**

Every instance is one real 24-hour window of the *Azure Trace for Packing 2020* (one Azure zone, 14 days): every VM
request that arrived in that window, in its real order, with its real VM type, priority, tenant, arrival time and —
held back by the verifier — its real departure time.

## 1. The number you are scored on

```
C        = server_cost + fail_penalty + evict_penalty                        (per instance, lower is better)
server_cost   = integral over the SCORED hours of  sum over non-empty servers of weight[machine type]   (hours)
fail_penalty  = 24 x (number of failed placements, anywhere in the window)
evict_penalty = 2 x weight[m] x (evicted VM's largest resource share on m) x clip(its real remaining life, 1 h, 24 h)

instance_score = clip( (C_starter - C) / (C_starter - LB), -1, 1 )
reward         = mean of instance_score over the instances                   (maximize)
```

- An instance is 24 h: the cluster starts empty, the first 12 h are **warm-up** (you place every request, nothing
  is charged except failures), the next 12 h are **scored**.
- `weight[m]` is the server-hour price of machine type `m`: its memory size relative to machine type 1 (from the
  trace's own resource table; see `data/practice/instances.json`).
- `C_starter` is the shipped starter's cost on that instance, `LB` a clairvoyant lower bound (it knows every
  departure and may split VMs fractionally across servers). Both are frozen per instance. The starter is `0`;
  `1` is not reachable by any real placement.
- A crash, a timeout, or an unreadable reply does not end the run: every request that did not get a valid decision
  is a failed placement, served on a new server and penalised, and the instance is still scored.

## 2. What you are given

| what | where | role |
|---|---|---|
| practice instances | `/app/data/practice/P000.npz … P006.npz` | trace days 0–6, one window per day, **with** departure times |
| practice truth | `/app/data/practice/truth.json` | `C_starter` and `LB` per practice instance |
| machine table | `/app/data/practice/machines.npz` | `demand[vm_type, machine_type, 5]` (NaN = incompatible), `weight`, capacity ratios |
| fleet history | `/app/data/practice/history_practice.npz` | every VM that started before trace day 7.0 (including VMs already running when collection began), departures after day 7.0 censored to `inf` |
| the starter | `/app/methods/main/allocator.py` | what you evolve; it is the zero of the scale |
| the visible evaluator | `python3 /app/selfcheck.py` | the verifier's own scorer and sandbox, fed the practice split |
| the scorer | `/app/score.py`, `/app/simulate.py`, `/app/cluster.py` | read them; the verifier runs these same files |

The sealed instances are later days of the same zone (trace days 7–13). The mix of VM types, the share of
low-priority VMs and the daily volume differ between days — look at the practice days before assuming they are alike.

Pre-installed: python 3.12, numpy, scipy. No network, 4 CPUs, 16 GB. One practice instance has 318k–436k requests;
the starter needs a few minutes of CPU per instance.

## 3. Interface contract

```python
class Allocator:
    def reset(self, cluster: dict) -> None: ...
    def place(self, request: dict, state) -> int | str | dict: ...
    def observe_departures(self, departed: list, state) -> None: ...   # optional
```

- `cluster` = `{"machines_file", "instance": {"id", "t0_trace_day", "warmup_h", "horizon_h", "n_hours"},
  "fail_penalty", "evict_mult", "budgets_cpu_s"}`.
- `request` = `{"vm", "vm_type", "priority", "tenant", "time"}`; `priority` 0 = regular, 1 = low-priority;
  `time` in hours since the window start. The departure time is **not** in it.
- `state` is a `cluster.ClusterState` the harness keeps up to date for you (read it, do not modify it):
  `n_servers`, `server_type[:n]`, `used[:n, 5]` (fractions of that server), `n_vms[:n]`, `n_low[:n]`,
  `server_vms[s]`, `vm_server`, `vm_type`, `vm_priority`, `vm_tenant`, `vm_start`, `now`, `machines`
  (`demand`, `compatible`, `weight`, `dom_cost`, `cheapest`), and `fits_mask(vm_type)`.
- `place` returns one decision:
  - `s` (int) — put the VM on existing server `s` (an empty server may be reused);
  - `"new:<m>"` — open a new server of machine type `m`;
  - `{"server": s, "evict": [vm, ...]}` — **high-priority requests only**: evict the listed low-priority VMs from
    server `s` (they must all be on `s`), then place the VM there.
- `observe_departures` receives `[[vm, end_time], ...]` for VMs that left (or were evicted) since the last call.

Requests that arrive in the same second are one decision batch: `place` is called for each of them in order, and each
decision is applied to `state` before the next call. Before a batch, every VM whose real end time has passed has left.

## 4. What you may and may not change

| | |
|---|---|
| yours | `methods/main/allocator.py`, and any module or data file you add under `methods/main/` |
| yours, and expected | `methods/experiment_log.md`, `methods/versions/v<N>/` |
| fixed | `score.py`, `simulate.py`, `cluster.py`, `rsi_common.py`, `selfcheck.py`, everything in `data/` |

Do not hard-code instance ids, tenants or arrival times.

## 5. Rules the verifier enforces on every decision

A decision is a **failed placement** (penalty 24, the VM is put on a new server of its cheapest machine type) if:

- the machine type cannot run that VM type (its demand is NaN there);
- after placement any of the five dimensions of the server would exceed 1.0;
- the server id does not exist, or the decision is not one of the three forms above;
- an eviction is requested by a low-priority request, names a VM that is not low-priority or not on that server,
  or still does not make room.

There is no overcommit, no migration, and no cap on the number of servers of a machine type (the trace does not
record the zone's inventory).

Budgets, measured in **CPU seconds of your whole process** (threads and child processes included): `reset` 120 s,
one decision batch 10 s, one instance 1500 s; and at most 1.5 cores on average (one core is yours). Past a budget your process is killed and the rest of that instance
fails. Your code runs in its own process with the clock and the random seeds pinned: `time.time()` does not move.

## 6. How to work

Keep `methods/experiment_log.md` current and snapshot each measured version into `methods/versions/v<N>/`. Compare
versions only on full practice readings. A single window (`--ids P006`) is a quick look, not a reading.

## 7. The one acceptance rule

A `selfcheck.py` run is a valid reading only if `reward.json` exists, `n_instances == n_declared` (all seven practice
windows) and `verifier_note.txt` shows no error line for any instance.

## 8. Before you report a number

A reward far above what the practice windows support usually means the policy read something it should not have — the
departure times in the practice files are there for learning, and are not available to `place` at run time. Check
`n_failed` and `n_evicted` in `reward.json` before believing a cost drop. All-zero or all-one is a red flag.

## 9. What you deliver

`methods/main/allocator.py` exposing `Allocator`. The verifier replays it on the sealed windows itself. **You never
write a score.**