# Experiment log — Azure VM online placement

Metric: reward = mean instance_score over the 7 practice windows (selfcheck.py).
Quick checks on P005/P006 are NOT valid readings (full 7-window runs are marked [FULL]).
Score sign: starter = 0 by construction; positive = better.

| id | parent | what | measured | kept? |
|----|--------|------|----------|-------|
| v0 | — | shipped first-fit starter | 0 (by definition; reproduces truth.json c_starter, n_failed=0) | baseline |
| v1 | v0 | tightness-only best-fit, 5 vectorized score modes | P005/P006 mean: m1 dominant-load **-0.116**, m2 sum-load **+0.0002**, m3 residual-product -0.077, m4 dot/align -0.195, m5 min-dim -0.024 | m2 tied starter, none kept |
| v2 | v1-m2 | lifetime-aware: server predicted-close (median life prior from fleet history + online adaptation), prefer non-extending then tightest server | P005/P006 **-0.101** (P005 -0.094, P006 -0.108), 0 fails | reverted |

| v2b | v2 | **oracle exact-lifetime** close-aware placement (dev-only diagnostic reading practice end_h; never shipped) | P005/P006: close rule **-0.073**, tight(=sum, ignores life) +0.0002 | diagnostic only |
| v3 | v1 | 10 shape-aware packing scores targeting nic bottleneck (nic/sumaw/dotmin/comp/bal/nicmix/sum_nic/resnic/maxmin_w/sum) | P005/P006 means: nic -0.125, sumaw -0.016, dotmin -0.684, comp -0.029, bal -0.014, nicmix -0.065, sum ≈ 0; all ≤ 0 | none kept |

Key diagnostics (replay_analyze.py, fleet_mix.py):
- Scored-hours utilization (starter): nic 0.89-0.92 (BINDING dim), core 0.78-0.83, mem 0.56-0.67, ssd 0.54-0.65, hdd ~0. Avg server max-fill = 1.000: bins saturate in their binding dim.
- Fleet = two populations: nic-bound m1/m16 (nic .98, core .6-.72, 70% of weighted rate P005) and core-bound m3/m8/m15/... (core .98). Cross-dim slack exists but is gated by compatibility and near-zero nic slack.
- Exact-lifetime oracle does not beat first-fit: the gap is spatial/machine-mix, not temporal.
- All myopic repacking scores tie or lose to first-fit in this fast-churn equilibrium (median life ~0.5h).
- Eviction opportunity P000: 12134 new opens (3032 scored, 1.38% of arrivals); 5643/5858 blocked high-pri placements had a compatible server carrying low-pri VMs.
| v4/v5 | v3 | + eviction (blocked high-pri evicts cheapest low-pri set, median-life penalty estimate, ETH w-hours) + new-server machine rules (cheap/nic/core/pool/auto), packing=sum | evict ETH=1: P002 -1.00 (srv 54401<LB but evict pen 16554), P000 -1.00 (pen 20892), P005 -0.69 — mechanism removes server-hours but median-life rem underestimates TRUE penalty ~2.2x; too eager | reverted pending oracle calibration |

Eviction opportunity (starter blocked events, whole window): high-pri new-opens 2811-5653/day, 87-97% had a compatible low-bearing server. Scored new-open rate 1.25-3.14% of arrivals (P002/P003 highest).

- Oracle eviction calibration done (sweep_oracle2.sh, oracle_evict.py with TRUE end_h; dev-only): true-penalty cap T over P000/P002/P003/P005, greedy set cover <=8 VMs, fires all 24h.

| T | mean(4d) | P000 | P002 | P003 | P005 |
|---|----------|------|------|------|------|
| 0.02 | **+0.0048** | -0.0012 (7 ev) | +0.0204 (9 ev) | +0.0001 (4 ev) | 0 (0 ev) |
| 0.05 | +0.0033 | +0.0016 (74) | +0.0104 (280) | +0.0066 (23) | -0.0056 (216) |
| 0.10 | -0.0036 | -0.0063 (533) | -0.0122 (840) | +0.0137 (80) | -0.0097 (600) |
| 0.20 | -0.0722 | -0.0602 | -0.0822 | -0.0550 | -0.0915 |

Ceiling ≈ +0.005, concentrated on low-heavy P002/P003; P005 (4.6% lows) zero/negative at all T. Benefit saturates after cheapest ~300 sets; penalties explode past T~0.05. => ship only a very conservative predictor (small absolute predicted-penalty budget, quantile residual estimate), expect <=+0.003 mean.
- Starter skips EMPTY reusable servers (fits_mask allows them): non-empty cost identical at reuse moment, only machine-type composition of fleet changes — added RSII_EMPTY c/a/w A/B modes to v8 (c with same type should exactly reproduce score).
- Fleet structure: top 14 high-volume types are cross-compatible on m{1,16,23,8,6,15} within ±15% w·dom; starter splits them m1/m23/m8/m15 by cheapest. All 14 fit on m23 (w=0.683, 1.25x inferred nic cap, +4.4% premium) — consolidation hypothesis for P005/P006's 15.5% gaps. v8 wave1 testing cheap/m23/nicd/effw/pool.
- Residual-life tables built (dev/build_restable.py -> main/restable.npz): low-pri = extreme mixture (39% alive at 24h; completed median life 0.11h, q75 0.71h); pooled residual q50 fresh 1.9h but q85 pinned at 24 cap; 48 types with >=100 low obs carry type x age quantiles.
- v6 (median-life eviction draft) superseded before measurement by v7 (quantile-table predictor, dev/v7_predict.py).
- Next: v8 machine rules (running) -> winners full 7-window; v7 predictor B/Q sweep; combine.

| v8 (dev) | oracle | machine-rule A/B (v8_machine.py), sum packing, 4 days P001/P004/P005/P006: cheap/sum=−0.0036 sanity; **m23 D=.15 +0.1185, m23 D=.30 +0.1221**; effw +0.0227; nicd −0.498; pool −0.403. Per-day m23 D.15: P001 +0.057, P004 **−0.202**, P005 +0.371, P006 +0.249; 0 fails 0 evicts — real packing gain, not penalty gaming | nic-hub rule kept (promoted to main as v6); P004 pathology to fix |
| **v6_hub** | v8 m23 | shipped m23 hub D=.15 + sum best-fit, no data-file deps | dev 4-day mean **+0.1185** (full 7-window reading pending) | KEPT interim |
| v10 (dev) | v6 | hub with core/mem share gates CC/CM (demands on m23 are discrete: .019/.038/.077/.154/.308 core) | wave3 4-day means: **CC=.10/CM=.10: +0.1262 ALL POSITIVE** (P001 +.061, P004 +.144, P005 +.169, P006 +.131); CC=.12 identical; CC=.16: +.1788 but P004 −.069 (regime jump when t44/t67/t62 core=.154 included) | tight gate chosen (robust across regimes) |
| **v7_gatedhub** | v10 | shipped: HUB=23, BAND=.30, core/mem gate .10, sum best-fit, standalone (no data files), 99 types routed | dev 4-day +.126 all-positive; **full 7-window dev reading running**, then official selfcheck | KEPT candidate |

[FULL-DEV 7-window, eval_local in-process] v7_gatedhub: **REWARD +0.11108**, all positive: P000 +.149, P001 +.061, P002 +.080, P003 +.044, P004 +.144, P005 +.169, P006 +.131; n_failed=0, n_evicted=0.

**[FINAL/OFFICIAL selfcheck.py --workers 4, run dir /app/selfcheck_runs/20260917-183846, copied to methods/selfcheck_runs/01 and /logs/verifier/reward.json] v7_gatedhub (main/allocator.py): reward=0.111076 (score_std .045, sem .018), n_instances=7/7, n_failed=0, n_evicted=0, constraint_pass_rate=1.0, 2,455,264 requests; per-window +.1487/.0611/.0800/.0441/.1436/.1691/.1310; no verifier error lines — VALID reading. This is the submitted version.**

Pool ledger diagnosis (dev/pool_cost.py): m23 reroute turns scattered cheap satellite pools into one nic-dense m23 pool (P005: m1 17.0k + m23 .6k+satellites -> m23 19.7k, total −1.4k); P004 fails only when .154-core types are admitted — m23 needs 86.6k unweighted server-hours (core strands nic), cost 59.1k vs cheap m1 52.4k. Tight gate removes them and P004 becomes +.144.

Notes:
- Pure spatial repacking cannot beat first-fit: mode 2 opens fewer servers (4410 vs 4737 P005) at equal cost — fuller bins stay non-empty longer, gains cancel.
- v2 predicted-close stacking hurt: close=max(median) is noisy (within-type IQR ~6.8x) and short VMs piling onto long servers steals long-VM capacity.
- lifeprior.npz built from fleet history (uncensored recent VMs), typefreq.npz from history type counts — both live in main/; lifetime path dropped but files still used for eviction penalty estimates.
