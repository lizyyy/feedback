# Final report — Azure zone online VM placement

## Submitted version

`methods/main/allocator.py` — **v7_gatedhub** (snapshot: `versions/v7_gatedhub/`).

**Official practice self-check reward: 0.111076** (`selfcheck.py --workers 4`, run dir
`20260917-183846`, artifacts in `methods/selfcheck_runs/01/`; the in-process dev replay matched to 4
decimals). 7/7 instances, `n_failed = 0`, `n_evicted = 0`, constraint pass rate 1.0, 2,455,264 requests,
no verifier error lines. Per-window instance scores, all positive:

| P000 | P001 | P002 | P003 | P004 | P005 | P006 | mean |
|-----:|-----:|-----:|-----:|-----:|-----:|-----:|-----:|
| +0.149 | +0.061 | +0.080 | +0.044 | +0.144 | +0.169 | +0.131 | **+0.111** |

(The official sandboxed `selfcheck.py` reading for this exact file is recorded in the experiment log
as the final entry; reward.json copied per the run contract.)

## The policy

Two ideas, both online and causal (no departure times used at decision time):

1. **Gated nic-hub consolidation for new servers.** The fleet is nic-bound (nic weighted utilization
   ~0.9). The ~100 small, strictly nic-dominant VM types are cross-certified on machine type 23, which
   costs 0.683 server-hours vs 1.0 for machine 1 and offers ~1.25x the nic capacity, for only a small
   weight×dominant-share premium. A type opens on machine 23 when it is certified there, its premium
   over its individually cheapest machine is ≤30%, **and** its core and memory footprints on machine 23
   are ≤0.10 each; everything else uses its cheapest machine. The profile gate is essential: machine 23
   has only ~0.54x the cores, and admitting the 0.15-core nic types strands those cores (P004 went from
   −0.20 ungated to +0.14 gated).
2. **Sum-of-loads best fit** among compatible non-empty servers (a tight, dimension-balanced variant of
   first fit; the starter scans for any fit).

The policy is one standalone file, loads no external data, does no eviction, and is comfortably inside
the CPU budgets (simple vectorized masks).

## How the design was reached (what worked / what did not)

- **Myopic repacking does not help.** 15 packing objectives (dominant-load, residual product, weighted
  alignment, nic-focused scores, lifetime-aware "close server" stacking, …) tie or lose to first fit in
  this fast-churn equilibrium; an oracle with exact lifetimes for placement also tied (−0.07).
- **Eviction's ceiling is tiny.** Even an oracle using true remaining lives gains at most ~+0.005 mean and
  only on the low-priority-heavy days (P002/P003); on low-priority-sparse days it is non-positive at every
  threshold, and predicted-penalty variants blow up because low-priority residual life is an extreme
  mixture (39% alive at 24h; completed median life 0.11h). Eviction was therefore shipped **off**.
- **Machine-type selection is the real lever.** The starter's per-VM cheapest choice fragments the
  cross-compatible nic types across pools {m1, m8, m15, m16, m23, …}. Consolidating the small nic types on
  machine 23 collapses many low-utilization bins into dense nic bins. Other reroute rules (argmin
  w×nic-share, biggest-pool, nic-efficiency) were strongly negative; consolidation onto the right hub with
  the right profile gate was the only robust winner.
- Pool cost ledgers (`dev/pool_cost.py`) showed the mechanism directly: e.g. on P005 the scattered m1
  17.0k + satellite pools shrink to one 19.7k m23 pool for a ~1.4k weighted server-hour saving.

## Generalization judgment

- The gate thresholds were chosen for **robustness, not best mean**: a slightly looser gate (core ≤0.16)
  scored higher on average (+0.179 on the 4 tuning days) but was negative on P004; the tight gate is
  positive on all seven windows spanning heavy (P000), low-priority-heavy (P002/P003), and nic-light
  (P005/P006) regimes. That all-positive spread across structurally different days is the main evidence
  the rule transfers to the sealed days 7–13 of the same zone.
- Constants come from fleet-wide structure (machine table capacities, the discreteness of demand rows),
  not instance ids, tenants, or arrival times; nothing in `place()` reads end times or instance identity.
- No failures anywhere means the score is pure weighted-server-hour reduction, not penalty gaming.

## Artifacts

- `experiment_log.md` — every version and measurement; `versions/` — snapshots of all logged versions.
- `dev/` — sweeps and diagnostics (oracle tools there read practice end_h and are dev-only, never shipped).
- `lifeprior.npz`, `restable.npz`, `typefreq.npz` in main/ are learning artifacts (fleet history +
  practice departures); the shipped allocator does not load them.
