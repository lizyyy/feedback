"""Best-fit allocator (research v1): tightness-only variants, env-selected."""
import os

import numpy as np

EPS = 1e-9


class Allocator:
    def reset(self, cluster):
        self.cluster = cluster
        self.machines = None

    def _init_machines(self, state):
        mac = state.machines
        self.machines = mac
        self.demand = mac.demand
        self.weight = mac.weight
        self.compat = mac.compatible
        self.cheapest = mac.cheapest
        self.mode = int(os.environ.get("RSII_BF_MODE", "2"))

    def place(self, request, state):
        if self.machines is None:
            self._init_machines(state)
        t = int(request["vm_type"])
        n = state.n_servers
        if n:
            mt = state.server_type[:n]
            d = self.demand[t][mt]
            used = state.used[:n]
            ok = self.compat[t][mt] & ((used + d) <= 1.0 + EPS).all(axis=1) & (state.n_vms[:n] > 0)
            idx = np.flatnonzero(ok)
            if idx.size:
                after = used[idx] + d[idx]
                mode = self.mode
                if mode == 1:
                    scores = after.max(axis=1)
                elif mode == 2:
                    scores = after.sum(axis=1)
                elif mode == 3:
                    res = np.maximum(1.0 - after, 1e-12)
                    scores = -np.log(res).sum(axis=1)
                elif mode == 4:
                    scores = (used[idx] * d[idx]).sum(axis=1)
                elif mode == 5:
                    scores = after.min(axis=1)
                else:
                    scores = after.max(axis=1)
                return int(idx[int(np.argmax(scores))])
        return f"new:{int(self.cheapest[t])}"
