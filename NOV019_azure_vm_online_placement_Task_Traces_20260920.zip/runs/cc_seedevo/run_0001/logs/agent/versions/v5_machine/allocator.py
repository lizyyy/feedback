"""Research v5: packing + eviction + smarter NEW-server machine selection.

New-server rules (RSII_NEW):
  cheap   : argmin w*dom (starter)
  nic     : argmin w/cap_nic among machines where the VM fits alone
  core    : argmin w/cap_core
  auto    : argmin w*dom* (1 - beta*log pool prior)  (mix-friendliness tie-break)
  pool    : cheapest, tie broken by arrival-pool size
Capacities are inferred from the demand matrix (ratios to machine type 1).
"""
import os
from pathlib import Path

import numpy as np

EPS = 1e-9


class Allocator:
    def reset(self, cluster):
        self.cluster = cluster
        self.machines = None
        self.pack = os.environ.get("RSII_PACK", "sum")
        self.new_rule = os.environ.get("RSII_NEW", "cheap")
        self.do_evict = os.environ.get("RSII_EVICT", "0") == "1"
        self.e_thresh = float(os.environ.get("RSII_ETH", "4.0"))
        p = Path(__file__).absolute().parent
        f = p / "lifeprior.npz"
        if not f.exists():
            f = Path.cwd() / "lifeprior.npz"
        z = np.load(f)
        self.prior_med, self.pr_med = z["med"].copy(), z["pr_med"].copy()
        f2 = p / "typefreq.npz"
        if not f2.exists():
            f2 = Path.cwd() / "typefreq.npz"
        z2 = np.load(f2)
        self.pool = z2["pool"]

    def _init(self, state):
        mac = state.machines
        self.demand = mac.demand
        self.weight = mac.weight
        self.compat = mac.compatible
        self.cheapest = mac.cheapest
        self.T, self.M = mac.n_types, mac.n_machines
        self.dom = mac.demand.max(2)
        # infer capacities relative to machine 1 from cross-compatible demand ratios
        cap = np.ones((self.M, 5))
        dd = mac.demand
        for m in range(self.M):
            if m == 1:
                continue
            both = self.compat[:, 1] & self.compat[:, m]
            for k in range(5):
                a, b = dd[both, 1, k], dd[both, m, k]
                ok = (a > 0) & (b > 0)
                cap[m, k] = np.median(a[ok] / b[ok]) if ok.sum() > 3 else np.nan
        cap[~np.isfinite(cap)] = 1.0
        self.cap = cap
        logpool = np.log(1.0 + self.pool)
        self.logpool = logpool / logpool.max()
        # per-vm-type new machine choice under each rule
        self.choice = {}
        for rule in ("nic", "core", "pool", "auto"):
            ch = np.zeros(self.T, dtype=int)
            for t in range(self.T):
                ms = np.flatnonzero(self.compat[t])
                if ms.size == 0:
                    ch[t] = int(self.cheapest[t]); continue
                if rule == "pool":
                    key = self.weight[ms] * self.dom[t, ms]
                    j = np.lexsort((-self.pool[ms], key))[0]
                elif rule == "auto":
                    key = self.weight[ms] * self.dom[t, ms] * (1.0 - 0.15 * self.logpool[ms])
                    j = np.argmin(key)
                elif rule in ("nic", "core"):
                    k = 4 if rule == "nic" else 0
                    j = np.argmin(self.weight[ms] / np.maximum(cap[ms, k], 1e-6))
                ch[t] = int(ms[j])
            self.choice[rule] = ch

    def _new_machine(self, t):
        if self.new_rule == "cheap":
            return int(self.cheapest[t])
        return int(self.choice[self.new_rule][t])

    def _pred_life(self, t, pr, now, start):
        m = self.prior_med[t, pr]
        if not np.isfinite(m) or m == 0.0:
            m = self.pr_med[pr]
        return max(1.0, min(24.0, float(np.exp(m)) - (now - start)))

    def place(self, request, state):
        if self.machines is None:
            self._init(state); self.machines = 1
        t = int(request["vm_type"])
        pr = int(request["priority"])
        now = float(state.now)
        n = state.n_servers
        idx = np.empty(0, dtype=int)
        d_all = None
        if n:
            mt = state.server_type[:n]
            d_all = self.demand[t][mt]
            used = state.used[:n]
            ok = self.compat[t][mt] & ((used + d_all) <= 1.0 + EPS).all(1) & (state.n_vms[:n] > 0)
            idx = np.flatnonzero(ok)
        if idx.size:
            after = state.used[:n][idx] + d_all[idx]
            if self.pack == "ff":
                return int(idx[0])
            return int(idx[int(np.argmax(after.sum(1)))])

        if self.do_evict and pr == 0:
            ev = self._eviction_set(state, t, now, n, d_all)
            if ev is not None:
                s, vms, pen = ev
                m_new = self._new_machine(t)
                if pen <= self.weight[m_new] * self.e_thresh:
                    return {"server": int(s), "evict": [int(v) for v in vms]}
        return f"new:{self._new_machine(t)}"

    def _eviction_set(self, state, t, now, n, d_all):
        mt = state.server_type[:n]
        cand = self.compat[t][mt] & (state.n_vms[:n] > 0) & (state.n_low[:n] > 0)
        cs = np.flatnonzero(cand)
        if cs.size == 0:
            return None
        used = state.used[:n]
        need = np.maximum(0.0, used[cs] + self.demand[t][mt[cs]] - 1.0 - EPS)
        order = np.argsort(need.sum(1))
        best = None
        for ci in order[:30]:
            s = int(cs[ci]); m = int(mt[s])
            low = [v for v in state.server_vms[s] if state.vm_priority[v] == 1]
            if not low:
                continue
            rows = np.array([self.demand[int(state.vm_type[v])][m] for v in low])
            doms = rows.max(1)
            rem = np.array([self._pred_life(int(state.vm_type[v]), 1, now, state.vm_start[v])
                            for v in low])
            pens = 2.0 * self.weight[m] * doms * rem
            need_s = need[ci].copy()
            chosen, total_pen, used_mask = [], 0.0, np.zeros(len(low), bool)
            while (need_s > EPS).any() and len(chosen) < 6:
                cover = np.minimum(rows, need_s[None, :]).sum(1)
                cover[used_mask] = -1.0
                j = int(np.argmax(cover / np.maximum(pens, 1e-9)))
                if cover[j] <= 0:
                    break
                used_mask[j] = True
                chosen.append(j)
                need_s = np.maximum(0.0, need_s - rows[j])
                total_pen += pens[j]
            if (need_s <= EPS).all():
                if best is None or total_pen < best[2]:
                    best = (s, [low[j] for j in chosen], total_pen)
        return best
