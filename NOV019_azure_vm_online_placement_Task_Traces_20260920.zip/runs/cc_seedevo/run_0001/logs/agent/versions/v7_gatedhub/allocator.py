"""Placement policy v7: profile-gated nic-hub consolidation + sum best-fit.

The fleet is nic-bound. The common high-volume VM types are cross-certified on
machine 23, which costs 0.683 per server-hour (vs 1.0 for machine 1) and exposes
~1.25x the nic capacity, at only a small weight*dominant-share premium. The starter
opens every VM on its individually cheapest machine, fragmenting these compatible
types across pools; consolidating the small, nic-dominant types onto machine 23
packs the binding (nic) dimension far tighter.

The gate matters: machine 23 has only ~0.54x the cores of machine 1, so larger
core-footprint nic types (e.g. demands >= ~0.15 of m23's cores) strand its cores
and are left on their cheapest machine. The gated rule is positive on every
practice regime (heavy, balanced and nic-light days) with zero failed placements.

  * existing non-empty server: compatible + within all five capacities; among fits
    choose the server with the greatest total post-placement fractional load;
  * new server: machine 23 when the type is certified there, its weight*dominant
    share is within 30% of its cheapest machine, and its core/memory shares on 23
    are small (<=0.10); otherwise its cheapest machine.
"""
import numpy as np

EPS = 1e-9
HUB = 23
BAND = 0.30
MAX_CORE = 0.10
MAX_MEM = 0.10


class Allocator:
    def reset(self, cluster):
        self.cluster = cluster
        self.machines = None

    def _init(self, state):
        mac = state.machines
        self.demand = mac.demand
        self.weight = mac.weight
        self.compat = mac.compatible
        dom = mac.demand.max(axis=2)
        wdom = self.weight[None, :] * np.where(self.compat, dom, np.inf)
        cheapest = wdom.argmin(axis=1)
        take = (self.compat[:, HUB]
                & (wdom[:, HUB] <= (1.0 + BAND) * wdom.min(axis=1))
                & (self.demand[:, HUB, 0] <= MAX_CORE)
                & (self.demand[:, HUB, 1] <= MAX_MEM))
        self.choice = cheapest
        self.choice[take] = HUB

    def place(self, request, state):
        if self.machines is None:
            self._init(state)
            self.machines = 1
        t = int(request["vm_type"])
        n = state.n_servers
        if n:
            mt = state.server_type[:n]
            d_all = self.demand[t][mt]
            ok = (self.compat[t][mt]
                  & ((state.used[:n] + d_all) <= 1.0 + EPS).all(axis=1)
                  & (state.n_vms[:n] > 0))
            idx = np.flatnonzero(ok)
            if idx.size:
                after = state.used[:n][idx] + d_all[idx]
                return int(idx[int(np.argmax(after.sum(axis=1)))])
        return f"new:{int(self.choice[t])}"
