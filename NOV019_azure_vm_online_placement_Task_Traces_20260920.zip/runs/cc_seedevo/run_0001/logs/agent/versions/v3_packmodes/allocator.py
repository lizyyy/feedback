"""Research v3 testbed: packing-score variants selected by RSII_MODE env.
Dev snapshot: /app/methods/versions/v3_packmodes/allocator.py"""
import os

import numpy as np

EPS = 1e-9
# nic-heavy fleet: dim scarcity weights used by some modes (tuned offline)
AW = np.array([1.0, 0.6, 0.0, 0.6, 1.2])


class Allocator:
    def reset(self, cluster):
        self.cluster = cluster
        self.machines = None
        self.mode = os.environ.get("RSII_MODE", "nic")

    def _init_machines(self, state):
        mac = state.machines
        self.demand = mac.demand
        self.weight = mac.weight
        self.compat = mac.compatible
        self.cheapest = mac.cheapest

    def place(self, request, state):
        if self.machines is None:
            self._init_machines(state); self.machines = 1
        t = int(request["vm_type"])
        n = state.n_servers
        if n:
            mt = state.server_type[:n]
            d = self.demand[t][mt]
            used = state.used[:n]
            ok = self.compat[t][mt] & ((used + d) <= 1.0 + EPS).all(1) & (state.n_vms[:n] > 0)
            idx = np.flatnonzero(ok)
            if idx.size:
                u, dd = used[idx], d[idx]
                after = u + dd
                mode = self.mode
                if mode == "nic":           # tightest nic
                    sc = after[:, 4]
                elif mode == "sumaw":       # scarcity-weighted sum
                    sc = after @ AW
                elif mode == "dotmin":      # complementary: least shape alignment
                    sc = -(u * dd).sum(1)
                elif mode == "comp":        # dot(used, 1-d)
                    sc = (u * (1.0 - dd)).sum(1)
                elif mode == "bal":         # most balanced + fullest: min-dim then sum
                    sc = after.min(1) + 0.01 * after.sum(1)
                elif mode == "nicmix":      # high non-nic load, reserve nic
                    sc = u[:, [0, 1, 3]].sum(1) - 0.5 * u[:, 4]
                elif mode == "sum_nic":     # sum, nic tiebreak
                    sc = after.sum(1) * 10 + after[:, 4]
                elif mode == "resnic":      # minimize residual nic after, tiebreak sum
                    sc = after[:, 4] * 10 + after.sum(1)
                elif mode == "maxmin_w":    # weighted bottleneck
                    sc = (after * AW).min(1)
                elif mode == "sum":
                    sc = after.sum(1)
                else:
                    sc = after[:, 4]
                return int(idx[int(np.argmax(sc))])
        return f"new:{int(self.cheapest[t])}"
