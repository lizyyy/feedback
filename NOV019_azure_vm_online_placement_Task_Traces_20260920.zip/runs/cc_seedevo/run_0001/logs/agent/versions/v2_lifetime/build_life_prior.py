#!/usr/bin/env python3
"""Build a lifetime prior table from fleet history -> main/lifeprior.npz.

For each (vm_type, priority) we store robust log-lifetime statistics computed
from uncensored VMs that started within the recent history window:
  med   : median lifetime (hours)
  q25,q75: quartiles
  meanlog, sdlog: mean/std of ln(lifetime_h) (Gaussian fit in log space)
  n     : sample count
Unknown / sparse cells fall back to priority-level then global stats.
"""
from pathlib import Path

import numpy as np

APP = Path("/app")
HIST = APP / "data/practice/history_practice.npz"
OUT = APP / "methods/main/lifeprior.npz"

RECENT_DAYS = 30.0


def main():
    z = np.load(HIST)
    vt = z["vm_type"].astype(np.int64)
    pr = z["priority"].astype(np.int64)
    sd, ed = z["start_day"], z["end_day"]
    keep = (sd > -RECENT_DAYS) & np.isfinite(ed) & (ed > sd)
    v, p = vt[keep], pr[keep]
    logd = np.log((ed[keep] - sd[keep]) * 24.0 + 1e-6)

    T, P = 488, 2
    med = np.zeros((T, P))
    meanlog = np.zeros((T, P))
    sdlog = np.ones((T, P))
    n = np.zeros((T, P), dtype=np.int64)

    for t in range(T):
        for pp in range(P):
            m = (v == t) & (p == pp)
            c = int(m.sum())
            n[t, pp] = c
            if c >= 20:
                x = logd[m]
                med[t, pp] = np.median(x)
                meanlog[t, pp] = x.mean()
                sdlog[t, pp] = x.std() if c > 1 else 1.0
    # priority / global priors (from all recent uncensored samples)
    pr_med = np.array([np.median(logd[p == pp]) for pp in range(P)])
    pr_mean = np.array([logd[p == pp].mean() for pp in range(P)])
    pr_sd = np.array([logd[p == pp].std() for pp in range(P)])
    glob_med = np.median(logd)
    glob_mean, glob_sd = logd.mean(), logd.std()

    np.savez(OUT, med=med, meanlog=meanlog, sdlog=sdlog, n=n,
             pr_med=pr_med, pr_mean=pr_mean, pr_sd=pr_sd,
             glob_med=glob_med, glob_mean=glob_mean, glob_sd=glob_sd)
    print("wrote", OUT, "cells with >=20 samples:", int((n >= 20).sum()), "of", 2 * T)


if __name__ == "__main__":
    main()
