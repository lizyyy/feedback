"""Lifetime-aware best-fit allocator (research v2).

Two signals beyond the shipped first-fit starter:

1. Tightness: among feasible non-empty compatible servers prefer the one that
   is most loaded after placement (summed utilisation across the five
   dimensions) -- dense packing.

2. Server closing time: every server carries a predicted closing time
   (max predicted departure of its VMs). Placing a VM on a server predicted to
   outlive it costs nothing in extra server-hours; placing it on a server it
   would outlive extends that server's life. Predicted lifetimes come from a
   prior learned on fleet history (lifeprior.npz) and are adapted online from
   departures actually observed in this window.

Tunables (env, offline A/B only):
  RSII_NEW_THRESH : open new instead of extending when w*ext > w_new*L*thresh
  RSII_LIFE_BLEND : weight of the online-adapted lifetime model (0 = prior only)
"""
import os
from pathlib import Path

import numpy as np

EPS = 1e-9
_HERE = Path(__file__).absolute().parent
if not (_HERE / "lifeprior.npz").exists():
    _HERE = Path.cwd()


class Allocator:
    def reset(self, cluster):
        self.cluster = cluster
        self.machines = None
        self.new_thresh = float(os.environ.get("RSII_NEW_THRESH", "1e9"))
        self.life_blend = float(os.environ.get("RSII_LIFE_BLEND", "1.0"))

    # ------------------------------------------------------------------ setup
    def _init_machines(self, state):
        mac = state.machines
        self.machines = mac
        self.demand = mac.demand
        self.weight = mac.weight
        self.compat = mac.compatible
        self.cheapest = mac.cheapest
        self.T, self.M = mac.n_types, mac.n_machines
        lp = np.load(_HERE / "lifeprior.npz")
        self.prior_mean = lp["meanlog"].copy()
        self.prior_n = lp["n"].astype(np.float64)
        self.pr_mean = lp["pr_mean"].copy()
        self.on_sum = np.zeros((self.T, 2))
        self.on_n = np.zeros((self.T, 2))
        self.close = np.zeros(64)
        self.cap = 64
        self.pend = {}            # vm -> predicted end
        self.info = {}            # vm -> (vm_type, priority, start, server)
        self.evicted = set()
        self._stale = set()

    def pred_loglife(self, t, pr):
        c = self.on_n[t, pr]
        pm = self.prior_mean[t, pr] if self.prior_n[t, pr] >= 20 else self.pr_mean[pr]
        if c > 0:
            w = min(1.0, self.life_blend * c / 20.0)
            return w * (self.on_sum[t, pr] / c) + (1 - w) * pm
        return pm

    def pred_end(self, t, pr, now):
        return now + float(np.exp(self.pred_loglife(t, pr)))

    def _grow(self, n):
        cap = self.cap
        while cap < n:
            cap *= 2
        self.close = np.concatenate([self.close, np.zeros(cap - self.cap)])
        self.cap = cap

    def _close_of(self, s, state):
        c = -np.inf
        for v in state.server_vms[s]:
            pe = self.pend.get(v)
            if pe is not None and pe > c:
                c = pe
        self.close[s] = c if c > -np.inf else state.now

    # ------------------------------------------------------------------ hooks
    def observe_departures(self, departed, state):
        for vm, end in departed:
            info = self.info.pop(vm, None)
            self.pend.pop(vm, None)
            if info is None or vm in self.evicted:
                continue
            t, pr, t0, s = info
            if end > t0:
                self.on_sum[t, pr] += np.log(end - t0 + 1e-6)
                self.on_n[t, pr] += 1
            self._stale.add(s)

    # ------------------------------------------------------------------ decide
    def place(self, request, state):
        if self.machines is None:
            self._init_machines(state)
        vm = request["vm"]
        t = int(request["vm_type"])
        pr = int(request["priority"])
        now = float(state.now)
        n = state.n_servers

        if self._stale:
            for s in self._stale:
                if s < state.n_servers and state.n_vms[s] > 0:
                    self._close_of(s, state)
            self._stale.clear()

        pe = self.pred_end(t, pr, now)
        s_chosen = -1
        if n:
            mt = state.server_type[:n]
            d = self.demand[t][mt]
            used = state.used[:n]
            ok = (self.compat[t][mt]
                  & ((used + d) <= 1.0 + EPS).all(axis=1)
                  & (state.n_vms[:n] > 0))
            idx = np.flatnonzero(ok)
            if idx.size:
                after = used[idx] + d[idx]
                tight = after.sum(axis=1)
                ext = np.maximum(0.0, pe - self.close[idx])
                w = self.weight[mt[idx]]
                no_ext = ext <= 1e-9
                if no_ext.any():
                    sub = np.flatnonzero(no_ext)
                    s_chosen = int(idx[sub[int(np.argmax(tight[sub]))]])
                else:
                    ext_cost = w * ext
                    order = np.lexsort((-tight, ext_cost))
                    j = int(order[0])
                    m_new = int(self.cheapest[t])
                    if ext_cost[j] <= float(self.weight[m_new]) * (pe - now) * self.new_thresh:
                        s_chosen = int(idx[j])

        if s_chosen < 0:
            m_new = int(self.cheapest[t])
            dec = f"new:{m_new}"
            s_chosen = n
            if s_chosen >= self.cap:
                self._grow(s_chosen + 1)
        else:
            dec = s_chosen

        self.pend[vm] = pe
        self.info[vm] = (t, pr, now, s_chosen)
        if pe > self.close[s_chosen]:
            self.close[s_chosen] = pe
        return dec
