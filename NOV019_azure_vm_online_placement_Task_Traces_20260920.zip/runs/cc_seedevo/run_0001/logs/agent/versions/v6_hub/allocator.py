"""Placement policy v6: nic-hub consolidation + sum best-fit.

Why: the fleet is nic-bound and the common high-volume VM types are cross-certified
on machine 23, which is cheaper per server-hour (weight 0.683 vs 1.0 for machine 1)
and has ~1.25x the nic capacity, at only ~5% premium in weight*dominant-share.
The starter opens each VM on its individually cheapest machine, fragmenting these
types across pools {m1, m8, m15, m16, m23, ...}; consolidating near-cheapest types
onto the m23 hub packs the nic dimension far tighter (validated +0.1..+0.37 on
practice days with zero failed placements).

Rules:
  * fit on an existing non-empty server: compatible and within capacity in all five
    dimensions, choose the server with the greatest total post-placement load (best
    fit by sum of fractional loads);
  * else open a new server: machine 23 when the type is certified there and its
    weight*dominant-share is within 15% of its cheapest machine; otherwise cheapest.
"""
import numpy as np

EPS = 1e-9
HUB = 23
BAND = 0.15


class Allocator:
    def reset(self, cluster):
        self.cluster = cluster
        self.machines = None

    def _init(self, state):
        mac = state.machines
        self.demand = mac.demand
        self.weight = mac.weight
        self.compat = mac.compatible
        self.cheapest = mac.cheapest
        n_types = mac.demand.shape[0]
        dom = mac.demand.max(axis=2)
        wdom = self.weight[None, :] * np.where(self.compat, dom, np.inf)
        cheapest = wdom.argmin(axis=1)
        take = self.compat[:, HUB] & (wdom[:, HUB] <= (1.0 + BAND) * wdom.min(axis=1))
        self.choice = cheapest
        self.choice[take] = HUB

    def place(self, request, state):
        if self.machines is None:
            self._init(state)
            self.machines = 1
        t = int(request["vm_type"])
        n = state.n_servers
        if n:
            mt = state.server_type[:n]
            d_all = self.demand[t][mt]
            ok = (self.compat[t][mt]
                  & ((state.used[:n] + d_all) <= 1.0 + EPS).all(axis=1)
                  & (state.n_vms[:n] > 0))
            idx = np.flatnonzero(ok)
            if idx.size:
                after = state.used[:n][idx] + d_all[idx]
                return int(idx[int(np.argmax(after.sum(axis=1)))])
        return f"new:{int(self.choice[t])}"
