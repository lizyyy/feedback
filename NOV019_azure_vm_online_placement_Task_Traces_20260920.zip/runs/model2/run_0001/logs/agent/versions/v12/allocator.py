"""Starter allocator: first fit.

What a simple cluster allocator does: walk the non-empty servers in the order they were opened and put the VM on the
first one whose machine type can run it and that still has room in every dimension. If none has room, open a new
server of the machine type on which this VM type is cheapest (weight x dominant share).

It ignores lifetimes, priorities, tenants, how full a server already is, and which machine type suits the VM mix.
"""
import numpy as np
from collections import deque


class Allocator:
    def reset(self, cluster):
        """cluster: machines_file, instance {id, t0_trace_day, warmup_h, horizon_h, n_hours}, penalties, budgets."""
        self.cluster = cluster
        z = np.load(cluster["machines_file"])
        raw, weight = z["demand"], z["weight"]
        compatible = ~np.isnan(raw[:, :, 0])
        demand = np.where(compatible[:, :, None], np.nan_to_num(raw, nan=0.0), 0.0)
        dom = demand.max(axis=2)
        base = np.where(compatible, weight[None, :] * dom, np.inf)
        blend = np.where(compatible,
                         weight[None, :] * (dom + 0.75 * (demand.sum(axis=2) - dom)), np.inf)
        self.base_type = np.argmin(base, axis=1)
        self.blend_type = np.argmin(blend, axis=1)
        self.n_request = 0
        self.n_low = 0
        self.recent = deque(maxlen=32768)
        self.recent_low = 0

    def place(self, request, state):
        """request: {vm, vm_type, priority, tenant, time}; state: cluster.ClusterState (read it, do not modify it)."""
        t = request["vm_type"]
        self.n_request += 1
        self.n_low += int(request["priority"])
        if len(self.recent) == self.recent.maxlen:
            self.recent_low -= self.recent[0]
        pr = int(request["priority"])
        self.recent.append(pr)
        self.recent_low += pr
        n = state.n_servers
        if n:
            ok = state.fits_mask(t) & (state.n_vms[:n] > 0)
            k = int(ok.argmax())
            if ok[k]:
                return k
        # The trace has two visibly different operating regimes.  A low share
        # of preemptible work means complementary shapes dominate, while a
        # substantial low-priority stream favors the conservative per-VM
        # dominant-share choice.  Infer the regime online, without day IDs.
        mixed = len(self.recent) >= 256 and self.recent_low * 10 < len(self.recent)
        choice = self.blend_type if mixed else self.base_type
        return f"new:{int(choice[t])}"
