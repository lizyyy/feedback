"""Starter allocator: first fit.

What a simple cluster allocator does: walk the non-empty servers in the order they were opened and put the VM on the
first one whose machine type can run it and that still has room in every dimension. If none has room, open a new
server of the machine type on which this VM type is cheapest (weight x dominant share).

It ignores lifetimes, priorities, tenants, how full a server already is, and which machine type suits the VM mix.
"""
import numpy as np


class Allocator:
    def reset(self, cluster):
        """cluster: machines_file, instance {id, t0_trace_day, warmup_h, horizon_h, n_hours}, penalties, budgets."""
        self.cluster = cluster
        z = np.load(cluster["machines_file"])
        raw, weight = z["demand"], z["weight"]
        compatible = ~np.isnan(raw[:, :, 0])
        demand = np.where(compatible[:, :, None], np.nan_to_num(raw, nan=0.0), 0.0)
        dom = demand.max(axis=2)
        base = np.where(compatible, weight[None, :] * dom, np.inf)
        blend = np.where(compatible,
                         weight[None, :] * (dom + 0.75 * (demand.sum(axis=2) - dom)), np.inf)
        self.base_type = np.argmin(base, axis=1)
        self.blend_type = np.argmin(blend, axis=1)
        self.n_request = 0
        self.n_low = 0
        self.last = {}
        self.previous = {}

    def place(self, request, state):
        """request: {vm, vm_type, priority, tenant, time}; state: cluster.ClusterState (read it, do not modify it)."""
        t = request["vm_type"]
        self.n_request += 1
        self.n_low += int(request["priority"])
        n = state.n_servers
        if n:
            for which, s in ((0, self.last.get(t, -1)), (1, self.previous.get(t, -1))):
                if 0 <= s < n and state.n_vms[s] > 0:
                    m = state.server_type[s]
                    if (state.machines.compatible[t, m]
                            and np.all(state.used[s] + state.machines.demand[t, m] <= 1.0 + 1e-9)):
                        if which:
                            self.previous[t], self.last[t] = self.last.get(t, -1), s
                        return s
            ok = state.fits_mask(t) & (state.n_vms[:n] > 0)
            k = int(ok.argmax())
            if ok[k]:
                old = self.last.get(t, -1)
                if old != k:
                    self.previous[t] = old
                self.last[t] = k
                return k
        # The trace has two visibly different operating regimes.  A low share
        # of preemptible work means complementary shapes dominate, while a
        # substantial low-priority stream favors the conservative per-VM
        # dominant-share choice.  Infer the regime online, without day IDs.
        mixed = self.n_request >= 256 and self.n_low * 10 < self.n_request
        choice = self.blend_type if mixed else self.base_type
        old = self.last.get(t, -1)
        if old != n:
            self.previous[t] = old
        self.last[t] = n
        return f"new:{int(choice[t])}"
