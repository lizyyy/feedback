"""Cost-aware multidimensional best-fit allocator."""
import numpy as np


class Allocator:
    def reset(self, cluster):
        """cluster: machines_file, instance {id, t0_trace_day, warmup_h, horizon_h, n_hours}, penalties, budgets."""
        self.cluster = cluster

    def place(self, request, state):
        t = request["vm_type"]
        n = state.n_servers
        if n:
            fits = state.fits_mask(t)
            opened = fits & (state.n_vms[:n] > 0)
            if opened.any():
                ids = np.flatnonzero(opened)
                mt = state.server_type[ids]
                post = state.used[ids] + state.machines.demand[t, mt]
                # Squared fill rewards a tight fit in scarce dimensions and leaves
                # less-fragmented servers for subsequent, differently shaped VMs.
                return int(ids[np.argmax(np.einsum("ij,ij->i", post, post))])
            # Reopening an existing server is equivalent to opening a new one, but
            # only reuse the generation selected by the machine cost model.
            empty = fits & (state.n_vms[:n] == 0) & (state.server_type[:n] == state.machines.cheapest[t])
            if empty.any():
                return int(np.flatnonzero(empty)[0])
        return f"new:{int(state.machines.cheapest[t])}"
