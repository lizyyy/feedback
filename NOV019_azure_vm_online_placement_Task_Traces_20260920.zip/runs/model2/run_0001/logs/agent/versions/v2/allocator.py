"""Starter allocator: first fit.

What a simple cluster allocator does: walk the non-empty servers in the order they were opened and put the VM on the
first one whose machine type can run it and that still has room in every dimension. If none has room, open a new
server of the machine type on which this VM type is cheapest (weight x dominant share).

It ignores lifetimes, priorities, tenants, how full a server already is, and which machine type suits the VM mix.
"""
import numpy as np


class Allocator:
    def reset(self, cluster):
        """cluster: machines_file, instance {id, t0_trace_day, warmup_h, horizon_h, n_hours}, penalties, budgets."""
        self.cluster = cluster
        self.last = {}

    def place(self, request, state):
        """request: {vm, vm_type, priority, tenant, time}; state: cluster.ClusterState (read it, do not modify it)."""
        t = request["vm_type"]
        n = state.n_servers
        if n:
            s = self.last.get(t, -1)
            if 0 <= s < n and state.n_vms[s] > 0:
                m = state.server_type[s]
                if (state.machines.compatible[t, m]
                        and np.all(state.used[s] + state.machines.demand[t, m] <= 1.0 + 1e-9)):
                    return s
            ok = state.fits_mask(t) & (state.n_vms[:n] > 0)
            k = int(ok.argmax())
            if ok[k]:
                self.last[t] = k
                return k
        self.last[t] = n
        return f"new:{int(state.machines.cheapest[t])}"
