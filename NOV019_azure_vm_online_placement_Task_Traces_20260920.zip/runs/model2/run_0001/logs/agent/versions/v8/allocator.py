"""Starter allocator: first fit.

What a simple cluster allocator does: walk the non-empty servers in the order they were opened and put the VM on the
first one whose machine type can run it and that still has room in every dimension. If none has room, open a new
server of the machine type on which this VM type is cheapest (weight x dominant share).

It ignores lifetimes, priorities, tenants, how full a server already is, and which machine type suits the VM mix.
"""
import numpy as np


class Allocator:
    def reset(self, cluster):
        """cluster: machines_file, instance {id, t0_trace_day, warmup_h, horizon_h, n_hours}, penalties, budgets."""
        self.cluster = cluster
        z = np.load(cluster["machines_file"])
        raw, weight = z["demand"], z["weight"]
        compatible = ~np.isnan(raw[:, :, 0])
        demand = np.where(compatible[:, :, None], np.nan_to_num(raw, nan=0.0), 0.0)
        dom = demand.max(axis=2)
        score = np.where(compatible,
                         weight[None, :] * (dom + 0.75 * (demand.sum(axis=2) - dom)),
                         np.inf)
        self.new_type = np.argmin(score, axis=1)

    def place(self, request, state):
        """request: {vm, vm_type, priority, tenant, time}; state: cluster.ClusterState (read it, do not modify it)."""
        t = request["vm_type"]
        n = state.n_servers
        if n:
            ok = state.fits_mask(t) & (state.n_vms[:n] > 0)
            if request["priority"]:
                preferred = ok & (state.n_low[:n] == state.n_vms[:n])
            else:
                preferred = ok & (state.n_low[:n] == 0)
            k = int(preferred.argmax())
            if preferred[k]:
                return k
            k = int(ok.argmax())
            if ok[k]:
                return k
        return f"new:{int(self.new_type[t])}"
