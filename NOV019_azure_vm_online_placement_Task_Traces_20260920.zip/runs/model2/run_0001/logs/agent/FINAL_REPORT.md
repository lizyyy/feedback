# Final report

## Submitted method

Version **v41** is submitted in `methods/main/allocator.py`. It is a deterministic online allocator that:

- learns the current workload regime from the cumulative low-priority request share, without using instance IDs,
  tenants, arrival-time constants, or departure information;
- uses conservative weighted dominant-share machine selection in the high-low-priority regime and a weighted L2
  resource norm when low-priority share is below 10%;
- first tries a per-VM-type locality cache, then the oldest feasible server of the currently preferred generation,
  then ordinary oldest-first placement;
- reuses the oldest empty server of the preferred generation in the low-share regime, without promoting that reuse
  into the locality cache.

It performs no evictions and produced zero invalid or failed placements in every full reading.

## Result and selection rationale

The shipped v0 baseline scored 0.000000 with total practice server cost 371400.52. Submitted v41 scored
**0.2533524283660306** with total server cost **363831.58817915496**, zero failures, and per-day scores:

`[0.168949, 0.202729, 0.206375, 0.215502, 0.225100, 0.419305, 0.335508]`.

The full result reproduced exactly on runs 52, 59, 63, and 64. v41 was selected over v32 (0.252584) and v36
(0.251813) because it had the best full mean and the best mean on the temporally latest P005/P006 pair, which is the
most relevant forward proxy for sealed days 7--13. It also remained positive on every practice day.

## Generalization protocol

Experiments were judged by full seven-day readings, per-day consistency, and a forward-time proxy. P006 was treated
as a lightly consulted temporal holdout early in research; after the main policy family stabilized, P005/P006 were
used together for quick screening and every promoted candidate received a full reading. Selection prioritized gains
that held across all days while giving additional weight to the latest days because the sealed split immediately
follows practice in trace time. No instance IDs, tenant IDs, exact arrival times, or practice departure times are
encoded in the submitted policy.

## What worked

- Adaptive machine selection was essential: pure total-share/L2 selection helped late days but badly hurt earlier
  regimes, while cumulative low-priority share provided a simple online switch.
- Per-type locality reduced CPU and improved most days once paired with better machine selection.
- Preferring an already-open server of the target generation produced the largest broad gain.
- Reusing an old empty target-generation server helped late-day cost and CPU, but keeping reuse separate from the
  type-locality cache was crucial.
- Stable oldest-first ordering consistently beat newest-first, density, and instantaneous best-fit variants.

## What did not work

Squared-utilization best-fit, newest-first packing, priority segregation, tenant locality, history-derived lifetime
classes, conservative low-priority eviction, multiple cache entries, dimension reweighting, L1/L1.5/L2.5 norms,
and removing the adaptive regime gate all regressed. Forced L2 on boundary day P004 scored -0.470640, strongly
confirming the need for the online workload gate.

All measured versions v0--v50 are preserved under `methods/versions/`, all self-check artifacts are under
`methods/selfcheck_runs/`, and the complete experimental record is in `methods/experiment_log.md`.
