"""Capacity-priced, lifetime-aware allocator.

Idea
----
Cost is the time integral of the weight of every non-empty server, so what a placement really spends is the
*usable capacity* it burns.  For machine type m let p[m] be the normalised aggregate demand profile of the
arriving VM mix measured on m (max component 1).  A server of type m with residual capacity r can still absorb

    U(r) = min_k r[k] / p[m,k]          in [0, 1]  (1 for an empty server)

"average server-loads" worth of future work, i.e. w[m] * U(r) of weighted capacity.  Placing a VM therefore
costs  w[m] * (U(r) - U(r - d)) : zero on a server that is already dead in some dimension, small when the VM's
shape matches what is left, large when it kills a dimension that still had value.  Minimising that sum is
exactly minimising total weighted server capacity, and it also tells us which machine type to open.

The same score chooses among existing servers (fragmentation aware, ties go to the oldest server, which keeps
the fleet consolidated) and which machine type a new server should have (shape aware -- the trace's binding
dimension is nic, not memory).

Time is the second half of the cost.  A server is paid for until its LAST vm leaves, so a long-lived vm dropped
on a server that was about to drain buys w * (its remaining life) of pure waste.  Writing L for the predicted
life of the request (a per (vm type, priority) table learned from the fleet history) and R for the predicted
remaining open time of a server, the cost of a placement in units of w * L is

    score(s) = w[s] * ( dU(s) + LAM * max(0, 1 - R(s)/L) )

-- the capacity it burns for L hours, plus the hours of server life it adds.  R comes from two monotone lower
bounds: the largest predicted end time among the vms already there, and the server's own age (lifetimes here are
heavy tailed, so a server that has been up for a long time will stay up).  A brand-new server has R = 0, which
gives opening one its natural price.
"""
import numpy as np

try:
    from _freq import FREQ_PPM
except Exception:                                     # pragma: no cover
    FREQ_PPM = None
import os

P_FLOOR = 1e-3            # a dimension nobody asks for is never treated as scarce
BIG = 1e9


class Allocator:
    THETA = 0.0           # extra pressure towards the fullest server (best fit)
    OPEN_MULT = None      # None: open a new server only when nothing fits
    LAM = 1.0             # weight of the server-lifetime-extension term
    AGE_C = 1.0           # predicted remaining open time of a server >= AGE_C * its age
    LMIN = 0.05           # floor on the predicted life of a request (hours)

    def _cfg(self, name, default):
        """Parameters are class attributes; ALLOC_<NAME> in the environment overrides one (research sweeps)."""
        v = os.environ.get("ALLOC_" + name)
        if v is None:
            return default
        try:
            return None if v == "none" else float(v)
        except Exception:
            return default

    # ------------------------------------------------------------------ setup
    def reset(self, cluster):
        for _k in ("THETA", "OPEN_MULT", "LAM", "AGE_C", "LMIN"):
            setattr(self, _k, self._cfg(_k, getattr(self, _k)))
        z = np.load(cluster["machines_file"])
        raw = np.asarray(z["demand"], dtype=np.float64)
        self.w = np.asarray(z["weight"], dtype=np.float64)
        nt, nm, nd = raw.shape
        self.nt, self.nm, self.nd = nt, nm, nd
        comp = ~np.isnan(raw[:, :, 0])
        self.comp = comp
        self.dem = np.where(comp[:, :, None], np.nan_to_num(raw, nan=0.0), 0.0)
        f = None
        if FREQ_PPM is not None and len(FREQ_PPM) == nt:
            f = np.asarray(FREQ_PPM, dtype=np.float64)
        if f is None or f.sum() <= 0:
            f = np.ones(nt, dtype=np.float64)
        self.f = f
        P = np.ones((nm, nd))
        for m in range(nm):
            fm = f * comp[:, m]
            if fm.sum() > 0:
                p = (fm[:, None] * self.dem[:, m, :]).sum(axis=0)
                if p.max() > 0:
                    P[m] = np.maximum(p / p.max(), P_FLOOR)
        self.P = P
        self.invP = 1.0 / P                                    # residual of an empty server, scaled
        self.DOP = self.dem / P[None, :, :]                    # (nt, nm, nd) demand in scaled units
        self.DOP[~comp] = BIG                                  # an incompatible machine type never fits
        self.DOPT = np.ascontiguousarray(self.DOP.transpose(0, 2, 1))   # (nt, nd, nm)
        ue = self.invP.min(axis=1)                             # == 1.0
        dopc = np.where(comp[:, :, None], self.DOP, 0.0)
        newc = self.w[None, :] * (ue[None, :] - (self.invP[None, :, :] - dopc).min(axis=2))
        self.newcost = np.where(comp, newc, np.inf) + self.LAM * self.w[None, :]   # a new server has R = 0
        self.best_new = np.argmin(self.newcost, axis=1).astype(np.int64)
        self.best_newcost = self.newcost[np.arange(nt), self.best_new]
        self.diag = os.environ.get("ALLOC_DIAG") or None
        self._diag_next = 0.0
        self._srv_cap = 8192
        self.md = np.zeros(self._srv_cap)          # max predicted end time of the vms on a server
        self.open_t = np.zeros(self._srv_cap)      # when the server became non-empty
        self.cheapest = np.argmin(np.where(comp, self.w[None, :] * self.dem.max(axis=2), np.inf), axis=1)
        # predicted life (hours, capped at one window) per (vm type, priority)
        self.life = np.full(2 * nt, 4.5)
        try:
            zl = np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), "_life.npz"))
            v = np.asarray(zl["mean24"], dtype=np.float64)
            if len(v) == 2 * nt:
                self.life = np.maximum(v, self.LMIN)
        except Exception:
            pass
        self.invlife = 1.0 / np.maximum(self.life, self.LMIN)
        # compacted view of the non-empty servers, rebuilt once per decision batch
        self._cap = 0
        self.n = 0
        self._grow(4096)
        self.t_mark = -1.0
        self.empty_ids = np.zeros(0, dtype=np.int64)
        self.empty_mt = np.zeros(0, dtype=np.int64)

    def _grow(self, need):
        cap = max(1024, self._cap)
        while cap < need:
            cap *= 2
        if cap == self._cap:
            return
        n = self.n
        A = np.zeros((self.nd, cap)); ub = np.zeros(cap); mt = np.zeros(cap, np.int64)
        wj = np.zeros(cap); sid = np.zeros(cap, np.int64); R = np.zeros(cap)
        if n:
            A[:, :n] = self._A[:, :n]; ub[:n] = self._ub[:n]; mt[:n] = self._mt[:n]
            wj[:n] = self._w[:n]; sid[:n] = self._sid[:n]; R[:n] = self._R[:n]
        self._A, self._ub, self._mt, self._w, self._sid, self._R = A, ub, mt, wj, sid, R
        self._cap = cap

    # ------------------------------------------------------- per-batch resync
    def _rebuild(self, state):
        N = state.n_servers
        nv = state.n_vms[:N]
        ids = np.flatnonzero(nv > 0)
        n = len(ids)
        self._grow(n + 64)
        mt = state.server_type[ids].astype(np.int64)
        A = ((1.0 - state.used[ids]) * self.invP[mt]).T
        self._A[:, :n] = A
        self._ub[:n] = A.min(axis=0)
        self._mt[:n] = mt
        self._w[:n] = self.w[mt]
        self._sid[:n] = ids
        if N > self._srv_cap:
            cap = self._srv_cap
            while cap < N + 1:
                cap *= 2
            md = np.zeros(cap); md[:self._srv_cap] = self.md; self.md = md
            ot = np.zeros(cap); ot[:self._srv_cap] = self.open_t; self.open_t = ot
            self._srv_cap = cap
        now = state.now
        self._R[:n] = np.maximum(self.md[ids] - now, self.AGE_C * (now - self.open_t[ids]))
        self.n = n
        if self.diag is not None and now >= self._diag_next:
            self._diag_next = now + 1.0
            try:
                ub = self._ub[:n]; wj = self._w[:n]; nv = state.n_vms[ids]
                h = np.histogram(ub, bins=[0, .05, .1, .2, .3, .5, .7, .9, 1.01])[0]
                with open(self.diag, "a") as fh:
                    fh.write("t=%.2f n=%d wsum=%.1f waste=%.1f wsingle=%.1f nsingle=%d age=%.2f ubhist=%s\n" % (
                        now, n, wj.sum(), (wj * ub).sum(), wj[nv <= 2].sum(), int((nv <= 2).sum()),
                        float(np.mean(now - self.open_t[ids])), list(h)))
            except Exception:
                pass
        e = np.flatnonzero(nv == 0)
        self.empty_ids = e
        self.empty_mt = state.server_type[e].astype(np.int64)

    def _append(self, sid, m, dop, now, life):
        n = self.n
        if n + 1 > self._cap:
            self._grow(n + 1)
        row = self.invP[m] - dop
        self._A[:, n] = row
        self._ub[n] = row.min()
        self._mt[n] = m
        self._w[n] = self.w[m]
        self._sid[n] = sid
        self._R[n] = life
        if sid < self._srv_cap:
            self.md[sid] = now + life
            self.open_t[sid] = now
        self.n = n + 1

    def _open(self, state, t, m, life):
        dop = self.DOP[t, m]
        now = state.now
        if len(self.empty_ids):
            k = np.flatnonzero(self.empty_mt == m)
            if len(k):
                k = int(k[0])
                sid = int(self.empty_ids[k])
                self.empty_mt[k] = -1
                self._append(sid, m, dop, now, life)
                return sid
        self._append(int(state.n_servers), m, dop, now, life)
        return "new:%d" % m

    # ------------------------------------------------------------- the policy
    def place(self, request, state):
        t = request["vm_type"]
        try:
            now = state.now
            if now != self.t_mark:
                self.t_mark = now
                self._rebuild(state)
            k = 2 * t + (1 if request["priority"] else 0)
            life = self.life[k]
            n = self.n
            if n:
                dg = self.DOPT[t][:, self._mt[:n]]
                B = self._A[:, :n] - dg
                ua = B.min(axis=0)
                c = self._ub[:n] - ua
                if self.LAM:
                    c += self.LAM * np.maximum(0.0, 1.0 - self._R[:n] * self.invlife[k])
                c *= self._w[:n]
                if self.THETA:
                    c += self.THETA * self._ub[:n]
                c = np.where(ua >= 0.0, c, np.inf)
                j = int(c.argmin())
                if c[j] < np.inf:
                    take = True
                    if self.OPEN_MULT is not None and c[j] > self.OPEN_MULT * self.best_newcost[t]:
                        take = False
                    if take:
                        sid = int(self._sid[j])
                        m = int(self._mt[j])
                        if self.comp[t, m] and (state.used[sid] + self.dem[t, m] <= 1.0).all():
                            self._A[:, j] = B[:, j]
                            self._ub[j] = ua[j]
                            e = now + life
                            if sid < self._srv_cap and self.md[sid] < e:
                                self.md[sid] = e
                                if self._R[j] < life:
                                    self._R[j] = life
                            return sid
            return self._open(state, t, int(self.best_new[t]), life)
        except Exception:                                      # never crash a batch
            return "new:%d" % int(self.cheapest[t])
