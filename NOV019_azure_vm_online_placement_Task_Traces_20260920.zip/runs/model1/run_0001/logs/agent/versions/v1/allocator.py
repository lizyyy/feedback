"""Capacity-priced best-fit allocator.

Idea
----
Cost is the time integral of the weight of every non-empty server, so what a placement really spends is the
*usable capacity* it burns.  For machine type m let p[m] be the normalised aggregate demand profile of the
arriving VM mix measured on m (max component 1).  A server of type m with residual capacity r can still absorb

    U(r) = min_k r[k] / p[m,k]          in [0, 1]  (1 for an empty server)

"average server-loads" worth of future work, i.e. w[m] * U(r) of weighted capacity.  Placing a VM therefore
costs  w[m] * (U(r) - U(r - d)) : zero on a server that is already dead in some dimension, small when the VM's
shape matches what is left, large when it kills a dimension that still had value.  Minimising that sum is
exactly minimising total weighted server capacity, and it also tells us which machine type to open.

The same score chooses among existing servers (fragmentation aware, ties go to the oldest server, which keeps
the fleet consolidated) and which machine type a new server should have (shape aware -- the trace's binding
dimension is nic, not memory).
"""
import numpy as np

try:
    from _freq import FREQ_PPM
except Exception:                                     # pragma: no cover
    FREQ_PPM = None

P_FLOOR = 1e-3            # a dimension nobody asks for is never treated as scarce
BIG = 1e9


class Allocator:
    THETA = 0.0           # extra pressure towards the fullest server (best fit) 
    OPEN_MULT = None      # None: open a new server only when nothing fits

    # ------------------------------------------------------------------ setup
    def reset(self, cluster):
        z = np.load(cluster["machines_file"])
        raw = np.asarray(z["demand"], dtype=np.float64)
        self.w = np.asarray(z["weight"], dtype=np.float64)
        nt, nm, nd = raw.shape
        self.nt, self.nm, self.nd = nt, nm, nd
        comp = ~np.isnan(raw[:, :, 0])
        self.comp = comp
        self.dem = np.where(comp[:, :, None], np.nan_to_num(raw, nan=0.0), 0.0)
        f = None
        if FREQ_PPM is not None and len(FREQ_PPM) == nt:
            f = np.asarray(FREQ_PPM, dtype=np.float64)
        if f is None or f.sum() <= 0:
            f = np.ones(nt, dtype=np.float64)
        self.f = f
        P = np.ones((nm, nd))
        for m in range(nm):
            fm = f * comp[:, m]
            if fm.sum() > 0:
                p = (fm[:, None] * self.dem[:, m, :]).sum(axis=0)
                if p.max() > 0:
                    P[m] = np.maximum(p / p.max(), P_FLOOR)
        self.P = P
        self.invP = 1.0 / P                                    # residual of an empty server, scaled
        self.DOP = self.dem / P[None, :, :]                    # (nt, nm, nd) demand in scaled units
        self.DOP[~comp] = BIG                                  # an incompatible machine type never fits
        self.DOPT = np.ascontiguousarray(self.DOP.transpose(0, 2, 1))   # (nt, nd, nm)
        ue = self.invP.min(axis=1)                             # == 1.0
        dopc = np.where(comp[:, :, None], self.DOP, 0.0)
        newc = self.w[None, :] * (ue[None, :] - (self.invP[None, :, :] - dopc).min(axis=2))
        self.newcost = np.where(comp, newc, np.inf)
        self.best_new = np.argmin(self.newcost, axis=1).astype(np.int64)
        self.best_newcost = self.newcost[np.arange(nt), self.best_new]
        self.cheapest = np.argmin(np.where(comp, self.w[None, :] * self.dem.max(axis=2), np.inf), axis=1)
        # compacted view of the non-empty servers, rebuilt once per decision batch
        self._cap = 0
        self.n = 0
        self._grow(4096)
        self.t_mark = -1.0
        self.empty_ids = np.zeros(0, dtype=np.int64)
        self.empty_mt = np.zeros(0, dtype=np.int64)

    def _grow(self, need):
        cap = max(1024, self._cap)
        while cap < need:
            cap *= 2
        if cap == self._cap:
            return
        n = self.n
        A = np.zeros((self.nd, cap)); ub = np.zeros(cap); mt = np.zeros(cap, np.int64)
        wj = np.zeros(cap); sid = np.zeros(cap, np.int64)
        if n:
            A[:, :n] = self._A[:, :n]; ub[:n] = self._ub[:n]; mt[:n] = self._mt[:n]
            wj[:n] = self._w[:n]; sid[:n] = self._sid[:n]
        self._A, self._ub, self._mt, self._w, self._sid = A, ub, mt, wj, sid
        self._cap = cap

    # ------------------------------------------------------- per-batch resync
    def _rebuild(self, state):
        N = state.n_servers
        nv = state.n_vms[:N]
        ids = np.flatnonzero(nv > 0)
        n = len(ids)
        self._grow(n + 64)
        mt = state.server_type[ids].astype(np.int64)
        A = ((1.0 - state.used[ids]) * self.invP[mt]).T
        self._A[:, :n] = A
        self._ub[:n] = A.min(axis=0)
        self._mt[:n] = mt
        self._w[:n] = self.w[mt]
        self._sid[:n] = ids
        self.n = n
        e = np.flatnonzero(nv == 0)
        self.empty_ids = e
        self.empty_mt = state.server_type[e].astype(np.int64)

    def _append(self, sid, m, dop):
        n = self.n
        if n + 1 > self._cap:
            self._grow(n + 1)
        row = self.invP[m] - dop
        self._A[:, n] = row
        self._ub[n] = row.min()
        self._mt[n] = m
        self._w[n] = self.w[m]
        self._sid[n] = sid
        self.n = n + 1

    def _open(self, state, t, m):
        dop = self.DOP[t, m]
        if len(self.empty_ids):
            k = np.flatnonzero(self.empty_mt == m)
            if len(k):
                k = int(k[0])
                sid = int(self.empty_ids[k])
                self.empty_mt[k] = -1
                self._append(sid, m, dop)
                return sid
        self._append(int(state.n_servers), m, dop)
        return "new:%d" % m

    # ------------------------------------------------------------- the policy
    def place(self, request, state):
        t = request["vm_type"]
        try:
            if state.now != self.t_mark:
                self.t_mark = state.now
                self._rebuild(state)
            n = self.n
            if n:
                dg = self.DOPT[t][:, self._mt[:n]]
                B = self._A[:, :n] - dg
                ua = B.min(axis=0)
                c = self._w[:n] * (self._ub[:n] - ua)
                if self.THETA:
                    c += self.THETA * self._ub[:n]
                c = np.where(ua >= 0.0, c, np.inf)
                j = int(c.argmin())
                if c[j] < np.inf:
                    take = True
                    if self.OPEN_MULT is not None and c[j] > self.OPEN_MULT * self.best_newcost[t]:
                        take = False
                    if take:
                        sid = int(self._sid[j])
                        m = int(self._mt[j])
                        if self.comp[t, m] and (state.used[sid] + self.dem[t, m] <= 1.0).all():
                            self._A[:, j] = B[:, j]
                            self._ub[j] = ua[j]
                            return sid
            return self._open(state, t, int(self.best_new[t]))
        except Exception:                                      # never crash a batch
            return "new:%d" % int(self.cheapest[t])
