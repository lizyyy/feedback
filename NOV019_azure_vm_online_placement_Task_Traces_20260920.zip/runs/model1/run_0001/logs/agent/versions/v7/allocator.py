"""Online VM placement: keep the residual VALUE of the fleet, priced by the packing LP's own dual.

A server is paid for by the hour as long as it is non-empty, so the only real currency is *server value*: the
weighted share of a machine that can still be sold to future VMs.  For a residual r (free fraction per dimension)

    U_m(r) = max { sum_i x_i s_i : sum_i x_i d_i <= r, x >= 0 },   s_i = max_k d_i[k]
           = min { a.r : a.d_i >= s_i for all i, a >= 0 }          (LP duality)

is exactly that: the largest total server-share of VMs the residual can still absorb, given the vm shapes machine
type m admits.  Being a min of linear functions it is concave and piecewise linear; `_vert.npz` holds the dual
vertices a^v (offline, from machines.npz and the pre-day-7 arrival frequencies only), scaled so U_m(1) = 1.
Placing a VM of type t on server s destroys  w[m] * (U(r) - U(r - d[t,m]))  of value, and opening a fresh server of
type m costs  w[m] * (1 - U_m(1 - d[t,m])).  Both are the SAME number, so the choice "which server / open which
machine type" is one argmin over one value function -- no separate routing rule, no tunable weights.

Why this shape and not Leontief min_k r_k/p_k (the natural first guess, and what v1 used): a fixed mix p declares
any unbalanced residual worthless (min = 0 as soon as one dimension is tight), so the policy creates such residuals
for free.  The LP form knows a core-rich / nic-poor residual can still be sold to a core-heavy vm type, because it
may adapt the mix; Leontief is the single fixed-mix vertex of exactly this polyhedron.

Cost per decision: a gather plus (n_dims + n_vertices) * n_servers flops, all numpy, no python loop over servers.
"""
import os

import numpy as np

EPS = 1e-9
P_FLOOR = 1e-3
BIG = 1e9


class Allocator:
    VCAP = 8             # dual vertices kept per machine type
    TIE = "bf"           # tie-break among equal value prices: bf (tightest) | old (lowest id) | vms
    TOL = 0.0            # what counts as a tie in the value price
    REUSE = 1            # reuse an existing empty server of the right machine type before opening a new one

    # ------------------------------------------------------------------ setup
    def _cfg(self, name, default):
        v = os.environ.get("ALLOC_" + name)
        if v is None:
            return default
        if v.lower() in ("none", "off"):
            return None
        try:
            return float(v) if ("." in v or "e" in v.lower()) else int(v)
        except ValueError:
            return v

    def reset(self, cluster):
        for k in ("VCAP", "TIE", "TOL", "REUSE"):
            setattr(self, k, self._cfg(k, getattr(self, k)))
        here = os.path.dirname(os.path.abspath(__file__))
        z = np.load(cluster["machines_file"])
        raw = np.asarray(z["demand"], dtype=np.float64)
        self.w = np.asarray(z["weight"], dtype=np.float64)
        nt, nm, nd = raw.shape
        self.nt, self.nm, self.nd = nt, nm, nd
        self.comp = ~np.isnan(raw[:, :, 0])
        self.dem = np.where(self.comp[:, :, None], np.nan_to_num(raw, nan=0.0), 0.0)
        self.cheapest = np.argmin(np.where(self.comp, self.w[None, :] * self.dem.max(axis=2), np.inf), axis=1)

        AV = self._vertices(here, nt, nm, nd)
        V = AV.shape[1]
        self.V = V
        u1 = (AV.sum(axis=2)).min(axis=1)                      # U_m(1) before scaling
        AV = AV / np.maximum(u1, 1e-12)[:, None, None]         # so an empty server is worth exactly 1.0
        self.AV = np.ascontiguousarray(AV)
        # value of one vm of type t on machine m under vertex v
        G = np.einsum("mvk,tmk->tvm", self.AV, self.dem)
        G = np.where(self.comp[:, None, :], G, -BIG)           # incompatible: never chosen (masked anyway)
        self.G = np.ascontiguousarray(G)
        # price of a fresh server of type m for a vm of type t
        Ur1 = self.AV.sum(axis=2).T                            # (V, nm), == 1.0 at the argmin vertex
        newc = self.w[None, :] * (1.0 - (Ur1[None, :, :] - self.G).min(axis=1))
        self.newcost = np.where(self.comp, newc, np.inf)
        self.best_new = np.argmin(self.newcost, axis=1).astype(np.int64)
        self.best_newcost = self.newcost[np.arange(nt), self.best_new]
        self.Ur1 = np.ascontiguousarray(Ur1)

        self.demT = np.ascontiguousarray(self.dem.transpose(0, 2, 1))    # (nt, nd, nm)
        self._cap = 0
        self.N = 0
        self._grow(4096)
        self.t_mark = -1.0

    def _vertices(self, here, nt, nm, nd):
        """Dual vertices of U_m, from the offline file; Leontief fixed-mix vertex as the fallback."""
        try:
            z = np.load(os.path.join(here, "_vert.npz"))
            AV = np.asarray(z["AV"], dtype=np.float64)
            NV = np.asarray(z["NV"], dtype=np.int64)
            if AV.shape[0] == nm and AV.shape[2] == nd:
                V = int(min(self.VCAP, AV.shape[1]))
                AV = AV[:, :V, :].copy()
                for m in range(nm):                            # pad unused slots with a duplicate (harmless in a min)
                    k = int(min(NV[m], V))
                    if k < 1:
                        AV[m, :] = 1.0
                    elif k < V:
                        AV[m, k:] = AV[m, 0]
                bad = ~np.isfinite(AV) | (AV < 0)
                AV[bad] = 0.0
                if (AV.sum(axis=2) > 0).all():
                    return AV
        except Exception:
            pass
        try:
            from _freq import FREQ_PPM
            f = np.asarray(FREQ_PPM, dtype=np.float64) + 1e-9
        except Exception:
            f = np.ones(nt)
        AV = np.ones((nm, 1, nd))
        for m in range(nm):
            fm = f * self.comp[:, m]
            p = (fm[:, None] * self.dem[:, m, :]).sum(axis=0)
            if p.max() > 0:
                p = np.maximum(p / p.max(), P_FLOOR)
                k = int(np.argmax(1.0 / p * -1.0))             # the binding dimension of an empty server
                a = np.zeros(nd)
                a[k] = 1.0 / p[k]
                AV[m, 0] = a
        return AV

    def _grow(self, need):
        cap = max(4096, self._cap * 2)
        while cap < need:
            cap *= 2
        R = np.ones((self.nd, cap))
        Ur = np.zeros((self.V, cap))
        U = np.zeros(cap)
        mt = np.zeros(cap, dtype=np.int64)
        wv = np.zeros(cap)
        if self._cap:
            N = self.N
            R[:, :N] = self._R[:, :N]; Ur[:, :N] = self._Ur[:, :N]; U[:N] = self._U[:N]
            mt[:N] = self._mt[:N]; wv[:N] = self._w[:N]
        self._R, self._Ur, self._U, self._mt, self._w = R, Ur, U, mt, wv
        self._cap = cap

    # ------------------------------------------------------------------ bookkeeping, indexed by server id
    def _cols(self, cols):
        """Recompute the cached vertex values of these servers from their (authoritative) residual."""
        if not len(cols):
            return
        A = self.AV[self._mt[cols]]                    # (c, V, nd)
        ur = np.einsum("cvk,kc->vc", A, self._R[:, cols])
        self._Ur[:, cols] = ur
        self._U[cols] = ur.min(axis=0)

    def _sync(self, state, batch):
        N = int(state.n_servers)
        if N > self._cap:
            self._grow(N)
        if N > self.N:                                 # servers opened since my last look (mine, or after a failure)
            new = np.arange(self.N, N)
            self._mt[new] = state.server_type[new].astype(np.int64)
            self._w[new] = self.w[self._mt[new]]
            self._R[:, new] = (1.0 - state.used[new]).T
            self._cols(new)
            self.N = N
        if batch and N:                                # once per batch: departures, evictions, any drift
            Rs = (1.0 - state.used[:N]).T
            ch = np.flatnonzero(np.abs(self._R[:, :N] - Rs).max(axis=0) > 1e-12)
            if len(ch):
                self._R[:, ch] = Rs[:, ch]
                self._cols(ch)

    def _open(self, state, t, m):
        if self.REUSE:
            n0 = self.N
            if n0:
                e = np.flatnonzero((state.n_vms[:n0] == 0) & (self._mt[:n0] == m))
                if len(e):
                    sid = int(e[0])
                    self._R[:, sid] = 1.0 - self.dem[t, m]
                    self._cols(np.array([sid]))
                    return sid
            return "new:%d" % m
        return "new:%d" % m

    # ------------------------------------------------------------------ the decision
    def place(self, request, state):
        t = request["vm_type"]
        try:
            batch = state.now != self.t_mark
            self.t_mark = state.now
            self._sync(state, batch)
            N = self.N
            if N:
                mt = self._mt[:N]
                d = self.demT[t][:, mt]                        # (nd, N) physical demand on each server
                Bp = self._R[:, :N] - d
                ok = (Bp.min(axis=0) >= -EPS) & (state.n_vms[:N] > 0) & self.comp[t][mt]
                if ok.any():
                    Ua = (self._Ur[:, :N] - self.G[t][:, mt]).min(axis=0)
                    c = np.where(ok, (self._U[:N] - Ua) * self._w[:N], np.inf)
                    j = int(c.argmin())
                    if self.TIE == "bf":
                        eq = c <= c[j] + 1e-12 + self.TOL
                        j = int(np.where(eq, Ua, np.inf).argmin())
                    sid = j
                    m = int(mt[j])
                    if (state.used[sid] + self.dem[t, m] <= 1.0).all():
                        self._R[:, sid] = Bp[:, sid]
                        self._Ur[:, sid] -= self.G[t][:, m]
                        self._U[sid] = self._Ur[:, sid].min()
                        return sid
            return self._open(state, t, int(self.best_new[t]))
        except Exception:                                      # a bad batch must never cost the whole instance
            return "new:%d" % int(self.cheapest[t])
