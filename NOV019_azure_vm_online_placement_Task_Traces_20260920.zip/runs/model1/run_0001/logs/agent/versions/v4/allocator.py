"""Capacity-priced best fit with a self-calibrating residual metric.

The zone is paid for by the weighted server-hour, every VM type demands all four live dimensions (hdd is
identically 0 in this trace) and demand rises through the window, so servers almost never close and the whole
game is packing efficiency: keep the fleet's *usable* capacity as large as possible.

Value a server of machine type m with residual r by the Leontief usable fraction

    U(r) = min_k r_k / p[m,k]                  p[m,k] = shape of the demand that machine type m has to absorb

-- the number of "mix bundles" that still fit, so U = 0 exactly when the server can take nothing more.  A
placement is priced by the usable capacity it destroys, w[m] * (U(r) - U(r-d)), and we take the cheapest; the
optional THETA term adds classical best-fit pressure (leave the smallest usable residual behind).

p is not a constant of the trace: the live mix per machine type swings from [.70 .67 0 .67 1] (four dimensions
binding at once) to [.79 .41 0 .45 1] (nic alone) between days, and a wrong p makes U measure the wrong
dimension.  So p is estimated online from the fleet itself -- sum of `used` over the servers of that machine
type -- and shrunk towards a fleet-history prior while the fleet is small.  Nothing here is fitted to a day.

The machine type of a NEW server is the one the lower bound itself would buy: the LP dual of the clairvoyant
fractional relaxation prices each machine type's binding dimension (`_mu.npz`, stable to ~2% across the seven
practice days), and argmin_m sum_k mu[m,k] d[t,m,k] reproduces that bound's routing to 0.0%.
"""
import os

import numpy as np

try:
    from _freq import FREQ_PPM                  # per-million vm-type arrival counts, fleet history (days < 7)
except Exception:                               # pragma: no cover
    FREQ_PPM = None

P_FLOOR = 1e-3
BIG = 1e9


class Allocator:
    THETA = 0.0          # best-fit pressure: cost += THETA * w * (usable residual left behind)
    TIE = "old"          # tie-break among exact-equal capacity prices: old|new|bf|wf|full|vms
    GAMMA = 0.0          # stranded-capacity penalty: cost += GAMMA * w * (mean_k residual - min_k residual)
    OPEN_MULT = None     # open a new server when the best fit costs more than OPEN_MULT * its fair price
    LAM = 0.0            # lifetime-extension term (0 = off)
    AGE_C = 1.0          # a server's remaining open time is at least AGE_C * its age
    LMIN = 0.05
    PMODE = "live"       # residual metric: "prior" (history arrival mix) | "live" (fleet mix) | "arriv"
    PREF = 0.1           # hours between profile refreshes
    KAPPA = 100.0        # shrinkage of the online profile towards the prior, in servers
    DECAY = 0.7          # per-refresh decay of the arrival accumulator

    # ------------------------------------------------------------------ setup
    def _cfg(self, name, default):
        v = os.environ.get("ALLOC_" + name)
        if v is None:
            return default
        if v == "none":
            return None
        try:
            return float(v)
        except Exception:
            return v

    def reset(self, cluster):
        for k in ("TIE", "THETA", "GAMMA", "OPEN_MULT", "LAM", "AGE_C", "LMIN", "PMODE", "PREF", "KAPPA", "DECAY"):
            setattr(self, k, self._cfg(k, getattr(self, k)))
        here = os.path.dirname(os.path.abspath(__file__))
        z = np.load(cluster["machines_file"])
        raw = np.asarray(z["demand"], dtype=np.float64)
        self.w = np.asarray(z["weight"], dtype=np.float64)
        nt, nm, nd = raw.shape
        self.nt, self.nm, self.nd = nt, nm, nd
        self.comp = ~np.isnan(raw[:, :, 0])
        self.dem = np.where(self.comp[:, :, None], np.nan_to_num(raw, nan=0.0), 0.0)

        # ---- prior profile: the shape of the arrival demand each machine type would see
        f = np.ones(nt)
        if FREQ_PPM is not None and len(FREQ_PPM) == nt:
            f = np.asarray(FREQ_PPM, dtype=np.float64) + 1e-9
        P0 = np.ones((nm, nd))
        for m in range(nm):
            fm = f * self.comp[:, m]
            if fm.sum() > 0:
                p = (fm[:, None] * self.dem[:, m, :]).sum(axis=0)
                if p.max() > 0:
                    P0[m] = np.maximum(p / p.max(), P_FLOOR)
        self.P0 = P0

        # ---- machine type for a new server: the same Leontief capacity price as the placement rule,
        # which (unlike an LP dual) charges a machine where the VM eats most of the binding dimension
        invP0 = 1.0 / P0
        dop0 = np.where(self.comp[:, :, None], self.dem / P0[None, :, :], 0.0)
        ue = invP0.min(axis=1)
        newcost = self.w[None, :] * (ue[None, :] - (invP0[None, :, :] - dop0).min(axis=2))
        newcost = np.where(self.comp, newcost, np.inf)
        self.newcost = newcost
        self.best_new = np.argmin(newcost, axis=1).astype(np.int64)
        self.best_newcost = newcost[np.arange(nt), self.best_new]
        self.cheapest = np.argmin(np.where(self.comp, self.w[None, :] * self.dem.max(axis=2), np.inf), axis=1)

        # ---- predicted life per (vm type, priority), from the fleet history
        self.life = np.full(2 * nt, 4.5)
        try:
            v = np.asarray(np.load(os.path.join(here, "_life.npz"))["mean24"], dtype=np.float64)
            if len(v) == 2 * nt:
                self.life = np.maximum(v, self.LMIN)
        except Exception:
            pass
        self.invlife = 1.0 / np.maximum(self.life, self.LMIN)

        tot = self.dem.sum(axis=(0, 1))
        kw = (tot > 0).astype(np.float64)
        self.kw = kw / max(kw.sum(), 1.0)
        self._set_profile(P0)
        self.A_acc = np.zeros((nm, nd))
        self.A_n = np.zeros(nm)
        self.t_ref = -1e9
        self.diag = os.environ.get("ALLOC_DIAG") or None
        self._diag_next = 0.0
        self._srv_cap = 8192
        self.md = np.zeros(self._srv_cap)
        self.open_t = np.zeros(self._srv_cap)
        self._cap = 0
        self.n = 0
        self._grow(4096)
        self.t_mark = -1.0
        self.empty_ids = np.zeros(0, dtype=np.int64)
        self.empty_mt = np.zeros(0, dtype=np.int64)

    def _set_profile(self, P):
        self.P = P = np.maximum(P, P_FLOOR)
        self.invP = 1.0 / P
        dop = self.dem / P[None, :, :]
        dop[~self.comp] = BIG                    # an incompatible machine type can never look free
        self.DOP = dop
        self.DOPT = np.ascontiguousarray(dop.transpose(0, 2, 1))       # (nt, nd, nm)

    def _grow(self, need):
        cap = max(4096, self._cap)
        while cap < need:
            cap *= 2
        n = self.n
        A = np.zeros((self.nd, cap)); ub = np.zeros(cap); mt = np.zeros(cap, np.int64)
        wj = np.zeros(cap); sid = np.zeros(cap, np.int64); R = np.zeros(cap)
        if n:
            A[:, :n] = self._A[:, :n]; ub[:n] = self._ub[:n]; mt[:n] = self._mt[:n]
            wj[:n] = self._w[:n]; sid[:n] = self._sid[:n]; R[:n] = self._R[:n]
        self._A, self._ub, self._mt, self._w, self._sid, self._R = A, ub, mt, wj, sid, R
        self._cap = cap

    # ------------------------------------------------------------------ the fleet view, rebuilt once per batch
    def _refresh(self, state, ids, mt):
        """Re-estimate p[m,:] from what the fleet is actually made of."""
        nm, nd = self.nm, self.nd
        if self.PMODE == "live":
            u = state.used[ids]
            S = np.empty((nm, nd))
            for k in range(nd):
                S[:, k] = np.bincount(mt, weights=u[:, k], minlength=nm)
            cnt = np.bincount(mt, minlength=nm).astype(np.float64)
        else:
            S = self.A_acc
            cnt = self.A_n
        mx = S.max(axis=1)
        good = mx > 0
        Pl = S / np.where(mx > 0, mx, 1.0)[:, None]
        g = np.clip(cnt / (cnt + self.KAPPA), 0.0, 1.0)[:, None]
        P = np.where(good[:, None], g * Pl + (1.0 - g) * self.P0, self.P0)
        self._set_profile(P / np.maximum(P.max(axis=1, keepdims=True), 1e-12))

    def _rebuild(self, state):
        N = int(state.n_servers)
        nv = state.n_vms[:N]
        ids = np.flatnonzero(nv > 0)
        n = len(ids)
        mt = state.server_type[ids].astype(np.int64)
        now = state.now
        if self.PMODE != "prior" and now - self.t_ref >= self.PREF:
            self.t_ref = now
            if self.PMODE == "live":
                self._refresh(state, ids, mt)
            else:
                self._refresh(state, ids, mt)
                self.A_acc *= self.DECAY
                self.A_n *= self.DECAY
        if n > self._cap:
            self._grow(n)
        A = ((1.0 - state.used[ids]) * self.invP[mt]).T
        self._A[:, :n] = A
        self._ub[:n] = A.min(axis=0)
        self._mt[:n] = mt
        self._w[:n] = self.w[mt]
        self._sid[:n] = ids
        if N > self._srv_cap:
            cap = self._srv_cap
            while cap < N + 1:
                cap *= 2
            md = np.zeros(cap); md[:self._srv_cap] = self.md; self.md = md
            ot = np.zeros(cap); ot[:self._srv_cap] = self.open_t; self.open_t = ot
            self._srv_cap = cap
        if self.LAM:
            self._R[:n] = np.maximum(self.md[ids] - now, self.AGE_C * (now - self.open_t[ids]))
        self.n = n
        e = np.flatnonzero(nv == 0)
        self.empty_ids = e
        self.empty_mt = state.server_type[e].astype(np.int64)
        if self.diag is not None and now >= self._diag_next:
            self._diag_next = now + 1.0
            try:
                ub = self._ub[:n]; wj = self._w[:n]
                with open(self.diag, "a") as fh:
                    fh.write("t=%.2f n=%d wsum=%.1f waste=%.1f wsingle=%.1f p1=%s p23=%s mt=%s\n" % (
                        now, n, wj.sum(), float((wj * ub).sum()), float(wj[nv[ids] <= 2].sum()),
                        np.round(self.P[1], 3).tolist(), np.round(self.P[23], 3).tolist(),
                        {int(m): int(c) for m, c in zip(*np.unique(mt, return_counts=True)) if c > 20}))
            except Exception:
                pass

    def _append(self, sid, m, dop, now, life):
        n = self.n
        if n + 1 > self._cap:
            self._grow(n + 1)
        row = self.invP[m] - dop
        self._A[:, n] = row
        self._ub[n] = row.min()
        self._mt[n] = m
        self._w[n] = self.w[m]
        self._sid[n] = sid
        self._R[n] = life
        if sid < self._srv_cap:
            self.md[sid] = now + life
            self.open_t[sid] = now
        self.n = n + 1

    def _open(self, state, t, m, life):
        dop = self.DOP[t, m]
        now = state.now
        if len(self.empty_ids):
            k = np.flatnonzero(self.empty_mt == m)
            if len(k):
                k = int(k[0])
                sid = int(self.empty_ids[k])
                self.empty_mt[k] = -1
                self._append(sid, m, dop, now, life)
                return sid
        self._append(int(state.n_servers), m, dop, now, life)
        return "new:%d" % m

    # ------------------------------------------------------------------ the decision
    def place(self, request, state):
        t = request["vm_type"]
        try:
            now = state.now
            if now != self.t_mark:
                self.t_mark = now
                self._rebuild(state)
            mbest = int(self.best_new[t])
            if self.PMODE == "arriv":
                self.A_acc[mbest] += self.dem[t, mbest]
                self.A_n[mbest] += 1.0
            life = self.life[2 * t + (1 if request["priority"] else 0)] if self.LAM else 0.0
            n = self.n
            if n:
                dg = self.DOPT[t][:, self._mt[:n]]
                B = self._A[:, :n] - dg
                ua = B.min(axis=0)
                c = self._ub[:n] - ua
                if self.THETA:
                    c += self.THETA * ua
                if self.GAMMA:
                    c += self.GAMMA * (self.kw @ B - ua)
                if self.LAM:
                    c += self.LAM * np.maximum(0.0, 1.0 - self._R[:n] * self.invlife[2 * t + (1 if request["priority"] else 0)])
                c *= self._w[:n]
                c = np.where(ua >= 0.0, c, np.inf)
                j = int(c.argmin())
                tie = self.TIE
                if tie != "old" and c[j] < np.inf:
                    eq = c <= c[j] + 1e-12
                    if tie == "bf":      sec = ua
                    elif tie == "wf":    sec = -ua
                    elif tie == "new":   sec = -self._sid[:n].astype(np.float64)
                    elif tie == "full":  sec = self._age[:n]
                    elif tie == "vms":   sec = -self._nv[:n].astype(np.float64)
                    else:                sec = np.zeros(n)
                    j = int(np.where(eq, sec, np.inf).argmin())
                if c[j] < np.inf:
                    if self.OPEN_MULT is None or c[j] <= self.OPEN_MULT * self.best_newcost[t]:
                        sid = int(self._sid[j])
                        m = int(self._mt[j])
                        if self.comp[t, m] and (state.used[sid] + self.dem[t, m] <= 1.0).all():
                            self._A[:, j] = B[:, j]
                            self._ub[j] = ua[j]
                            if self.LAM:
                                e = now + life
                                if sid < self._srv_cap and self.md[sid] < e:
                                    self.md[sid] = e
                                    if self._R[j] < life:
                                        self._R[j] = life
                            return sid
            return self._open(state, t, mbest, life)
        except Exception:                        # never crash a batch
            return "new:%d" % int(self.cheapest[t])
