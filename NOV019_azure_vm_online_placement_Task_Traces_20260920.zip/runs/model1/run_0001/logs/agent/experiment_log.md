# Experiment log

| version | what changed | practice reward (7/7 instances) | note |
|---|---|---|---|
| v0 | starter as shipped | 0.000000 by construction | first fit, cheapest machine type for new servers |
| v1 | rewrite: capacity-priced best-fit. Value a server's residual r by the Leontief usable fraction U(r)=min_k r_k/p[m,k] (p = normalized aggregate demand profile of machine type m, from the fleet-history arrival mix in `_freq.py`); place to minimise w[m]*(U(r)-U(r-d)); machine type of a new server = argmin of the same score on an empty server; reuse empty server ids; rebuild a compacted numpy view of open servers once per decision batch; verify the chosen decision against `state.used` and fall back to `new:cheapest` on any exception | **0.047286** (run 01; 0 failed, 0 evicted, 7/7, cand-cpu 1080s) | KEPT. per instance: P000 -0.044, P001 +0.042, P002 -0.085, P003 -0.126, P004 +0.180, P005 +0.208, P006 +0.156. Negative exactly on the days whose VMs live longest / whose fleet is biggest (P002/P003), positive on the small-fleet days |
| v2 | v1 + lifetime-aware term: per (vm type, priority) predicted life L from `_life.npz` (history, censoring-aware), per-server predicted remaining open time R = max(max predicted end - now, AGE_C*age); cost = w*(dU + LAM*relu(1-R/L)), LAM=1, so a new server (R=0) is priced at w*(dU+LAM) | truncated look only (P006, first 60k requests): peak open servers 2366 vs v1 834 on 40k -- packing clearly destroyed | REVERTED (kept as the parameterised code base with LAM=0 = v1; LAM sweep continues) |

## What the offline analysis established (drives every version below)

* I rebuilt the task's own lower bound as an LP (`/app/lp.py`): per 0.5 h of the scored window, minimise sum_m w[m] x[m]
  over fractional assignments y[t,m] of the live VM multiset. It reproduces `truth.json`'s LB to **0.01-0.3 % on all
  seven practice days**, so the LP is a faithful model of the bound and its duals are usable.
* The LP duals mu[m,k] are extremely sparse and stable across days: **each machine type has essentially one binding
  dimension** (m1/m16 -> nic at price 1.0 exactly, m23 -> core 0.634, m4/m14 -> core). The LB's portfolio is
  {m1, m16, m23} on every day; the shares move a lot day to day (m1 0.25 -> 0.62), the duals do not.
* The dual price of hosting VM type t is nu_t = min_m sum_k mu[m,k] d[t,m,k], and sum over live VMs of nu_t = LB.
  Measured against it, **v1's machine-type routing is already within 0.18 % of dual-optimal**, and the "obvious"
  LP-profile Leontief routing is 4.3 % *worse*. So the machine-type choice is NOT where the loss is -- do not touch it.
* Every VM type demands all four live dimensions (hdd is identically 0), so a residual that is dead in one dimension
  really is dead: the Leontief value function U(r) is the right shape, and multi-price-vector refinements are surplus.
* v1's own cost rate / LB rate over the scored window: P000 1.091, P001 1.100, P002 1.062, P003 1.060, P004 1.058,
  P005 1.136, P006 1.148. The starter's: 1.089, 1.103, 1.056, 1.053, 1.071, 1.184, 1.185. **The headroom per day is
  what differs** -- on the big-fleet days (P002/P003, 7.4k servers) first fit is already 5 % from a fractional
  clairvoyant bound, on the small-fleet days (P005/P006, 2.8k servers) it is 18 % off.
* Demand *rises* through the scored window on every day: running-max of the LB rate / mean of the LB rate = 1.004-1.045,
  and v1 opens 3023 servers on P006 but only ever closes ~126. **Servers essentially never close, and that costs almost
  nothing** -- so lifetime segregation (the v2 idea) cannot be the main lever, and opening capacity a bit early is
  nearly free because it would have been opened later anyway. What is left is packing efficiency.
* Hourly diagnostics (`ALLOC_DIAG`, weight of unusable-shaped residual sum_s w_s*ub_s over paid weight sum_s w_s):
  P003 3.4 % (against 5.3 % total headroom -- almost nothing to win, easy to lose), P006 10-18 % (loose).

### v3  (parent v1)  — LB-dual routing + self-calibrating live-fleet profile  — **REVERTED**
Two changes on top of v1, both aimed at the two free parameters of the Leontief criterion:
1. **routing**: replace v1's Leontief new-server price with the *LP dual* price
   `newcost[t,m] = sum_k mu[m,k] d[t,m,k]` (`_mu.npz`, the mean duals of my LB reconstruction over the 7
   practice days; `argmin_m` reproduces the bound's own routing exactly);
2. **profile**: estimate `p[m,k]` online from the live fleet (`p ~ sum_{s of type m} used[s,k]`), shrunk to the
   history prior with weight `kappa/(kappa+n_servers_of_that_type)`, refreshed every `PREF` h.

Quick look (full instance, in-process): **P003 score −1.0000, cost 81860 (v1: 33962), peak 10204 servers
(v1: ~3000), 0 failures.** Catastrophic, and the cause is structural, not a bug: an LP dual prices the
*fractional* optimum, so it is happy to route a VM type onto a machine type where the VM eats ~0.9 of the
binding dimension (cheap per unit of resource, and splittable in the LP). Integrally that strands the rest of
the server. v1's Leontief price `w[m]·(U(empty) − U(empty−d[t,m]))` charges exactly that stranding, so it is
integrality-aware — the same value function that scores the placement also picks the machine type.
Reverted; the dual is the right price for the *bound*, not for a packing.  Snapshot: versions/v3 (stage/v4).

### v4  (parent v1)  — v3 minus the dual routing; adds tie-break / best-fit / stranded-capacity knobs
v1's Leontief routing restored (v4 == v1 when `PMODE=prior`, all knobs at their defaults), plus three knobs
so the *packing criterion* itself can be tested: `THETA` (best-fit pressure, cost += THETA·w·usable-left),
`GAMMA` (stranded capacity, cost += GAMMA·w·(mean_k − min_k of the scaled residual)), `TIE` (what breaks an
exact tie in the capacity price: `old` = lowest server id, the v1 behaviour, vs `new|bf|wf|full|vms`).
Structural reason to look here: ΔU = d_k*/p_k* whenever the binding dimension does not move, so the price is
*identical* across most feasible servers and the tie-break is the real packing rule.

**sweep_03** (v5 = versions/v4 code, full instances in-process, P003 / P006; v5 `PMODE=prior` == v1 up to
±0.008, so read these as deltas within v5, not against the official v1 run):

| config | P003 | P006 | note |
|---|---|---|---|
| `PMODE=prior` (= v1) | −0.1210 | +0.1489 | baseline |
| `PMODE=live` | −0.0842 | +0.1687 | live-fleet profile, shrunk to the history prior |
| `PMODE=arriv` | −0.0699 | +0.2606 | profile from the decayed *arrival* mix |
| `PMODE=prior TIE=new` | −0.0480 | +0.2071 | tie -> newest server |
| **`PMODE=prior TIE=bf`** | **+0.2114** | **+0.3011** | tie -> tightest server (best fit) |
| `THETA=0.3/1/3` (P006 K20k) | — | peak 780/703/860 vs 592 | best-fit *inside the price*: much worse |

The structural prediction is confirmed: **DeltaU = d_k*/p_k* whenever the binding dimension does not move, so the
capacity price is exactly equal across most feasible servers and the tie-break is the real packing rule.**
Best fit has to be applied *among the equal-price placements* (`TIE=bf`), where it is worth +0.15..+0.33 on a
single instance; folded into the price (`THETA`) it instead reorders the primary criterion and costs 20-45% more
servers. Both changes are one-liners and both are pure functions of the visible state.

### v5  (parent v4/v1)  — **best-fit as the TIE-BREAK among equal capacity prices**  — KEPT
`TIE="bf"`, `PMODE="prior"` baked in as class defaults (verified bit-identical to running v4 with those env
overrides). Nothing else changed: the price is still v1's Leontief `w[m]·(U(r) − U(r−d))`, routing still
`w[m]·(U(empty) − U(empty−d[t,m]))`, no parameters, no lifetime model, no eviction.

**selfcheck run 02 — official, sandboxed, 7/7 practice windows — reward = 0.205453**
(`cost_ratio_score 0.212662`, `n_failed 0`, `n_evicted 0`, `constraint_pass_rate 1.0`)

| inst | v1 score | v5 score | v5 cost | starter | bound | peak | cand-cpu |
|---|---|---|---|---|---|---|---|
| P000 | −0.0930 | **+0.2677** | 69659.8 | 71219.7 | 65393.0 | — | 245.4 s |
| P001 | −0.0311 | **+0.2703** | 67583.0 | 69400.8 | 62677.0 | — | 209.2 s |
| P002 | +0.0400 | **+0.2716** | 57196.5 | 58066.2 | 54864.1 | — | 152.0 s |
| P003 | −0.1260 | **+0.2114** | 59007.5 | 59640.5 | 56646.0 | — | 149.3 s |
| P004 | +0.1021 | **−0.0258** | 62180.0 | 62073.1 | 57936.7 | — | 161.9 s |
| P005 | +0.0674 | **+0.1419** | 24113.4 | 24656.2 | 20830.9 | — | 102.3 s |
| P006 | +0.1564 | **+0.3011** | 25105.3 | 26344.0 | 22230.3 | — |  96.3 s |
| mean | 0.047286 | **0.205453** | | | | | ≤245 s of 1500 s |

6 of 7 days improve, one (P004) goes slightly negative; the mean is 4.3x v1. The in-process sweep predicted
0.2055 and every per-instance score matched the sandboxed run to 4 decimals, so `quick.py`/`sweep.py` (full
instances, in-process) is a faithful stand-in for the verifier and can be used for triage. CPU head-room is
6x. **Generalization rule adopted from here on:** judge only on the 7-day mean of full windows, prefer
parameter-free structural changes, and never accept a change whose 7-day gain is inside the per-day noise
(per-day effect sd ~ 0.2, so SE of the mean ~ 0.076); a change that only fixes one day is noise.
Snapshot: versions/v5 (= methods/main).

### v6  (parent v5) — two more tie-break shapes (`bf1`, `dot`) — NOT MEASURED on 7 days, deprioritized
`stage/v6` adds `TIE=bf1` (best fit on the *weighted mean* residual instead of the Leontief min) and `TIE=dot`
(best fit on the alignment of the residual with the arrival mix), plus `PICK`/`ROUTE` for a starter ablation and
an additive waste decomposition (`DIAG`).  A 7-day sweep was launched and killed at 15 min to free all four
cores for the lifetime direction below, which the oracle probe had just shown to be much larger.  No reading;
nothing promoted.  Snapshot: versions/v6.

### D1 (diagnostic, not a version) — the departure ORACLE: how much is lifetime knowledge worth?
`stage/oracle` and `stage/v8` can read the practice window's real departure times (`ALLOC_OR=1`) **as an
offline measurement only** -- never in `methods/main`, never in a graded run.  The point is to bound the gain
any lifetime model could produce.  The criterion is the true marginal cost of a placement:

    ext(s) = w[m] * max(0, min(death of this VM, 24) - max(current death of s, now, 12))     [server-hours]

with `death of s` = max over the VMs on s of their real end times (exactly maintainable as a running max: a
departed VM's end is <= now, so it can never be the max of a non-empty server).

| run | criterion | P006 score | peak servers | note |
|---|---|---|---|---|
| v5 | price -> best-fit | **+0.3011** | ~600 | baseline |
| oracle, `lex` | ext -> best-fit | **+0.1472** | **3444** | full window, 320k requests |
| oracle, `lex`, K=20k | ext -> best-fit | cost 1604 vs 3313 | 618 vs 629 | truncated: looks like a 2x win |

**The full-window run kills the naive form and explains why.** `ext` is a *continuous* criterion, so the
equal-cost set is a single server and the tie-break never runs: the capacity price disappears from the
decision and the fleet inflates 5x (3444 peak vs ~600).  A truncated window hides this completely -- with no
arrivals after K the fleet only drains, so the run rewards exactly the wrong thing.  Two lessons:
1. the Leontief capacity price must stay the *primary* criterion; anything new has to enter either as a
   discrete pre-primary (with price -> best-fit as its tie-break) or in commensurable units;
2. `add` (c = ext + KAP*dU) with KAP <= 24 is not a mixture at all: ext spans 0..24 h while KAP*dU spans
   0.06..0.6, so ext dominates and `add` degenerates to `lex`.  A real mixture needs KAP ~ 30..300.
This produced the **shelf** form: primary `1[the VM outlives the server]` (two levels, so ties are the norm),
tie-break = v5's own rule (price, then best fit).  K=20k P006: 1697 predicted / **1143 oracle** / 1756 v5.

### D2 (diagnostic, not a version) — **the lifetime direction is dead, and the oracle is what kills it**
`stage/v8` = v5 + a time-extension pre-primary.  Predicted death of the arriving VM from the pre-day-7 history
(per (vm_type, priority): `E[min(L,24)]`, median, or the 75th percentile -- all Kaplan-Meier corrected);
predicted death of a server from `max(running max of its VMs' predicted deaths, now + R(server age))` with
`R` = the age-conditional median residual life, also from the history.  The age signal is strong in the trace
(median residual life 0.7 h at age 0, 3.8 h at age 1 h, 9.8 h at 2 h, 18.5 h at 4 h; P(resid > 3 h) 0.22 ->
0.86), and per-type medians span 0.20 h to 26.6 h, so both inputs carry real information.

**Full P006 window (320k requests), shelf form (`1[VM outlives server]` -> price -> best fit):**

| criterion | P006 score | cost | peak |
|---|---|---|---|
| **v5: price -> best fit** | **+0.3011** | **25105.3** | — |
| shelf, predicted `E[min(L,24)]` | +0.2361 | 25372.8 | 2840 |
| shelf, predicted per-type p75 | +0.2291 | 25401.4 | 2929 |
| shelf, age-only (one constant life, no type model) | +0.1289 | 25813.7 | 2840 |
| **shelf, EXACT departure oracle** | **+0.1180** | 25858.4 | 2960 |

The oracle is the *worst* of the four.  This is not a weak-predictor result -- it is a statement about the
trace: **restricting the candidate set to "servers that will outlive this VM" costs more in capacity fit than
time-packing can repay.**  Demand rises across the window, so servers almost never drain; the freed-earlier
server-hours the shelf buys are worth less than the shape damage of not taking the cheapest capacity price.
Sharper knowledge makes the restriction tighter, so the oracle loses the most.  (The K=20k truncated runs
showed a 2x "win" for exactly the opposite reason: with no arrivals after K the fleet only drains, so the
proxy scored the drain phase, which is not what the window is.)
**Consequence for the rest of the run: the remaining 4-16% above LB is shape stranding, not time
fragmentation.  Effort goes into the value function U, not into lifetimes.**  Reverted; nothing promoted.
Snapshot: versions/v8 (`EMODE=off` reproduces v5 exactly).

### v7  (parent v5) — the LP value function instead of the Leontief min — REVERTED
Replace `U(r) = min_k r_k/p_k` (one fixed mix `p`) by the LP value of the residual,

    U_m(r) = max { sum_i x_i s_i : sum_i x_i d_i <= r, x >= 0 }   =   min { a.r : a.d_i >= s_i, a >= 0 }

with `s_i = max_k d_ik` (the dominant share of VM type i) -- a concave min-of-linear function.  The dual
vertices `a` are enumerated offline (`/app/vert.py`, scipy HiGHS, 240 Dirichlet directions + the all-ones and
historical-mix directions, deduped; 25-35 distinct vertices per machine type, the top 8 by optimality
frequency kept) and normalised so `U_m(1) = 1`; at run time `U` is a min over 8 dot products, maintained
incrementally per server column.  Motivation: a fixed mix declares any unbalanced residual worthless, so the
policy creates such residuals for free, while the LP form knows a core-rich residual can still be sold.

**Full P006: score −0.4131** (cost 28043.5, peak 3553) vs v5 **+0.3011**.  Reverted.
This is the *same* failure as v3's LP-dual routing, and the two together are the structural lesson of this
run: **an LP/fractional value function systematically over-values an unbalanced residual**, because the LP may
sell it to a fractional mixture of VM types, while an online integral policy must sell it to whole VMs in the
mix that actually arrives.  The Leontief min is *pessimistic* in exactly the right way -- it assumes the
residual has to be sold in the observed mix, so it charges for unbalancing a server.  Snapshot: versions/v7.

### D3 (diagnostic) — the residual metric's profile `p`, crossed with the best-fit tie-break
`p[m,k]` is the demand shape the Leontief metric assumes machine type `m` must absorb.  Three estimators:
`prior` (frozen pre-day-7 arrival mix), `live` (sum of `used` over the live servers of that machine type,
shrunk to the prior by KAPPA=100 servers), `arriv` (decayed arrival mix, per machine type).
Full instances, in-process, same code (`stage/v5`), only the env differs:

| profile | with TIE=old (sweep_03) | | with TIE=bf (sweep_09) | |
|---|---|---|---|---|
| | P003 | P006 | P003 | P006 |
| `prior` | −0.1210 | +0.1489 | +0.2114 | +0.3011 |
| `live`  | −0.0842 | +0.1687 | **+0.2488** | **+0.3081** |
| `arriv` | −0.0699 | **+0.2606** | +0.2094 | +0.2001 |

**The two levers interact and the ranking flips.** With the old tie-break the arrival-mix profile was far the
best (+0.11 on P006); once best-fit resolves the price degeneracy it is the worst (−0.10 on P006), and the
live-fleet profile is best on both windows.  Reading: the arrival mix answers "what is coming", which is what
you need when the *price* has to do all the work; the live-fleet mix answers "what shape is the capacity I am
already holding", which is what a best-fit rule needs to measure tightness in the right metric.  Promoted to
a 7-day run (sweep_10).

---

### v8-live / D4 — `PMODE=live` on all seven windows: rejected by the pre-registered rule
**parent** v5 · **run** sweep_10 (`/app/methods/logs/sweep_10.log`, quick.py, verified bit-equal to the sandboxed verifier) · **status: NOT promoted**

D3's two-window triage (P003, P006) said the live-fleet profile beats the frozen history prior. The seven-day
run says the triage was reading one day:

| | P000 | P001 | P002 | P003 | P004 | P005 | P006 | mean |
|---|---|---|---|---|---|---|---|---|
| v5 (`PMODE=prior`) | .2677 | .2703 | .2716 | .2114 | −.0258 | .1419 | .3011 | **.20545** |
| `PMODE=live` | .2604 | .2633 | .2584 | .2488 | −.0457 | .2736 | .3081 | .2238 |
| Δ | −.0073 | −.0070 | −.0132 | +.0374 | −.0199 | **+.1317** | +.0070 | +.0184 |

Only 3 of 7 days improve; Δ sd = .053 ⇒ SE = .020 ⇒ t = 0.91. Remove P005 and the mean change is −.0005, i.e.
the entire effect is one window. The pre-registered rule (mean must beat the incumbent AND ≥6/7 days improve,
or mean gain > 2 SE ≈ .15) rejects it, and I am honouring the rule rather than the mean: a +.018 mean carried by
a single day out of seven is the definition of an effect that will not transfer to days 7–13.

**Kept as a finding, not a change.** The profile choice is now second-order; the tie-break is first-order.
*Also recorded:* the two-window triage is only a filter for what deserves a seven-day run — it has now twice
(D3, and the THETA sweep) ranked configs differently from the full reading.

### v9 — harmonic size class: the trace has no size granularity to exploit
**parent** v5 · **snapshot** versions/v9 · **status: SCL branch abandoned before measurement (diagnostic)**

Idea: the residual gap is stranding, and the classical 1-D fix is size classes — a server that holds only VMs
of which *k* copies fit has its fragmentation bounded by 1/k, because a departure leaves exactly the hole the
class needs. Profile-free class straight from the machine table: `cls[t,m] = min(CMAX, floor(1/max_k d[t,m,k]))`,
server labelled by its largest VM, mismatch charged `SCL` residual-units inside the best-fit tie-break
(`SCL=0` ⇒ exactly v5).

Killed by the arrival histogram before spending a reading on it — class of each arrival on the machine type we
would open, P006:

| class (copies that fit) | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8+ |
|---|---|---|---|---|---|---|---|---|
| arrivals | 1082 | 1460 | 2244 | 1264 | 13033 | 7228 | 517 | 291018 |

**91.6% of requests are class 8+** — every VM is small relative to a server, so there is almost no size
structure for classes to separate, and `SCL` would be labelling 92% of the fleet with one label. Combined with
the demand-table finding (dimensions correlated .72–.93, core the largest dimension for 77% of arrival-weighted
pairs), the conclusion is that **the remaining gap is directional, not size-granular**: capacity is stranded
because a server fills up in nic while core stays empty, not because a big VM cannot find a big hole.
The `SCL` knob stays in the code at its no-op default 0.0 and the effort moved to the third tie level (v9-T3).

### v9-T3 — third tie level (least total residual among near-tied fits): rejected
**parent** v5 · **snapshot** versions/v9 · **run** sweep_11 (`logs/sweep_11.log`) · **status: reverted**

The directional-stranding fix. `ua` (the Leontief residual) only sees the *binding* dimension, so two servers
that both leave 0.3 usable bundles are tied even if one leaves (0.3,.9,.9,.9) — 1.8 units of unusable slack —
and the other (0.3,.35,.32,.31). Third tie level: among equal capacity price and fit within `TOL`, take the
server leaving the least *total* residual, i.e. the balanced one. (Same quantity `GAMMA` priced and was killed
for; the v5 lesson is that it is harmful in the price and might be useful in the tie-break.)

| | P000 | P001 | P002 | P003 | P004 | P005 | P006 | mean |
|---|---|---|---|---|---|---|---|---|
| v5 | .2677 | .2703 | .2716 | .2114 | −.0258 | .1419 | .3011 | **.20545** |
| `T3=l1` | .2624 | .2753 | .2229 | .1981 | .0093 | .2568 | .2669 | .2131 |
| Δ | −.0053 | +.0050 | −.0487 | −.0133 | +.0351 | +.1149 | −.0342 | +.0077 |
| `T3=l1 TOL=.05` | .2191 | — | — | — | — | — | — | (killed) |

Rejected: mean +.008, 3/7 days. `TOL=.05` is far worse on P000 (.2191 vs .2624) — widening the tie set
destroys best-fit precision, the v5 lesson for the third time, so that branch was killed after one window.

**The finding that matters is the shape of Δ, across both rejected refinements.** `PMODE=live` and `T3=l1` are
independent mechanisms, yet both help exactly where v5 is weakest (P004 +.035/+.035, P005 +.115/+.132) and hurt
exactly where v5 is strongest (P002 −.049/−.013, P006 −.034/+.007). That is variance reduction about an
unchanged mean, not a gain: v5's price+best-fit rule is already at the point where making the criterion more
shape-aware trades one day's stranding for another's. Both were left in the code at no-op defaults.

### Generalization: the practice week and why the sign test is the right guard
The seven practice days are not exchangeable — they are one real week, and days 5–6 are a separate regime:

| | d0 | d1 | d2 | d3 | d4 | d5 | d6 |
|---|---|---|---|---|---|---|---|
| low-priority share | .169 | .208 | .318 | .308 | .173 | **.046** | **.037** |
| starter cost | 71220 | 69401 | 58066 | 59640 | 62073 | **24656** | **26344** |
| fluid load alive @12h | 4891 | 4194 | 2784 | 3289 | 3798 | **1147** | **1373** |

Same request count on d5/d6 (317k) but 3–4x less live load and almost no low-priority work: a weekend.
The sealed split is days 7–13 — also seven consecutive days — so it must carry the same weekly phase mix,
about five weekday and two weekend windows, the same 5:2 as practice. Two consequences I acted on:
1. the **7-day practice mean is a structurally representative estimator** of the sealed mean, so the mean is
   the right quantity to compare — not a per-day best case, and never a 1–2 window triage;
2. the **sign test is the correct second guard**, because a true regime effect has to appear on *both* weekend days.
   `PMODE=live` gained +.132 on P005 and +.007 on P006 — so it is a single-day fluke, not a weekend effect, and
   rejecting it was right. Had both weekend days moved together I would have treated a 2/7 pattern as real.

### v10 — machine-type dominance / fleet flexibility on the opening rule: rejected
**parent** v5 · **snapshot** versions/v10 · **run** sweep_12 (`logs/sweep_12.log`) · **status: reverted**

The machine table has weakly-dominant pairs at an identical weight. Machine type 16 carries the *same* memory,
hdd, ssd and nic demand as type 1 at **0.9165x** its core demand (0.769x at the extreme), at the same weight
1.0, and hosts **281 VM types against type 1's 183**. The opening rule already picked the dominant member of
the other tied pairs (m=1 over m=22, m=23 over m=24) but lost this one: `argmin` broke the exact price tie by
index, sending 76.3% of all new servers to the narrower machine. `NEW=breadth` breaks that tie by how much of
the arrival mix the machine can host (then lighter, then lower index); the mean new-server price is unchanged
to 6 decimals, and the fleet moves from 76.3% m=1 to 76.4% m=16.

| | P000 | P001 | P002 | P003 | P004 | P005 | P006 | mean |
|---|---|---|---|---|---|---|---|---|
| v5 | .2677 | .2703 | .2716 | .2114 | −.0258 | .1419 | .3011 | **.20545** |
| v10 `NEW=breadth` | .1667 | .2073 | .2331 | .1705 | −.0059 | .2943 | .3401 | .2009 |
| Δ | −.1010 | −.0630 | −.0385 | −.0409 | +.0199 | **+.1524** | **+.0390** | −.0046 |

Rejected on the mean. But unlike the two refinements above this is a **real regime effect**, and it is the one
pattern my weekend criterion said to believe: *all five weekdays get worse, both weekend days get better.* It
is simply pointed the wrong way on a 5:2 mix.

**The mechanism is a coupling worth recording: more capacity, worse value function.** The profile `p[m]` is
estimated over the VM types compatible with `m`, so moving the fleet onto the broader machine type blends 281
heterogeneous demand shapes into one profile instead of 183, and the Leontief metric then measures the wrong
dimension more often. The capacity gain (8.4% more usable core at the same price) is real but small, and on the
high-load weekdays it is swamped by the profile degradation; on the light weekend days, where the fleet is small
and sharing matters more than metric precision, the flexibility wins. A strictly dominant hardware change made
the policy worse because the policy's own metric is machine-type-conditioned. `NEW` stays in the code at the
no-op default `"old"` and the pair-dominance scan is kept in the log as a table.

**Decision on the submitted version.** Four alternatives were measured on full 7-day readings:
v5 **.20545** · `PMODE=live` .2238 · `T3=l1` .2131 · `NEW=breadth` .2009. `PMODE=live` has the highest mean but
is rejected by the pre-registered rule (3/7 days; the entire +.018 is P005, and P006 — the *other* weekend day —
moved only +.007, so it is not the regime effect the criterion would accept). Two further reasons, independent
of the statistics, favour v5: it is simpler (a profile frozen from the fleet history, identical for every sealed
day) and it has no closed feedback loop, whereas `PMODE=live` re-estimates the metric from the fleet it built
itself every 0.1 h — a loop whose behaviour on an unseen mix I cannot bound, and which demonstrably swings by
±.13 between two adjacent, structurally similar days. **v5 is submitted.**

### FINAL READING — v5, official self-check (run 03)
`python3 /app/selfcheck.py` on the full practice split · artifacts `selfcheck_runs/03/` · `main` = `versions/v5`
(`diff -r` clean)

```
split=practice  instances=7/7  reward=0.205453  (cost_ratio_score=0.212662)
n_failed 0  n_evicted 0  constraint_pass_rate 1.0  n_feasible 7/7  candidate_cpu 1071.4s (~153s/instance of 1500s)
P000 .2677  P001 .2703  P002 .2716  P003 .2114  P004 -.0258  P005 .1419  P006 .3011
```
Acceptance rule verified: reward.json present, `n_instances == n_declared == 7`, no error line in
verifier_note.txt. `/logs/verifier/reward.json` records reward 0.2054532898512452.

### v11 — routed profile (profile/routing fixed point): rejected, and it explains v10
**parent** v5 · **snapshot** versions/v11 · **run** sweep_13 (`logs/sweep_13.log`) · **status: reverted**

`p[m]` is built from every VM type *compatible* with `m`, but the docstring's own intent is "the shape of the
demand machine type m has to absorb" — and what m absorbs is the types *routed* to it (`best_new[t] == m`), not
everything that could run there. Profile and routing determine each other, so iterate them to a fixed point.
Parameter-free, and it fixes a genuine mismatch between the code and its stated intent.

| | P000 | P001 | P002 | P003 | P004 | P005 | P006 | mean |
|---|---|---|---|---|---|---|---|---|
| v5 | .2677 | .2703 | .2716 | .2114 | −.0258 | .1419 | .3011 | **.20545** |
| v11 routed | −.9515 | −1.0000 | −1.0000 | −1.0000 | −1.0000 | −.0379 | −.4546 | **−.7777** |

Catastrophic: five days clipped at the −1.0 floor, peak servers 8572–10328 against v5's 6191–7975. 0 failures,
0 evictions — this is pure packing collapse, not an error.

**Why, and it is the most useful negative of the run.** The fixed point diversifies the fleet: v5 opens 76.3%
m=1 + 15.8% m=23 (two dominant types), v11 opens m=8 33.8%, m=12 15.4%, m=23 15.4%, m=30 11.6% and a tail.
A server can only host VM types compatible with its machine type, so splitting the fleet across eight machine
types means an arrival finds far fewer compatible servers with room, and opens its own.

Read together with v10 this separates two effects that had been confounded:

| | fleet composition | mean |
|---|---|---|
| v5 | 2 dominant machine types, profile blends 183 types | **.20545** |
| v10 `NEW=breadth` | 2 dominant machine types, profile blends 281 types | .2009 |
| v11 `PROF=routed` | ~8 machine types, sharp per-machine profiles | −.7777 |

**Fleet concentration is first-order; profile sharpness is second-order.** Sharing requires that most VMs can
land on most servers — that is worth an order of magnitude more than measuring the residual in the right
dimension. The sharper metric v11 bought was worth nothing against the sharing it destroyed, and v10's small
loss was the mirror image: same concentration, slightly blunter metric. v5 sits at the good point by
construction, because pricing a new server with the *compatible-set* profile happens to concentrate the fleet.
This also retrospectively justifies the original opening rule, which I had assumed was arbitrary.

### v12 — SUBMITTED: v5 hardened against a machine-table length mismatch
**parent** v5 · **snapshot** versions/v12 · **status: kept (this is what is graded)**

Not a policy change — generalization insurance, motivated directly by v11. The prior profile is weighted by
`_freq.py` (fleet-history arrival counts per VM type) behind the guard `len(FREQ_PPM) == nt`. If the machine
table the verifier hands us carried a different VM-type count, that guard silently fell back to **uniform**
weights. Measured consequence of the uniform path on the practice data:

| | opening machine-type mix | 7-day mean |
|---|---|---|
| frequency-weighted (intended) | m=1 76.3%, m=23 15.8%, m=14 3.2% | **.20545** |
| uniform fallback | m=8 34.9%, m=11 24.3%, m=30 13.6%, m=23 10.2% | ≈ **−.78** (this is v11's fleet) |

**90.8% of arrivals (2 230 170 / 2 455 264) would change their opening machine type**, fragmenting the fleet into
almost exactly the configuration sweep_13 measured at −0.7777. A single file-level difference in `machines.npz`
would have turned +0.205 into about −0.78. The hidden split is the same zone so the table is very probably
identical (488 rows is already the union over the whole trace, against 172–203 distinct types per day) — but
the downside is the whole score and the fix is four lines.

Fix: align by type index instead of giving up — shared ids keep their real frequency, ids beyond the history get
a negligible-but-positive weight, and a shorter table is simply truncated. Verified:

* on the practice table (488 types) `P0`, `best_new`, `newcost` and `DOP` are **bit-identical** to v5
  (`np.array_equal` on all four), so this cannot move the visible score;
* on a synthetic 528-type table the old code fragments to m=8 24.9% / m=11 23.4% / m=23 21.3%, while the new
  code holds m=1 76.3% / m=23 15.8% / m=14 3.2% — i.e. it keeps the +0.205 fleet instead of the −0.78 one.

Re-measured with the official self-check anyway, because the graded bytes changed (run 04 below).

### FINAL READING — v12 (submitted), official self-check (run 04)
`python3 /app/selfcheck.py` · artifacts `selfcheck_runs/04/` · `main` = `versions/v12`

```
split=practice  instances=7/7  reward=0.205453  (cost_ratio_score=0.212662)
n_failed 0  n_evicted 0  constraint_pass_rate 1.0  n_feasible 7/7
cand-cpu per instance: 229.4 195.2 141.0 138.9 156.8 95.8 94.7 s  (6-15% of the 1500 s budget)
cores used per instance: 0.38-0.50 of the 1.5 allowed
P000 .2677  P001 .2703  P002 .2716  P003 .2114  P004 -.0258  P005 .1419  P006 .3011
```
Acceptance rule verified: reward.json present, `n_instances == n_declared == 7`, no error line in
verifier_note.txt. Identical to run 03 (v5) in the reward and in every per-instance score and cost — the
empirical proof that the v12 hardening is a no-op on visible data. `/logs/verifier/reward.json` records
0.2054532898512452.

**Summary of every full 7-day reading taken in this run** (all with 0 failures and 0 evictions):

| version | what it changed | 7-day mean | kept? |
|---|---|---|---|
| v0 starter | first fit | 0.0 by definition | — |
| v1 | Leontief capacity price | .0473 | kept |
| v5 | + best fit as the tie-break among equal prices | **.20545** | kept |
| v7 | LP value function instead of the Leontief min | −.4131 (P006) | reverted |
| v8-live | profile from the live fleet | .2238 | rejected by rule (3/7 days) |
| v9-T3 | third tie level on total residual | .2131 | reverted (3/7 days) |
| v10 | new-server tie broken by fleet flexibility | .2009 | reverted |
| v11 | profile/routing fixed point | −.7777 | reverted |
| **v12** | **v5 + machine-table length hardening** | **.20545** | **SUBMITTED** |

### D5 — diagnostic: how much room is there in eviction?  (parent v12, no code promoted)
`n_evicted` was 0 in every reading so far: the policy never used the third decision form. Reading the
decision core showed why an opportunity must exist — with `OPEN_MULT=None` the price never prefers a new
server over a feasible fit, so **every** opening is a forced one ("nothing fits"), which is exactly the
moment an eviction is legal and could substitute. Instrumented v12 (decisions unchanged) to ask at each
forced opening in the scored window: could evicting low-priority VMs from an existing server have hosted
this VM, and at what cost? Greedy cheapest-first (smallest dominant share), first 60 compatible servers
with `n_low>0`, every 3rd opening. `pen1h` = the true penalty evaluated at the clip floor (1 h), i.e. a
lower bound; `wsaved` = weight of the server avoided.

| window | low-pri share | rescuable | evictions/rescue | pen@1h per rescue | weight avoided | break-even L/H | mean age of evicted |
|---|---|---|---|---|---|---|---|
| P002 | .318 | **88.2%** | 2.30 | 0.456 | 0.815 | 1.8 | 8.2 h |
| P005 | .046 | **85.9%** | 1.16 | 0.163 | 0.939 | **5.8** | 2.8 h |

Two things worth recording. (1) The opportunity is nearly universal — ~86-88% of forced openings had a
feasible eviction, usually a *single* small VM. That is the signature of a tightly packed fleet: best fit
fills servers to the brim, so an arrival fits nowhere, and freeing one sliver anywhere rescues it.
(2) The lever is **inverted with respect to low-priority supply**: the day with 7x more low-priority VMs
(P002) has the *worse* economics, because its evictable VMs are bigger and older (8.2 h vs 2.8 h of elapsed
age — under a heavy-tailed lifetime that means a longer remaining life, so a higher clip) and 2.3 of them
are needed per rescue. Break-even in remaining-life-to-server-hours drops from 5.8 to 1.8.

The prize is large because the LB is tight: the practice gaps `C_starter - LB` are only 3202 (P002) and
3825 (P005), so **1000 weighted-server-hours saved is worth +0.31 / +0.26 of instance score**. Eviction is
also the one lever that can push cost below what pure packing could reach, since the clairvoyant LB packs
every VM and never discards one.

### d6 — eviction as a policy (parent v12) — REVERTED, and the reason matters
Turned D5's scan into a decision: at a forced opening in the scored window, a high-priority request evicts
the cheapest low-priority set that makes room, if the *estimated* penalty `2 w[m] sum(share) x LHAT` is below
the estimated saving `w[m_new] x min(HHAT, 24-now)`. `LHAT=HHAT=3 h`.

```
P005   score 0.0972  cost 24284.5   (v12: 0.1419 / 24113.4)   fail 0  evict 1504  peak 2738 (v12 3085)  opened 2821 (v12 3213)
```

The mechanism works exactly as designed — 392 fewer openings, 347 fewer peak servers, no invalid decision —
**and the cost still went up.** The saving in server-hours is real but smaller than the eviction penalty:
D5 priced a rescue at 0.163 because it evaluated the penalty at the clip *floor* (1 h remaining life), and
the real remaining lives are several hours, so the true price per rescue is roughly an order of magnitude
higher. The whole 5.8x "margin" was an artefact of the floor.

This is the cleanest vindication of the pre-registered rule in the run: an opportunity diagnostic on two
windows said "86% rescuable, 5.8x margin" and the actual measurement on the *same* window said the policy
loses 0.045 of score. Estimated opportunity is not measured cost. Rejected on the strongest regime, so the
weaker one (P002, break-even 1.8) cannot save it; `LHAT=12` (pessimistic life, evict only true slivers)
tested below as d6b.

### d6b — pessimistic eviction (LHAT=12), 7 days (sweep_15) — REJECTED
`LHAT=3 -> 12`: price an evicted VM as if it had 12 h of life left, so only true slivers clear the bar.
On P005 this flipped the lever positive — and P005 is where the threshold was *chosen*, so the other six
days are the honest test.

| window | v12 | d6b (LHAT=12) | delta | regime |
|---|---|---|---|---|
| P000 | .2677 | .1998 | **-.068** | weekday |
| P001 | .2703 | .0349 | **-.235** | weekday |
| P002 | .2716 | -.0416 | **-.313** | weekday, low-pri .318 |
| P003 | .2114 | -.0017 | **-.213** | weekday, low-pri .308 |
| P005 | .1419 | .1920 | +.050 | weekend, low-pri .046 (**tuned here**) |

status: **rejected** — mean already far below v12 after four windows, all four untuned and all worse, two
of them catastrophically. Sweep stopped early; the verdict cannot change.

Why it fails where the diagnostic said it would fail: on weekdays a rescue needs 2.3 evictions of older,
larger low-priority VMs (D5: break-even 1.8 vs 5.8), and those VMs' real remaining lives are long, so the
penalty `2 w share clip(life,1,24)` lands near its ceiling while the avoided server would have been open
only a couple of hours. The lever is real but its sign depends on the day's low-priority mix -- precisely
the quantity the task warns "differs between days" and which I cannot observe on the sealed split until
after I have already evicted. A policy whose sign flips with an unobservable regime variable is exactly
what should not be shipped.

Two rules earned their keep here: **a one-window win is not a result** (P005 +.050 -> 7-day disaster), and
**an opportunity estimate is not a measurement** (D5's 5.8x margin came from pricing at the clip floor).

---

## FINAL ENTRY — v12 submitted (run 05)
`/app/methods/main` = `versions/v12`  (`diff -r` clean). Final official self-check, all seven practice windows:

```
split=practice  instances=7/7  reward=0.205453  (mean_instance_score; cost_ratio_score=0.212662)
n_failed 0   n_evicted 0   constraint_pass_rate 1.0   n_feasible 7/7   0 error lines in verifier_note.txt
P000 .2677  P001 .2703  P002 .2716  P003 .2114  P004 -.0258  P005 .1419  P006 .3011
cand-cpu 103-247 s per instance of 1500 s;  wall 209-604 s
```
Identical to runs 03 and 04 on all 31 scored keys. Acceptance rule satisfied. `/logs/verifier/reward.json`
holds 0.2054532898512452.

**Why v12 and not a higher practice mean.** `PMODE=live` measured .2238 and was rejected: 4/7 days worse,
the whole gain one window, t=0.91. `d6b` eviction measured +.050 on the window it was tuned on and
-.068/-.235/-.313/-.213 on the four untuned weekdays. Both were refused by the same pre-registered rule
(mean must improve AND >=6/7 days individually, or the gain must exceed 2 SE), declared before the
measurements and applied without exception in all four promotion decisions this run (v5 promoted; v8-live,
v9-T3, v10, d6b refused).

**Every version is snapshotted**: `versions/v1..v12` plus the diagnostics `versions/d5`, `d6`, `d6b`.
